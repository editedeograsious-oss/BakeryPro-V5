import pg from 'pg';
import bcrypt from 'bcryptjs';
const { Pool } = pg;

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const PRIMARY_ADMIN_ID = 101;

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS app_state (
      id integer PRIMARY KEY CHECK (id = 1),
      revision bigint NOT NULL DEFAULT 0,
      data jsonb NOT NULL DEFAULT '{}'::jsonb,
      updated_at timestamptz NOT NULL DEFAULT now()
    );
    INSERT INTO app_state (id, revision, data) VALUES (1,0,'{}'::jsonb)
    ON CONFLICT (id) DO NOTHING;

    CREATE TABLE IF NOT EXISTS auth_users (
      id bigint PRIMARY KEY,
      username text UNIQUE NOT NULL,
      password_hash text NOT NULL,
      role text NOT NULL CHECK (role IN ('admin','cashier','baker','rider')),
      display_name text NOT NULL,
      active boolean NOT NULL DEFAULT true,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE UNIQUE INDEX IF NOT EXISTS one_active_admin
      ON auth_users ((role)) WHERE role='admin' AND active=true;

    CREATE TABLE IF NOT EXISTS audit_log (
      id bigserial PRIMARY KEY,
      created_at timestamptz NOT NULL DEFAULT now(),
      actor_id bigint,
      actor_username text,
      actor_role text,
      action text NOT NULL,
      details jsonb NOT NULL DEFAULT '{}'::jsonb,
      device_id text,
      ip text
    );

    CREATE TABLE IF NOT EXISTS payment_transactions (
      id uuid PRIMARY KEY,
      provider text NOT NULL,
      order_id text,
      phone text NOT NULL,
      amount numeric(14,2) NOT NULL,
      currency text NOT NULL DEFAULT 'UGX',
      status text NOT NULL DEFAULT 'PENDING',
      provider_reference text,
      provider_payload jsonb,
      created_by bigint,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    );
  `);

  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'change-this-before-production';
  const hash = await bcrypt.hash(password, 12);
  await pool.query(`
    INSERT INTO auth_users (id, username, password_hash, role, display_name, active)
    VALUES ($1,$2,$3,'admin','Primary Admin',true)
    ON CONFLICT (id) DO UPDATE SET
      username=EXCLUDED.username,
      role='admin',
      active=true,
      updated_at=now()
  `, [PRIMARY_ADMIN_ID, username, hash]);
}

export async function getStateRow(client = pool) {
  const { rows } = await client.query('SELECT revision, data, updated_at FROM app_state WHERE id=1');
  return rows[0];
}

export async function writeAudit(client, actor, action, details = {}, deviceId = null, ip = null) {
  await client.query(
    `INSERT INTO audit_log(actor_id,actor_username,actor_role,action,details,device_id,ip)
     VALUES($1,$2,$3,$4,$5,$6,$7)`,
    [actor?.id ?? null, actor?.username ?? null, actor?.role ?? null, action, details, deviceId, ip]
  );
}
