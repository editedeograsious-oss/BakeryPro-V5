import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { pool } from './db.js';

const secret = () => process.env.JWT_SECRET || 'dev-only-change-me';
const expiresIn = () => process.env.JWT_EXPIRES_IN || '12h';

export function issueToken(user) {
  return jwt.sign({ sub: String(user.id), username: user.username, role: user.role, name: user.display_name }, secret(), { expiresIn: expiresIn() });
}

export async function authenticate(username, password) {
  const { rows } = await pool.query('SELECT * FROM auth_users WHERE username=$1 AND active=true', [username]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return null;
  return user;
}

export async function requireAuth(req, res, next) {
  try {
    const raw = req.headers.authorization || '';
    const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
    if (!token) return res.status(401).json({ error: 'authentication_required' });
    const payload = jwt.verify(token, secret());
    const { rows } = await pool.query('SELECT id,username,role,display_name,active FROM auth_users WHERE id=$1', [payload.sub]);
    const user = rows[0];
    if (!user?.active) return res.status(401).json({ error: 'account_inactive' });
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'invalid_or_expired_token' });
  }
}

export function requireRole(...roles) {
  return (req,res,next) => roles.includes(req.user?.role) ? next() : res.status(403).json({ error: 'forbidden' });
}
