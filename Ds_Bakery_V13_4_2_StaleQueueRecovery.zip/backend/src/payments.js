import crypto from 'crypto';

function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing ${name}`);
  return v;
}

async function mtnToken() {
  const base = process.env.MTN_BASE_URL || 'https://sandbox.momodeveloper.mtn.com';
  const subscription = required('MTN_SUBSCRIPTION_KEY');
  const apiUser = required('MTN_API_USER');
  const apiKey = required('MTN_API_KEY');
  const basic = Buffer.from(`${apiUser}:${apiKey}`).toString('base64');
  const r = await fetch(`${base}/collection/token/`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${basic}`,
      'Ocp-Apim-Subscription-Key': subscription
    }
  });
  if (!r.ok) throw new Error(`MTN token request failed (${r.status})`);
  const body = await r.json();
  if (!body.access_token) throw new Error('MTN token response had no access token');
  return body.access_token;
}

export async function requestMtnPayment({ phone, amount, externalId }) {
  const base = process.env.MTN_BASE_URL || 'https://sandbox.momodeveloper.mtn.com';
  const subscription = required('MTN_SUBSCRIPTION_KEY');
  const token = await mtnToken();
  const reference = crypto.randomUUID();
  const target = process.env.MTN_TARGET_ENV || 'sandbox';
  const currency = process.env.MTN_CURRENCY || 'UGX';
  const callback = process.env.MTN_CALLBACK_URL || '';
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Ocp-Apim-Subscription-Key': subscription,
    'X-Target-Environment': target,
    'X-Reference-Id': reference,
    'Content-Type': 'application/json'
  };
  if (callback) headers['X-Callback-Url'] = callback;
  const payload = {
    amount: String(amount),
    currency,
    externalId: String(externalId || reference),
    payer: { partyIdType: 'MSISDN', partyId: String(phone).replace(/\D/g,'') },
    payerMessage: "D's Bakery payment",
    payeeNote: "D's Bakery order payment"
  };
  const r = await fetch(`${base}/collection/v1_0/requesttopay`, { method:'POST', headers, body:JSON.stringify(payload) });
  if (r.status !== 202) {
    const txt = await r.text();
    throw new Error(`MTN request-to-pay failed (${r.status}): ${txt.slice(0,250)}`);
  }
  return { reference, payload };
}

export async function checkMtnPayment(reference) {
  const base = process.env.MTN_BASE_URL || 'https://sandbox.momodeveloper.mtn.com';
  const subscription = required('MTN_SUBSCRIPTION_KEY');
  const token = await mtnToken();
  const r = await fetch(`${base}/collection/v1_0/requesttopay/${reference}`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Ocp-Apim-Subscription-Key': subscription,
      'X-Target-Environment': process.env.MTN_TARGET_ENV || 'sandbox'
    }
  });
  if (!r.ok) throw new Error(`MTN payment-status request failed (${r.status})`);
  return r.json();
}
