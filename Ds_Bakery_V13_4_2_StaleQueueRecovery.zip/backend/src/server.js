import 'dotenv/config';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { pool, initDb, getStateRow, writeAudit, PRIMARY_ADMIN_ID } from './db.js';
import { authenticate, issueToken, requireAuth, requireRole } from './auth.js';
import { requestMtnPayment, checkMtnPayment } from './payments.js';

const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const frontendDir = path.resolve(__dirname, '../../frontend');

const liveClients=new Set();
function sendLive(res,event,payload){
  try{res.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`)}catch{}
}
function broadcastState(payload){
  for(const c of [...liveClients]){
    try{sendLive(c.res,'state',payload)}catch{liveClients.delete(c)}
  }
}


await initDb();

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
const allowedOrigins=(process.env.CORS_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb){ if(!origin || !allowedOrigins.length || allowedOrigins.includes(origin)) return cb(null,true); cb(new Error('Origin not allowed')); } }));
app.use(express.json({ limit: '3mb' }));

const loginLimiter = rateLimit({ windowMs: 10*60*1000, max: 30, standardHeaders: true, legacyHeaders: false });

function clientIp(req){ return req.ip || req.socket?.remoteAddress || null; }
function changedKeys(a={}, b={}) {
  const keys = new Set([...Object.keys(a||{}), ...Object.keys(b||{})]);
  return [...keys].filter(k => JSON.stringify(a?.[k]) !== JSON.stringify(b?.[k]));
}
function normalizeUsers(users=[]) {
  const cleaned = Array.isArray(users) ? structuredClone(users) : [];
  let primary = cleaned.find(u => Number(u.id) === PRIMARY_ADMIN_ID);
  if (!primary) primary = { id: PRIMARY_ADMIN_ID, name:'Primary Admin', username:process.env.ADMIN_USERNAME||'admin', role:'admin' };
  primary.id = PRIMARY_ADMIN_ID; primary.role='admin'; primary.username = process.env.ADMIN_USERNAME || primary.username || 'admin';
  const out=[primary];
  for(const u of cleaned){
    if(Number(u.id)===PRIMARY_ADMIN_ID) continue;
    const role=['cashier','baker','rider','customer'].includes(u.role)?u.role:'cashier';
    out.push({...u, role});
  }
  return out;
}
async function syncStaffAuth(client, users=[]) {
  const staff = users.filter(u => Number(u.id)!==PRIMARY_ADMIN_ID && ['cashier','baker','rider'].includes(u.role));
  const ids = staff.map(u=>Number(u.id));
  for(const u of staff){
    const existing = await client.query('SELECT id FROM auth_users WHERE id=$1',[u.id]);
    let hash = null;
    if (typeof u.password === 'string' && u.password.length >= 4) hash = await bcrypt.hash(u.password, 12);
    if(existing.rowCount){
      if(hash) await client.query(`UPDATE auth_users SET username=$2,password_hash=$3,role=$4,display_name=$5,active=true,updated_at=now() WHERE id=$1`,[u.id,u.username,hash,u.role,u.name||u.username]);
      else await client.query(`UPDATE auth_users SET username=$2,role=$3,display_name=$4,active=true,updated_at=now() WHERE id=$1`,[u.id,u.username,u.role,u.name||u.username]);
    } else if(hash){
      await client.query(`INSERT INTO auth_users(id,username,password_hash,role,display_name,active) VALUES($1,$2,$3,$4,$5,true)`,[u.id,u.username,hash,u.role,u.name||u.username]);
    }
  }
  if(ids.length) await client.query(`UPDATE auth_users SET active=false,updated_at=now() WHERE role<>'admin' AND NOT (id = ANY($1::bigint[]))`,[ids]);
  else await client.query(`UPDATE auth_users SET active=false,updated_at=now() WHERE role<>'admin'`);
}
function stripPasswords(state){
  const out=structuredClone(state||{});
  if(Array.isArray(out.users)) out.users=out.users.map(({password,...u})=>u);
  return out;
}
function recordId(x){ return x && x.id != null ? String(x.id) : null; }
function appendOnly(oldArr=[], submittedArr=[]){
  const old = Array.isArray(oldArr) ? structuredClone(oldArr) : [];
  const submitted = Array.isArray(submittedArr) ? submittedArr : [];
  const known = new Set(old.map(recordId).filter(Boolean));
  const additions = submitted.filter(x => { const id=recordId(x); return id && !known.has(id); }).map(x=>structuredClone(x));
  return [...additions, ...old];
}
function mergeExistingFields(oldArr=[], submittedArr=[], allowedFields=[]){
  const old = Array.isArray(oldArr) ? structuredClone(oldArr) : [];
  const submitted = Array.isArray(submittedArr) ? submittedArr : [];
  const incoming = new Map(submitted.map(x=>[recordId(x),x]));
  return old.map(item=>{
    const x=incoming.get(recordId(item)); if(!x) return item;
    const out={...item}; for(const f of allowedFields) if(Object.prototype.hasOwnProperty.call(x,f)) out[f]=structuredClone(x[f]);
    return out;
  });
}
function appendAndUpdate(oldArr=[], submittedArr=[], allowedFields=[]){
  const updated=mergeExistingFields(oldArr,submittedArr,allowedFields);
  const known=new Set(updated.map(recordId).filter(Boolean));
  const additions=(Array.isArray(submittedArr)?submittedArr:[]).filter(x=>{const id=recordId(x);return id&&!known.has(id)}).map(x=>structuredClone(x));
  return [...additions,...updated];
}
function stockOnly(oldArr=[], submittedArr=[]){
  return mergeExistingFields(oldArr,submittedArr,['stock']);
}

const PERMISSION_KEYS=['sales','expenses','customers','payments','production','delivery','waste','shifts','refunds'];
function defaultPermissions(role){
  const common={sales:true,expenses:true,customers:true,payments:true,production:false,delivery:false,waste:true,shifts:false,refunds:false};
  if(role==='cashier')return {...common,shifts:true,refunds:true};
  if(role==='baker')return {...common,production:true};
  if(role==='rider')return {...common,delivery:true};
  if(role==='admin')return Object.fromEntries(PERMISSION_KEYS.map(k=>[k,true]));
  return Object.fromEntries(PERMISSION_KEYS.map(k=>[k,false]));
}
function permissionsFor(oldState,username,role){
  if(role==='admin')return defaultPermissions('admin');
  const u=(oldState.users||[]).find(x=>x.username===username);
  const d=defaultPermissions(role),src=u?.permissions&&typeof u.permissions==='object'?u.permissions:{};
  return Object.fromEntries(PERMISSION_KEYS.map(k=>[k,src[k]===undefined?!!d[k]:!!src[k]]));
}
function mergeOwnRecords(oldArr=[],incomingArr=[],username,allowedFields=[]){
  const old=Array.isArray(oldArr)?structuredClone(oldArr):[],incoming=Array.isArray(incomingArr)?incomingArr:[],map=new Map(incoming.map(x=>[recordId(x),x]));
  const out=old.map(item=>{const x=map.get(recordId(item));if(!x||item.username!==username)return item;const n={...item};for(const f of allowedFields)if(Object.prototype.hasOwnProperty.call(x,f))n[f]=structuredClone(x[f]);return n});
  const known=new Set(out.map(recordId).filter(Boolean));for(const x of incoming){const id=recordId(x);if(id&&!known.has(id)&&x.username===username)out.unshift(structuredClone(x))}return out
}


function phoneKey(v){let s=String(v||'').replace(/\D/g,'');if(s.startsWith('256'))s='0'+s.slice(3);if(s.length===9&&s.startsWith('7'))s='0'+s;return s}
function newOrdersForSync(oldState,submitted,role,username){
  const known=new Set((oldState.orders||[]).map(recordId));
  const incoming=(submitted.orders||[]).filter(o=>recordId(o)&&!known.has(recordId(o)));
  if(role==='customer')return incoming.filter(o=>phoneKey(o.phone)===phoneKey(username));
  if(role==='admin')return incoming;
  const perm=permissionsFor(oldState,username,role);
  return perm.sales?incoming:[]
}
function validateNewOrderStock(oldState,submitted,role,username){
  const demand=new Map();
  for(const o of newOrdersForSync(oldState,submitted,role,username)){
    for(const i of (o.items||[])){
      const id=String(i.id),q=Math.max(0,Number(i.qty)||0);
      if(q)demand.set(id,(demand.get(id)||0)+q)
    }
  }
  const insufficient=[];
  for(const [id,qty] of demand){
    const p=(oldState.products||[]).find(x=>String(x.id)===id),available=Number(p?.stock)||0;
    if(qty>available+1e-9)insufficient.push({productId:id,name:p?.name||'Product',requested:qty,available})
  }
  return insufficient
}

function mergeForRole(oldState, submitted, role, username){
  if(role==='admin') return structuredClone(submitted);
  if(role==='customer'){
    const next=structuredClone(oldState||{}),incoming=submitted||{},mine=phoneKey(username);
    const oldIds=new Set((oldState.orders||[]).map(recordId));
    const newOwn=(incoming.orders||[]).filter(o=>recordId(o)&&!oldIds.has(recordId(o))&&phoneKey(o.phone)===mine).map(o=>structuredClone(o));

    next.orders=(oldState.orders||[]).map(old=>{
      const inc=(incoming.orders||[]).find(x=>String(x.id)===String(old.id));
      if(!inc||phoneKey(old.phone)!==mine)return old;
      const mayCancel=['Pending','Confirmed'].includes(old.status)&&inc.status==='Cancelled'&&String(inc.cancellationReason||'').trim();
      if(!mayCancel)return old;
      const out=structuredClone(old);
      out.status='Cancelled';out.cancellationReason=String(inc.cancellationReason).trim();out.cancelledAt=inc.cancelledAt||new Date().toISOString();out.cancelledBy='Customer';out.cancelledByName=inc.cancelledByName||old.customer||'Customer';out.balanceDue=0;out.paymentStatus=(Number(old.amountPaid)||0)>0?'Refund Pending':'Cancelled';
      const incomingTimeline=Array.isArray(inc.timeline)?inc.timeline:[],seen=new Set((old.timeline||[]).map(e=>String(e.id)));
      out.timeline=[...(old.timeline||[]),...incomingTimeline.filter(e=>!seen.has(String(e.id)))];
      return out;
    });
    next.orders=[...newOwn,...next.orders];

    next.products=structuredClone(oldState.products||[]);
    // New customer orders reduce current server stock.
    for(const o of newOwn)for(const i of (o.items||[])){const p=next.products.find(x=>String(x.id)===String(i.id));if(p)p.stock=(Number(p.stock)||0)-(Number(i.qty)||0)}
    // Newly cancelled customer orders restore stock exactly once.
    for(const old of (oldState.orders||[])){
      const inc=(incoming.orders||[]).find(x=>String(x.id)===String(old.id));
      if(!inc||phoneKey(old.phone)!==mine||!['Pending','Confirmed'].includes(old.status)||inc.status!=='Cancelled'||!String(inc.cancellationReason||'').trim())continue;
      for(const i of (old.items||[])){const p=next.products.find(x=>String(x.id)===String(i.id));if(p)p.stock=(Number(p.stock)||0)+(Number(i.qty)||0)}
    }
    // Customer-created profile/order data only; all master data stays server-owned.
    next.customers=appendOnly(oldState.customers||[],(incoming.customers||[]).filter(c=>phoneKey(c.phone)===mine));
    return next;
  }
  const next=structuredClone(oldState||{}),incoming=submitted||{},perm=permissionsFor(oldState,username,role);
  const allowedOrderFields=[];
  if(perm.sales)allowedOrderFields.push('status');
  if(perm.payments)allowedOrderFields.push('paymentStatus','amountPaid','balanceDue');
  if(perm.delivery)allowedOrderFields.push('deliveryStatus','rider','status');
  if(perm.refunds)allowedOrderFields.push('paymentStatus','balanceDue','refundedAmount','refundStatus');
  next.orders=perm.sales?appendAndUpdate(oldState.orders||[],incoming.orders||[],allowedOrderFields):mergeExistingFields(oldState.orders||[],incoming.orders||[],allowedOrderFields);
  next.expenses=perm.expenses?appendOnly(oldState.expenses||[],incoming.expenses||[]):structuredClone(oldState.expenses||[]);
  next.customers=perm.customers?appendOnly(oldState.customers||[],incoming.customers||[]):structuredClone(oldState.customers||[]);
  next.creditPayments=perm.payments?appendOnly(oldState.creditPayments||[],incoming.creditPayments||[]):structuredClone(oldState.creditPayments||[]);
  next.cashClosings=appendOnly(oldState.cashClosings||[],incoming.cashClosings||[]);
  next.cashierShifts=perm.shifts?mergeOwnRecords(oldState.cashierShifts||[],incoming.cashierShifts||[],username,['cashSales','cashCredit','cashExpenses','cashRefunds','expectedCash','actualCash','difference','closeNote','closedAt','status']):structuredClone(oldState.cashierShifts||[]);
  next.refunds=perm.refunds?appendOnly(oldState.refunds||[],incoming.refunds||[]):structuredClone(oldState.refunds||[]);
  next.wasteRecords=perm.waste?appendOnly(oldState.wasteRecords||[],incoming.wasteRecords||[]):structuredClone(oldState.wasteRecords||[]);
  next.stockMovements=appendOnly(oldState.stockMovements||[],incoming.stockMovements||[]);
  next.stockAdjustments=structuredClone(oldState.stockAdjustments||[]);
  next.customCakes=(perm.sales||perm.production)?appendAndUpdate(oldState.customCakes||[],incoming.customCakes||[],['status']):structuredClone(oldState.customCakes||[]);
  next.productionPlans=perm.production?appendAndUpdate(oldState.productionPlans||[],incoming.productionPlans||[],['status','startedAt','completedAt','ingredientCost','laborCost','energyCost','packagingCost','otherCost','totalProductionCost','unitProductionCost']):structuredClone(oldState.productionPlans||[]);

  // Derive permitted stock changes rather than trusting arbitrary staff master-data edits.
  next.products=structuredClone(oldState.products||[]);
  next.materials=structuredClone(oldState.materials||[]);
  const dec=(arr,id,qty)=>{const item=arr.find(x=>String(x.id)===String(id));if(item)item.stock=Math.max(0,(Number(item.stock)||0)-(Number(qty)||0))};
  const inc=(arr,id,qty)=>{const item=arr.find(x=>String(x.id)===String(id));if(item)item.stock=(Number(item.stock)||0)+(Number(qty)||0)};

  if(perm.sales){
    const known=new Set((oldState.orders||[]).map(recordId));
    for(const o of (incoming.orders||[]).filter(x=>recordId(x)&&!known.has(recordId(x))))for(const i of (o.items||[]))dec(next.products,i.id,i.qty);
  }
  if(perm.waste){
    const known=new Set((oldState.wasteRecords||[]).map(recordId));
    for(const w of (incoming.wasteRecords||[]).filter(x=>recordId(x)&&!known.has(recordId(x))))dec(w.itemType==='material'?next.materials:next.products,w.itemId,w.quantity);
  }
  if(perm.refunds){
    const known=new Set((oldState.refunds||[]).map(recordId));
    for(const r of (incoming.refunds||[]).filter(x=>recordId(x)&&!known.has(recordId(x))&&x.restock))inc(next.products,r.productId,r.qty);
  }
  if(perm.production){
    // Production is a controlled exception: accept stock quantities generated by the production workflow.
    next.products=stockOnly(next.products,incoming.products||[]);
    next.materials=stockOnly(next.materials,incoming.materials||[]);
  }
  return next;
}
app.get('/api/health', async (_req,res)=>{ const row=await getStateRow(); res.json({ok:true,service:'ds-bakery',revision:Number(row.revision),liveClients:liveClients.size,time:new Date().toISOString()}); });
app.get('/api/events', requireAuth, async(req,res)=>{
  res.setHeader('Content-Type','text/event-stream');
  res.setHeader('Cache-Control','no-cache, no-transform');
  res.setHeader('Connection','keep-alive');
  res.setHeader('X-Accel-Buffering','no');
  res.flushHeaders?.();
  const row=await getStateRow();
  const client={res,user:req.user,deviceId:req.headers['x-device-id']||null};
  liveClients.add(client);
  sendLive(res,'hello',{revision:Number(row.revision),time:new Date().toISOString()});
  const heartbeat=setInterval(()=>{try{res.write(`: heartbeat ${Date.now()}\n\n`)}catch{}},25000);
  req.on('close',()=>{clearInterval(heartbeat);liveClients.delete(client)});
});

app.post('/api/auth/register-customer', loginLimiter, async (req,res)=>{
  const name=String(req.body?.name||'').trim(),phone=String(req.body?.phone||'').replace(/\s+/g,''),password=String(req.body?.password||'');
  if(!name||!phone||!password)return res.status(400).json({error:'name_phone_password_required'});
  if(password.length<6)return res.status(400).json({error:'password_minimum_6_characters'});
  const existing=await pool.query('SELECT id FROM auth_users WHERE username=$1',[phone]);
  if(existing.rowCount)return res.status(409).json({error:'account_exists'});
  const id=Date.now();const hash=await bcrypt.hash(password,12);
  await pool.query(`INSERT INTO auth_users(id,username,password_hash,role,display_name,active) VALUES($1,$2,$3,'customer',$4,true)`,[id,phone,hash,name]);
  const user={id,username:phone,role:'customer',display_name:name};const token=issueToken(user);
  await writeAudit(pool,user,'auth.customer.registered',{},req.headers['x-device-id']||null,clientIp(req));
  res.status(201).json({token,user:{id:Number(id),username:phone,role:'customer',name}});
});

app.post('/api/auth/login', loginLimiter, async (req,res)=>{
  const {username,password}=req.body||{};
  if(!username||!password) return res.status(400).json({error:'username_and_password_required'});
  const user=await authenticate(String(username),String(password));
  if(!user){ await writeAudit(pool,null,'auth.login.failed',{username:String(username)},req.headers['x-device-id']||null,clientIp(req)); return res.status(401).json({error:'invalid_credentials'}); }
  const token=issueToken(user);
  await writeAudit(pool,user,'auth.login.success',{},req.headers['x-device-id']||null,clientIp(req));
  res.json({token,user:{id:Number(user.id),username:user.username,role:user.role,name:user.display_name}});
});
app.get('/api/auth/me', requireAuth, (req,res)=>res.json({user:{id:Number(req.user.id),username:req.user.username,role:req.user.role,name:req.user.display_name}}));
app.post('/api/auth/change-password', requireAuth, async(req,res)=>{
  const {currentPassword,newPassword}=req.body||{};
  if(!newPassword || String(newPassword).length<8) return res.status(400).json({error:'new_password_minimum_8_characters'});
  const user=await authenticate(req.user.username,String(currentPassword||''));
  if(!user) return res.status(401).json({error:'current_password_incorrect'});
  const hash=await bcrypt.hash(String(newPassword),12);
  await pool.query('UPDATE auth_users SET password_hash=$2,updated_at=now() WHERE id=$1',[req.user.id,hash]);
  await writeAudit(pool,req.user,'auth.password.changed',{},req.headers['x-device-id']||null,clientIp(req));
  res.json({ok:true});
});

app.get('/api/state/meta', requireAuth, async(_req,res)=>{ res.set('Cache-Control','no-store');const row=await getStateRow(); res.json({revision:Number(row.revision),updatedAt:row.updated_at}); });
app.get('/api/state', requireAuth, async(_req,res)=>{ res.set('Cache-Control','no-store');const row=await getStateRow(); res.json({revision:Number(row.revision),updatedAt:row.updated_at,state:row.data}); });
app.put('/api/state', requireAuth, async(req,res)=>{
  const submitted=req.body?.state ?? req.body;
  const deviceId=req.body?.deviceId || req.headers['x-device-id'] || null;
  const baseRevision=Number(req.body?.baseRevision);
  if(!submitted || typeof submitted!=='object') return res.status(400).json({error:'state_required'});
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const {rows}=await client.query('SELECT revision,data FROM app_state WHERE id=1 FOR UPDATE');
    const currentRevision=Number(rows[0]?.revision||0),oldState=rows[0]?.data||{};

    // The Primary Admin can edit anything, so stale full-state admin writes are rejected
    // instead of silently overwriting sales or stock uploaded by another device.
    if(req.user.role==='admin' && Number.isFinite(baseRevision) && baseRevision!==currentRevision){
      await client.query('ROLLBACK');
      return res.status(409).json({error:'revision_conflict',currentRevision,message:'Another device changed the shared data before this admin update.'});
    }

    // Atomic server-side stock validation serializes simultaneous sales.
    const insufficient=validateNewOrderStock(oldState,submitted,req.user.role,req.user.username);
    if(insufficient.length){
      await client.query('ROLLBACK');
      return res.status(409).json({error:'insufficient_stock',currentRevision,items:insufficient,message:'One or more products no longer have enough shared stock.'});
    }

    let next=mergeForRole(oldState,submitted,req.user.role,req.user.username);
    next.users=normalizeUsers(next.users||oldState.users||[]);
    if(req.user.role==='admin') await syncStaffAuth(client,next.users);
    const changed=changedKeys(oldState,next),stored=stripPasswords(next),revision=currentRevision+1;
    await client.query('UPDATE app_state SET revision=$1,data=$2,updated_at=now() WHERE id=1',[revision,stored]);
    await writeAudit(client,req.user,'state.update',{changedKeys:changed,revision,baseRevision:Number.isFinite(baseRevision)?baseRevision:null},deviceId,clientIp(req));
    await client.query('COMMIT');

    const event={revision,changedKeys:changed,actor:req.user.username,role:req.user.role,deviceId,time:new Date().toISOString()};
    broadcastState(event);
    res.json({ok:true,revision,changedKeys:changed});
  }catch(e){
    try{await client.query('ROLLBACK')}catch{}
    console.error(e);res.status(500).json({error:'state_update_failed'})
  }finally{client.release()}
});
app.get('/api/audit', requireAuth, requireRole('admin'), async(req,res)=>{
  const limit=Math.min(500,Math.max(1,Number(req.query.limit||100)));
  const {rows}=await pool.query(`SELECT id,created_at,actor_id,actor_username,actor_role,action,details,device_id,ip FROM audit_log ORDER BY id DESC LIMIT $1`,[limit]);
  res.json({items:rows});
});

app.post('/api/payments/request', requireAuth, requireRole('admin','cashier','baker','rider'), async(req,res)=>{
  const provider=String(req.body?.provider||'').toLowerCase();
  const phone=String(req.body?.phone||'').replace(/\s+/g,'');
  const amount=Number(req.body?.amount||0);
  const orderId=req.body?.orderId?String(req.body.orderId):null;
  if(!['mtn','airtel'].includes(provider)||!phone||amount<=0) return res.status(400).json({error:'invalid_payment_request'});
  const id=crypto.randomUUID();
  const mode=(process.env.PAYMENTS_MODE||'demo').toLowerCase();
  if(mode!=='live'){
    await pool.query(`INSERT INTO payment_transactions(id,provider,order_id,phone,amount,currency,status,provider_payload,created_by) VALUES($1,$2,$3,$4,$5,'UGX','DEMO_PENDING',$6,$7)`,[id,provider,orderId,phone,amount,{mode:'demo'},req.user.id]);
    await writeAudit(pool,req.user,'payment.request.demo',{id,provider,amount,phone},req.headers['x-device-id']||null,clientIp(req));
    return res.json({id,status:'DEMO_PENDING',demo:true,message:'Backend is in demo payment mode.'});
  }
  if(provider==='airtel') return res.status(503).json({error:'airtel_not_configured',message:'Airtel live adapter requires your merchant onboarding endpoints and credentials.'});
  try{
    const result=await requestMtnPayment({phone,amount,externalId:orderId||id});
    await pool.query(`INSERT INTO payment_transactions(id,provider,order_id,phone,amount,currency,status,provider_reference,provider_payload,created_by) VALUES($1,'mtn',$2,$3,$4,$5,'PENDING',$6,$7,$8)`,[id,orderId,phone,amount,process.env.MTN_CURRENCY||'UGX',result.reference,result.payload,req.user.id]);
    await writeAudit(pool,req.user,'payment.request.mtn',{id,reference:result.reference,amount,phone},req.headers['x-device-id']||null,clientIp(req));
    res.json({id,status:'PENDING',reference:result.reference,demo:false});
  }catch(e){ res.status(502).json({error:'mtn_request_failed',message:e.message}); }
});
app.get('/api/payments/:id', requireAuth, async(req,res)=>{
  const {rows}=await pool.query('SELECT * FROM payment_transactions WHERE id=$1',[req.params.id]);
  const tx=rows[0]; if(!tx) return res.status(404).json({error:'payment_not_found'});
  if(tx.provider==='mtn' && tx.provider_reference && (process.env.PAYMENTS_MODE||'demo').toLowerCase()==='live'){
    try{
      const status=await checkMtnPayment(tx.provider_reference);
      const normalized=String(status.status||status.Status||'PENDING').toUpperCase();
      await pool.query('UPDATE payment_transactions SET status=$2,provider_payload=$3,updated_at=now() WHERE id=$1',[tx.id,normalized,status]);
      tx.status=normalized; tx.provider_payload=status;
    }catch(e){ tx.status_check_error=e.message; }
  }
  res.json({id:tx.id,provider:tx.provider,orderId:tx.order_id,phone:tx.phone,amount:Number(tx.amount),currency:tx.currency,status:tx.status,reference:tx.provider_reference,payload:tx.provider_payload});
});
app.post('/api/payments/:id/demo-success', requireAuth, requireRole('admin','cashier','baker','rider'), async(req,res)=>{
  if((process.env.PAYMENTS_MODE||'demo').toLowerCase()==='live') return res.status(400).json({error:'not_available_in_live_mode'});
  const {rowCount}=await pool.query(`UPDATE payment_transactions SET status='SUCCESSFUL',updated_at=now() WHERE id=$1`,[req.params.id]);
  if(!rowCount) return res.status(404).json({error:'payment_not_found'});
  await writeAudit(pool,req.user,'payment.demo.success',{id:req.params.id},req.headers['x-device-id']||null,clientIp(req));
  res.json({ok:true,status:'SUCCESSFUL'});
});
app.all('/api/payments/mtn/callback', async(req,res)=>{
  await writeAudit(pool,null,'payment.mtn.callback',{body:req.body||{},query:req.query||{}},req.headers['x-device-id']||null,clientIp(req));
  res.status(200).json({ok:true});
});

app.use(express.static(frontendDir, { extensions:['html'] }));
app.get('*',(req,res)=>{ if(req.path.startsWith('/api/')) return res.status(404).json({error:'not_found'}); res.sendFile(path.join(frontendDir,'index.html')); });

app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({error:'server_error'}); });
app.listen(port,()=>console.log(`D's Bakery backend listening on :${port}`));
