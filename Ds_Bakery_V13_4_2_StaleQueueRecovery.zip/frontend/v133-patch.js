/* D's Bakery V13.3 feature patch: production costing, customer-auth ordering, admin-only receipt printing */
(() => {
  const byId = id => document.getElementById(id);
  const adminCanPrint = () => !!state.session && state.session.role === 'admin';

  // ----- CUSTOMER LOGIN REQUIRED BEFORE ORDERING -----
  const originalCheckout = window.checkout;
  window.checkout = function(){
    if(state.session?.role !== 'customer'){
      byId('modalBackdrop')?.classList.remove('hidden');
      return toast('Please login or create a customer account before ordering.');
    }
    return originalCheckout();
  };
  if(byId('checkoutBtn')) byId('checkoutBtn').onclick = window.checkout;

  const originalCustomCake = window.customCake;
  window.customCake = function(){
    if(state.session?.role !== 'customer'){
      byId('modalBackdrop')?.classList.remove('hidden');
      return toast('Please login or create a customer account before requesting a cake.');
    }
    byId('cakeCustomer').value = state.session.name || '';
    byId('cakePhone').value = state.session.username || '';
    return originalCustomCake();
  };
  if(byId('cakeOrderBtn')) byId('cakeOrderBtn').onclick = window.customCake;

  // Server-backed customer registration so the same account works on every phone.
  window.registerCustomer = async function(){
    const name=byId('regName').value.trim(), phone=normalizedPhone(byId('regPhone').value), password=byId('regPassword').value;
    if(!name||!phone||!password) return toast('Complete registration.');
    if(password.length<6) return toast('Customer password must be at least 6 characters.');
    if(!state.cloud?.url) return toast('Internet connection is required to create a customer account.');
    try{
      const r=await fetch(state.cloud.url.replace(/\/$/,'')+'/auth/register-customer',{
        method:'POST',headers:{'Content-Type':'application/json','X-Device-Id':deviceId()},
        body:JSON.stringify({name,phone,password})
      });
      const d=await r.json().catch(()=>({}));
      if(!r.ok){
        if(r.status===409) return toast('A customer account already exists for this phone. Please login.');
        return toast('Customer registration failed. Please try again.');
      }
      setCloudToken(d.token);
      state.session={id:Number(d.user.id),name:d.user.name,username:d.user.username,role:'customer'};
      let u=state.users.find(x=>Number(x.id)===state.session.id || normalizedPhone(x.username)===phone);
      if(u) Object.assign(u,{name,username:phone,password,role:'customer'});
      else state.users.push({id:state.session.id,name,username:phone,password,role:'customer'});
      upsertCustomer(name,phone); localSave(); byId('modalBackdrop').classList.add('hidden');
      await cloudPull(true); renderAll(); startCloudPolling(); toast('Account created. You can now order.');
    }catch(e){ toast('Could not reach the server. Please check internet and try again.'); }
  };
  if(byId('registerBtn')) byId('registerBtn').onclick = window.registerCustomer;

  function enforceCustomerIdentity(){
    const customer=state.session?.role==='customer';
    if(byId('customerName')){byId('customerName').value=customer?(state.session.name||''):'';byId('customerName').readOnly=customer;}
    if(byId('customerPhone')){byId('customerPhone').value=customer?(state.session.username||''):'';byId('customerPhone').readOnly=customer;}
    if(byId('checkoutBtn')) byId('checkoutBtn').textContent=customer?'Checkout':'Login to Order';
    if(byId('cakeCustomer')){byId('cakeCustomer').value=customer?(state.session.name||''):'';byId('cakeCustomer').readOnly=customer;}
    if(byId('cakePhone')){byId('cakePhone').value=customer?(state.session.username||''):'';byId('cakePhone').readOnly=customer;}
  }

  // ----- ADMIN-ONLY RECEIPT PRINTING -----
  const originalShowReceipt = window.showReceipt;
  window.showReceipt = function(id){
    originalShowReceipt(id);
    const b=byId('printReceiptBtn');
    if(b){b.classList.toggle('hidden',!adminCanPrint());b.disabled=!adminCanPrint();b.textContent='Print Receipt (Admin Only)';}
  };
  byId('printReceiptBtn') && (byId('printReceiptBtn').onclick = () => {
    if(!adminCanPrint()) return toast('Only the Primary Admin can print receipts.');
    window.print();
  });
  window.addEventListener('beforeprint', e=>{
    if(!adminCanPrint()){
      const receipt=byId('receiptContent');
      if(receipt){receipt.dataset.beforePrintDisplay=receipt.style.display||'';receipt.style.display='none';}
    }
  });
  window.addEventListener('afterprint',()=>{
    const receipt=byId('receiptContent'); if(receipt?.dataset.beforePrintDisplay!==undefined){receipt.style.display=receipt.dataset.beforePrintDisplay;delete receipt.dataset.beforePrintDisplay;}
  });

  // ----- PRODUCTION COSTING -----
  const prodForm=document.querySelector('.production-form');
  if(prodForm && !byId('productionLaborCost')){
    const btn=byId('addProductionBtn');
    const fields=[
      ['productionLaborCost','Labour cost (UGX)'],
      ['productionEnergyCost','Power / fuel cost (UGX)'],
      ['productionPackagingCost','Packaging cost (UGX)'],
      ['productionOtherCost','Other production cost (UGX)']
    ];
    fields.forEach(([id,placeholder])=>{const i=document.createElement('input');i.id=id;i.type='number';i.min='0';i.placeholder=placeholder;prodForm.insertBefore(i,btn);});
    btn.textContent='Plan Batch + Cost';
  }

  const originalRenderProduction = window.renderProduction;
  function enhanceProductionCosts(){
    const cards=[...document.querySelectorAll('#productionList .production-card')];
    cards.forEach((card,index)=>{
      const p=state.productionPlans[index]; if(!p || card.querySelector('.v133-cost-summary')) return;
      const rec=recipe(p.productId); const ingredient=Number(p.ingredientCost)||(rec?.yield?recipeBatchCost(p.productId)*(Number(p.qty)/Number(rec.yield)):0);
      const labor=Number(p.laborCost)||0, energy=Number(p.energyCost)||0, packaging=Number(p.packagingCost)||0, other=Number(p.otherCost)||0;
      const total=Number(p.totalProductionCost)||(ingredient+labor+energy+packaging+other), unit=Number(p.unitProductionCost)||(p.qty?total/Number(p.qty):0);
      const d=document.createElement('div'); d.className='v133-cost-summary';
      d.innerHTML=`<div class="subtle"><strong>Production Cost</strong></div><div class="cost-grid"><span>Ingredients <strong>${money.format(ingredient)}</strong></span><span>Labour <strong>${money.format(labor)}</strong></span><span>Power/Fuel <strong>${money.format(energy)}</strong></span><span>Packaging <strong>${money.format(packaging)}</strong></span><span>Other <strong>${money.format(other)}</strong></span><span>Total Batch <strong>${money.format(total)}</strong></span><span>Cost / Unit <strong>${money.format(unit)}</strong></span></div>`;
      const actions=card.querySelector('.order-actions'); actions?card.insertBefore(d,actions):card.appendChild(d);
    });
  }
  window.renderProduction = function(){ originalRenderProduction(); enhanceProductionCosts(); };

  window.addProduction = function(){
    if(!hasPerm('production')) return toast('You do not have production permission.');
    const pid=Number(byId('productionProduct').value), qty=Number(byId('productionQty').value), due=byId('productionDue').value;
    if(!pid||!qty||qty<=0||!due) return toast('Select product, quantity and due time.');
    const rec=recipe(pid), ingredientCost=rec?.yield?recipeBatchCost(pid)*(qty/rec.yield):0;
    const laborCost=Math.max(0,Number(byId('productionLaborCost')?.value)||0), energyCost=Math.max(0,Number(byId('productionEnergyCost')?.value)||0), packagingCost=Math.max(0,Number(byId('productionPackagingCost')?.value)||0), otherCost=Math.max(0,Number(byId('productionOtherCost')?.value)||0);
    const totalProductionCost=ingredientCost+laborCost+energyCost+packagingCost+otherCost, unitProductionCost=qty?totalProductionCost/qty:0, f=feasibility(pid,qty);
    state.productionPlans.unshift({id:uid(),productId:pid,qty,due,note:byId('productionNote').value.trim(),status:'Planned',createdAt:new Date().toISOString(),recordedBy:state.session.username,startedAt:null,completedAt:null,ingredientCost,laborCost,energyCost,packagingCost,otherCost,totalProductionCost,unitProductionCost});
    ['productionQty','productionDue','productionNote','productionLaborCost','productionEnergyCost','productionPackagingCost','productionOtherCost'].forEach(id=>{if(byId(id))byId(id).value='';});
    localSave(); renderAll(); toast(f.ok?'Production batch planned with cost estimate.':'Batch planned with cost estimate, but materials are currently insufficient.');
  };
  if(byId('addProductionBtn')) byId('addProductionBtn').onclick=window.addProduction;

  const originalCompleteProduction=window.completeProduction;
  window.completeProduction=function(id){
    const p=state.productionPlans.find(x=>x.id===id); if(p){
      const rec=recipe(p.productId); p.ingredientCost=rec?.yield?recipeBatchCost(p.productId)*(Number(p.qty)/Number(rec.yield)):0;
      p.laborCost=Math.max(0,Number(p.laborCost)||0);p.energyCost=Math.max(0,Number(p.energyCost)||0);p.packagingCost=Math.max(0,Number(p.packagingCost)||0);p.otherCost=Math.max(0,Number(p.otherCost)||0);
      p.totalProductionCost=p.ingredientCost+p.laborCost+p.energyCost+p.packagingCost+p.otherCost;p.unitProductionCost=p.qty?p.totalProductionCost/Number(p.qty):0;
    }
    const result=originalCompleteProduction(id); if(p){localSave();enhanceProductionCosts();} return result;
  };

  const originalRenderAll=window.renderAll;
  window.renderAll=function(){ const r=originalRenderAll(); enforceCustomerIdentity(); enhanceProductionCosts(); return r; };
  enforceCustomerIdentity(); enhanceProductionCosts();
})();

/* D's Bakery V13.4: Daily Production Cost & Financial Control */
(() => {
  const $id=id=>document.getElementById(id);
  const n=v=>Math.max(0,Number(v)||0);
  const materialBucket=name=>{
    const s=String(name||'').toLowerCase();
    if(/flour/.test(s)) return 'flour';
    if(/sugar/.test(s)) return 'sugar';
    if(/margarine|butter/.test(s)) return 'margarine';
    if(/yeast/.test(s)) return 'yeast';
    return 'otherIngredients';
  };

  // Split utilities into Gas, Fuel and Electricity for every new production batch.
  const prodForm=document.querySelector('.production-form');
  const oldEnergy=$id('productionEnergyCost');
  if(prodForm && oldEnergy){
    oldEnergy.placeholder='Electricity cost (UGX)'; oldEnergy.id='productionElectricityCost';
    [['productionGasCost','Gas cost (UGX)'],['productionFuelCost','Fuel cost (UGX)']].forEach(([id,ph])=>{
      if($id(id)) return; const i=document.createElement('input'); i.id=id;i.type='number';i.min='0';i.placeholder=ph;prodForm.insertBefore(i,$id('productionPackagingCost'));
    });
  }

  window.addProduction=function(){
    if(!hasPerm('production')) return toast('You do not have production permission.');
    const pid=Number($id('productionProduct').value),qty=Number($id('productionQty').value),due=$id('productionDue').value;
    if(!pid||!qty||qty<=0||!due) return toast('Select product, quantity and due time.');
    const rec=recipe(pid),ingredientCost=rec?.yield?recipeBatchCost(pid)*(qty/rec.yield):0;
    const laborCost=n($id('productionLaborCost')?.value),gasCost=n($id('productionGasCost')?.value),fuelCost=n($id('productionFuelCost')?.value),electricityCost=n($id('productionElectricityCost')?.value),packagingCost=n($id('productionPackagingCost')?.value),otherCost=n($id('productionOtherCost')?.value);
    const totalProductionCost=ingredientCost+laborCost+gasCost+fuelCost+electricityCost+packagingCost+otherCost,unitProductionCost=qty?totalProductionCost/qty:0,f=feasibility(pid,qty);
    state.productionPlans.unshift({id:uid(),productId:pid,qty,due,note:$id('productionNote').value.trim(),status:'Planned',createdAt:new Date().toISOString(),recordedBy:state.session.username,startedAt:null,completedAt:null,ingredientCost,laborCost,gasCost,fuelCost,electricityCost,packagingCost,otherCost,totalProductionCost,unitProductionCost});
    ['productionQty','productionDue','productionNote','productionLaborCost','productionGasCost','productionFuelCost','productionElectricityCost','productionPackagingCost','productionOtherCost'].forEach(id=>{if($id(id))$id(id).value='';});
    localSave();renderAll();toast(f.ok?'Production batch planned with full cost estimate.':'Batch planned, but materials are currently insufficient.');
  };
  if($id('addProductionBtn')) $id('addProductionBtn').onclick=window.addProduction;

  function ingredientBreakdown(plan){
    const out={flour:0,sugar:0,margarine:0,yeast:0,otherIngredients:0};
    const rec=recipe(plan.productId); if(!rec?.yield) return out;
    const factor=n(plan.qty)/n(rec.yield);
    (rec.items||[]).forEach(i=>{const m=material(i.materialId); if(!m)return; out[materialBucket(m.name)]+=n(m.cost)*n(i.qty)*factor;});
    return out;
  }
  function productionTotals(start,end){
    const t={flour:0,sugar:0,margarine:0,yeast:0,otherIngredients:0,labor:0,gas:0,fuel:0,electricity:0,packaging:0,otherProduction:0,ingredients:0,total:0,produced:0,batches:0};
    state.productionPlans.filter(p=>p.status==='Completed'&&dateInRange(p.completedAt||p.createdAt,start,end)).forEach(p=>{
      const b=ingredientBreakdown(p); Object.keys(b).forEach(k=>t[k]+=b[k]);
      t.labor+=n(p.laborCost);t.gas+=n(p.gasCost);t.fuel+=n(p.fuelCost);t.electricity+=n(p.electricityCost??p.energyCost);t.packaging+=n(p.packagingCost);t.otherProduction+=n(p.otherCost);t.produced+=n(p.qty);t.batches++;
    });
    t.ingredients=t.flour+t.sugar+t.margarine+t.yeast+t.otherIngredients;
    t.total=t.ingredients+t.labor+t.gas+t.fuel+t.electricity+t.packaging+t.otherProduction;
    return t;
  }
  function ensureDailyCostUI(){
    if($id('dailyCostPanel')) return;
    const reports=$id('reportsTab'); if(!reports)return;
    const panel=document.createElement('div');panel.id='dailyCostPanel';panel.className='card';
    panel.innerHTML=`<div class="section-head compact"><div><h3>Production Cost & Daily Financial Control</h3><div class="subtle">Automatically totals completed production batches for the selected report period. Production costs are kept separate from general expenses to prevent double counting.</div></div></div>
    <div class="report-grid" id="dailyCostGrid"></div>
    <div class="report-two-col"><div><h4>Ingredient & Production Costs</h4><div class="report-list" id="dailyCostList"></div></div><div><h4>Financial Summary</h4><div class="report-list" id="dailyFinanceList"></div></div></div>`;
    reports.appendChild(panel);
  }
  function renderDailyCosts(){
    ensureDailyCostUI(); if(!$id('dailyCostGrid'))return;
    const {start,end}=reportRange(),p=productionTotals(start,end),orders=state.orders.filter(o=>o.status!=='Cancelled'&&dateInRange(o.createdAt,start,end)),expenses=state.expenses.filter(e=>dateInRange(e.date,start,end));
    const sales=orders.reduce((s,o)=>s+n(o.total),0); const generalExpenses=expenses.reduce((s,e)=>s+n(e.amount),0); const net=sales-p.total-generalExpenses;
    const sold=orders.reduce((s,o)=>s+(o.items||[]).reduce((q,i)=>q+n(i.qty),0),0);
    const waste=(state.waste||[]).filter(w=>dateInRange(w.date||w.createdAt,start,end)&&w.status!=='Voided').reduce((s,w)=>s+n(w.qty),0);
    $id('dailyCostGrid').innerHTML=`<div class="stat soft"><span>Total Production Cost</span><strong>${money.format(p.total)}</strong></div><div class="stat soft"><span>Total Expenses</span><strong>${money.format(generalExpenses)}</strong></div><div class="stat soft"><span>Sales Revenue</span><strong>${money.format(sales)}</strong></div><div class="stat soft"><span>Net Profit</span><strong>${money.format(net)}</strong></div><div class="stat soft"><span>Items Produced</span><strong>${num.format(p.produced)}</strong></div><div class="stat soft"><span>Items Sold</span><strong>${num.format(sold)}</strong></div>`;
    const rows=[['Flour',p.flour],['Sugar',p.sugar],['Margarine',p.margarine],['Yeast',p.yeast],['Other Ingredients',p.otherIngredients],['Labour',p.labor],['Gas',p.gas],['Fuel',p.fuel],['Electricity',p.electricity],['Packaging',p.packaging],['Other Production Costs',p.otherProduction],['Total Ingredients',p.ingredients],['TOTAL PRODUCTION COST',p.total]];
    $id('dailyCostList').innerHTML=rows.map(([k,v])=>`<div class="mini-row"><span>${k}</span><strong>${money.format(v)}</strong></div>`).join('');
    $id('dailyFinanceList').innerHTML=`<div class="mini-row"><span>Completed Batches</span><strong>${p.batches}</strong></div><div class="mini-row"><span>Items Produced</span><strong>${num.format(p.produced)}</strong></div><div class="mini-row"><span>Items Sold</span><strong>${num.format(sold)}</strong></div><div class="mini-row"><span>Waste</span><strong>${num.format(waste)}</strong></div><div class="mini-row"><span>Sales Revenue</span><strong>${money.format(sales)}</strong></div><div class="mini-row"><span>Production Cost</span><strong>${money.format(p.total)}</strong></div><div class="mini-row"><span>Other Expenses</span><strong>${money.format(generalExpenses)}</strong></div><div class="mini-row"><span>Net Profit</span><strong>${money.format(net)}</strong></div>`;
  }
  const prevRenderReports=window.renderReports;
  window.renderReports=function(){const r=prevRenderReports();renderDailyCosts();return r;};
  $id('reportPeriod')?.addEventListener('change',renderDailyCosts);
  renderDailyCosts();
})();
