const CACHE="ds-bakery-v13-4-2";
const ASSETS=["./","./index.html","./styles.css","./app.js","./v133-patch.js","./manifest.json","./logo.png","./icon-192.png","./icon-512.png","./apple-touch-icon.png"];

self.addEventListener("install",event=>{
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)));
});

self.addEventListener("activate",event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener("fetch",event=>{
  const req=event.request;
  if(req.method!=="GET") return;
  const url=new URL(req.url);
  const liveFile=url.origin===self.location.origin &&
    (url.pathname==="/" || url.pathname.endsWith("/index.html") ||
     url.pathname.endsWith("/app.js") || url.pathname.endsWith("/v133-patch.js") ||
     url.pathname.endsWith("/styles.css"));
  if(liveFile){
    event.respondWith(
      fetch(req).then(resp=>{
        const copy=resp.clone();
        caches.open(CACHE).then(cache=>cache.put(req,copy));
        return resp;
      }).catch(()=>caches.match(req))
    );
    return;
  }
  event.respondWith(caches.match(req).then(cached=>cached||fetch(req)));
});
