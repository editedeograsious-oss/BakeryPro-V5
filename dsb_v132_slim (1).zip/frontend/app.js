
const API_DEFAULT = location.protocol.startsWith("http") ? location.origin + "/api" : "";
const PRIMARY_ADMIN_ID=101;

const PERMISSION_KEYS=["sales","expenses","customers","payments","production","delivery","waste","shifts","refunds"];
const PERMISSION_LABELS={sales:"Record sales / POS",expenses:"Record expenses",customers:"Add customers",payments:"Receive payments",production:"Production operations",delivery:"Delivery updates",waste:"Record waste / damage",shifts:"Open & close cashier shifts",refunds:"Process returns / refunds"};
function roleDefaultPermissions(role){
  const common={sales:true,expenses:true,customers:true,payments:true,production:false,delivery:false,waste:true,shifts:false,refunds:false};
  if(role==="cashier")return {...common,shifts:true,refunds:true};
  if(role==="baker")return {...common,production:true};
  if(role==="rider")return {...common,delivery:true};
  if(role==="admin")return Object.fromEntries(PERMISSION_KEYS.map(k=>[k,true]));
  return Object.fromEntries(PERMISSION_KEYS.map(k=>[k,false]));
}
function normalizeUserPermissions(u){
  if(!u)return;
  if(u.id===PRIMARY_ADMIN_ID||u.role==="admin"){u.permissions=roleDefaultPermissions("admin");return}
  const defaults=roleDefaultPermissions(u.role),src=u.permissions&&typeof u.permissions==="object"?u.permissions:{};
  u.permissions=Object.fromEntries(PERMISSION_KEYS.map(k=>[k,src[k]===undefined?!!defaults[k]:!!src[k]]));
}
function currentStaffUser(){return state.users.find(u=>u.id===state.session?.id)||state.users.find(u=>u.username===state.session?.username)||null}
function hasPerm(key){
  if(can("admin"))return true;
  const u=currentStaffUser();if(!u||!isStaff())return false;normalizeUserPermissions(u);return !!u.permissions?.[key]
}

const deepClone=v=>typeof structuredClone==="function"?structuredClone(v):JSON.parse(JSON.stringify(v));
const seed={
 products:[{id:1,name:"White Bread",category:"Bread",price:5000,stock:20,emoji:"🍞"},{id:2,name:"Brown Bread",category:"Bread",price:6000,stock:15,emoji:"🥖"},{id:3,name:"Vanilla Cake",category:"Cake",price:45000,stock:6,emoji:"🎂"},{id:4,name:"Chocolate Cake",category:"Cake",price:55000,stock:5,emoji:"🍰"},{id:5,name:"Cupcake",category:"Pastry",price:3500,stock:30,emoji:"🧁"},{id:6,name:"Doughnut",category:"Snack",price:2500,stock:35,emoji:"🍩"},{id:7,name:"Meat Pie",category:"Snack",price:4000,stock:18,emoji:"🥧"},{id:8,name:"Croissant",category:"Pastry",price:4500,stock:12,emoji:"🥐"}],
 users:[{id:101,name:"System Admin",username:"admin",password:"admin123",role:"admin"},{id:102,name:"Front Cashier",username:"cashier",password:"cash123",role:"cashier"},{id:103,name:"Lead Baker",username:"baker",password:"bake123",role:"baker"},{id:104,name:"Delivery Rider",username:"rider",password:"ride123",role:"rider"}],
 orders:[],expenses:[],customCakes:[],productionPlans:[],materialPurchases:[],creditPayments:[],supplierPayments:[],customers:[],cashClosings:[],stockAdjustments:[],wasteRecords:[],cashierShifts:[],refunds:[],stockMovements:[],
 suppliers:[{id:301,name:"Kampala Flour Supplies",phone:"0700000001",email:"",address:"Kampala"},{id:302,name:"Fresh Farm Eggs",phone:"0700000002",email:"",address:"Wakiso"}],
 materials:[{id:201,name:"Wheat Flour",unit:"kg",stock:50,cost:4500,reorder:10},{id:202,name:"Sugar",unit:"kg",stock:20,cost:5000,reorder:5},{id:203,name:"Butter",unit:"kg",stock:8,cost:18000,reorder:2},{id:204,name:"Eggs",unit:"piece",stock:120,cost:500,reorder:30},{id:205,name:"Yeast",unit:"kg",stock:3,cost:22000,reorder:.5},{id:206,name:"Milk",unit:"litre",stock:15,cost:4500,reorder:4},{id:207,name:"Cooking Oil",unit:"litre",stock:10,cost:7500,reorder:3},{id:208,name:"Chocolate",unit:"kg",stock:5,cost:26000,reorder:1}],
 recipes:{
  "1":{yield:20,items:[{materialId:201,qty:10},{materialId:205,qty:.2},{materialId:202,qty:.5},{materialId:207,qty:.3}]},
  "2":{yield:20,items:[{materialId:201,qty:10},{materialId:205,qty:.2},{materialId:202,qty:.3},{materialId:207,qty:.25}]},
  "3":{yield:1,items:[{materialId:201,qty:.6},{materialId:202,qty:.4},{materialId:203,qty:.25},{materialId:204,qty:6},{materialId:206,qty:.3}]},
  "4":{yield:1,items:[{materialId:201,qty:.6},{materialId:202,qty:.45},{materialId:203,qty:.25},{materialId:204,qty:6},{materialId:206,qty:.3},{materialId:208,qty:.2}]},
  "5":{yield:12,items:[{materialId:201,qty:.7},{materialId:202,qty:.35},{materialId:203,qty:.2},{materialId:204,qty:4},{materialId:206,qty:.25}]},
  "6":{yield:20,items:[{materialId:201,qty:1.5},{materialId:202,qty:.3},{materialId:205,qty:.04},{materialId:207,qty:.5}]}
 },
 cloud:{url:API_DEFAULT,mode:"auto",revision:0}
};
const DataService={get:k=>JSON.parse(localStorage.getItem("bakerypro3_"+k)||"null"),set:(k,v)=>localStorage.setItem("bakerypro3_"+k,JSON.stringify(v)),ensure(){for(const[k,v]of Object.entries(seed))if(this.get(k)===null)this.set(k,deepClone(v));},reset(){Object.keys(seed).forEach(k=>this.set(k,deepClone(seed[k])));localStorage.removeItem("bakerypro3_session");localStorage.removeItem("bakerypro3_cart");localStorage.removeItem("bakerypro3_posCart");}};DataService.ensure();
const state={};for(const k of Object.keys(seed))state[k]=DataService.get(k);state.cart=JSON.parse(localStorage.getItem("bakerypro3_cart")||"[]");state.posCart=JSON.parse(localStorage.getItem("bakerypro3_posCart")||"[]");state.session=JSON.parse(localStorage.getItem("bakerypro3_session")||"null");state.pendingCheckout=null;state.purchaseMaterialId=null;
let syncApplying=false;
let cloudPollTimer=null;
let syncStreamAbort=null;
let syncStreamRetryTimer=null;
let syncBusy=false;
const OUTBOX_KEY="dsb_sync_outbox_v13";
const cloudToken=()=>sessionStorage.getItem("dsb_cloud_token")||"";
const setCloudToken=t=>t?sessionStorage.setItem("dsb_cloud_token",t):sessionStorage.removeItem("dsb_cloud_token");
function deviceId(){let id=localStorage.getItem("dsb_device_id");if(!id){id=(crypto.randomUUID?crypto.randomUUID():"dev-"+Date.now()+"-"+Math.random().toString(16).slice(2));localStorage.setItem("dsb_device_id",id)}return id}
function getOutbox(){try{const x=JSON.parse(localStorage.getItem(OUTBOX_KEY)||"[]");return Array.isArray(x)?x:[]}catch{return[]}}
function saveOutbox(x){localStorage.setItem(OUTBOX_KEY,JSON.stringify(Array.isArray(x)?x:[]));updateSyncMini()}
function outboxCount(){return getOutbox().length}
function updateSyncMini(label=null){
  const el=$("syncMini");if(!el)return;
  if(label){el.textContent=label;return}
  const n=outboxCount();
  el.textContent=!navigator.onLine?(n?`Offline · ${n} pending`:"Offline"):(n?`${n} pending`:(cloudToken()?"Synced":"Offline"))
}
function queueSyncSnapshot(){
  if(syncApplying||!cloudToken()||!state.cloud?.url||state.cloud?.mode!=="auto")return;
  const current=getOutbox(),baseRevision=current[0]?.baseRevision??Number(state.cloud?.revision||0);
  const item={id:current[0]?.id||("sync-"+Date.now()),createdAt:current[0]?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString(),baseRevision,state:snapshot()};
  saveOutbox([item]);
  setCloud(`Pending synchronization · ${new Date(item.updatedAt).toLocaleTimeString()}`,navigator.onLine?"pending":"offline");
}

function enforceSingleAdmin(){
 let primary=state.users.find(u=>u.id===PRIMARY_ADMIN_ID);
 if(!primary){primary={id:PRIMARY_ADMIN_ID,name:"System Admin",username:"admin",password:"admin123",role:"admin"};state.users.unshift(primary)}
 primary.role="admin";
 state.users.forEach(u=>{if(u.id!==PRIMARY_ADMIN_ID&&u.role==="admin")u.role="cashier";normalizeUserPermissions(u)});normalizeUserPermissions(primary);
 if(state.session?.id===PRIMARY_ADMIN_ID)state.session={id:primary.id,name:primary.name,username:primary.username,role:"admin"};
 else if(state.session?.role==="admin")state.session=null;
}
enforceSingleAdmin();DataService.set("users",state.users);state.session?localStorage.setItem("bakerypro3_session",JSON.stringify(state.session)):localStorage.removeItem("bakerypro3_session");
const $=id=>document.getElementById(id),money=new Intl.NumberFormat("en-UG",{style:"currency",currency:"UGX",maximumFractionDigits:0}),num=new Intl.NumberFormat("en-UG",{maximumFractionDigits:3}),uid=()=>Date.now()+Math.floor(Math.random()*10000);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));const can=(...r)=>state.session&&r.includes(state.session.role);const isStaff=()=>!!state.session&&["admin","cashier","baker","rider"].includes(state.session.role);
function toast(m){const t=$("toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function localSave(){enforceSingleAdmin();for(const k of Object.keys(seed))DataService.set(k,state[k]);localStorage.setItem("bakerypro3_cart",JSON.stringify(state.cart));localStorage.setItem("bakerypro3_posCart",JSON.stringify(state.posCart));state.session?localStorage.setItem("bakerypro3_session",JSON.stringify(state.session)):localStorage.removeItem("bakerypro3_session");if(!syncApplying&&state.cloud?.mode==="auto"&&cloudToken()){queueSyncSnapshot();queueMicrotask(()=>flushSyncOutbox(true))}}
function snapshot(){return {version:13.1,updatedAt:new Date().toISOString(),products:state.products,users:state.users,orders:state.orders,expenses:state.expenses,customCakes:state.customCakes,productionPlans:state.productionPlans,materialPurchases:state.materialPurchases,materials:state.materials,recipes:state.recipes,suppliers:state.suppliers,creditPayments:state.creditPayments,supplierPayments:state.supplierPayments,customers:state.customers,cashClosings:state.cashClosings,stockAdjustments:state.stockAdjustments,wasteRecords:state.wasteRecords,cashierShifts:state.cashierShifts,refunds:state.refunds,stockMovements:state.stockMovements};}
function product(id){return state.products.find(x=>x.id===Number(id))}function material(id){return state.materials.find(x=>x.id===Number(id))}function recipe(pid){return state.recipes[String(pid)]||null}
function recipeBatchCost(pid){const r=recipe(pid);if(!r)return 0;return r.items.reduce((s,i)=>s+(material(i.materialId)?.cost||0)*i.qty,0)}
function recipeUnitCost(pid){const r=recipe(pid);return r&&r.yield?recipeBatchCost(pid)/r.yield:0}function marginPct(p){const c=recipeUnitCost(p.id);return p.price?((p.price-c)/p.price)*100:0}
function requirements(pid,qty){const r=recipe(pid);if(!r||!r.yield)return[];const factor=qty/r.yield;return r.items.map(i=>({materialId:i.materialId,qty:i.qty*factor}))}
function feasibility(pid,qty){const req=requirements(pid,qty);if(!req.length)return{ok:false,missing:["No recipe configured"]};const miss=req.filter(r=>(material(r.materialId)?.stock||0)+1e-9<r.qty).map(r=>`${material(r.materialId)?.name||"Material"}: need ${num.format(r.qty)}, have ${num.format(material(r.materialId)?.stock||0)}`);return{ok:!miss.length,missing:miss}}

function orderReceived(o){
  if(Number.isFinite(Number(o.amountPaid)))return Number(o.amountPaid);
  if(o.paymentStatus==="Paid")return Number(o.total)||0;
  if(o.source==="pos"&&o.paymentMethod==="Cash")return Number(o.total)||0;
  return 0
}
function orderBalance(o){
  if(Number.isFinite(Number(o.balanceDue)))return Math.max(0,Number(o.balanceDue));
  if(["Credit","Part Paid"].includes(o.paymentStatus))return Math.max(0,(Number(o.total)||0)-orderReceived(o));
  return 0
}
function supplierById(id){return state.suppliers.find(s=>s.id===Number(id))}
function supplierBalance(id){
  const purchases=state.materialPurchases.filter(p=>Number(p.supplierId)===Number(id)).reduce((s,p)=>s+(Number(p.totalCost)||0),0);
  const payments=state.supplierPayments.filter(p=>Number(p.supplierId)===Number(id)).reduce((s,p)=>s+(Number(p.amount)||0),0);
  return Math.max(0,purchases-payments)
}
function totalReceivables(){return state.orders.reduce((s,o)=>s+orderBalance(o),0)}
function totalPayables(){return state.suppliers.reduce((s,sup)=>s+supplierBalance(sup.id),0)}
function dateInRange(iso,start,end){const d=new Date(iso);return(!start||d>=start)&&(!end||d<end)}
function reportRange(){
  const v=$("reportPeriod")?.value||"month",now=new Date(),start=new Date(now),end=new Date(now);
  if(v==="all")return{start:null,end:null,label:"All Time"};
  if(v==="today"){start.setHours(0,0,0,0);end.setDate(start.getDate()+1);end.setHours(0,0,0,0);return{start,end,label:"Today"}}
  if(v==="7days"){start.setDate(now.getDate()-6);start.setHours(0,0,0,0);end.setDate(now.getDate()+1);end.setHours(0,0,0,0);return{start,end,label:"Last 7 Days"}}
  if(v==="lastmonth"){start.setDate(1);start.setMonth(now.getMonth()-1);start.setHours(0,0,0,0);end.setDate(1);end.setMonth(now.getMonth());end.setHours(0,0,0,0);return{start,end,label:"Last Month"}}
  start.setDate(1);start.setHours(0,0,0,0);end.setMonth(now.getMonth()+1,1);end.setHours(0,0,0,0);return{start,end,label:"This Month"}
}




function localDateKey(d=new Date()){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${day}`}
function dateBounds(key){const s=new Date(`${key}T00:00:00`),e=new Date(s);e.setDate(e.getDate()+1);return{s,e}}
function customerProfile(phone){return state.customers.find(c=>normalizedPhone(c.phone)===normalizedPhone(phone))||null}
function customerCreditLimit(phone){return Math.max(0,Number(customerProfile(phone)?.creditLimit)||0)}
function customerCreditDays(phone){return Math.max(1,Number(customerProfile(phone)?.creditDays)||7)}
function customerNextDue(phone){const ds=customerOrders(phone).filter(o=>orderBalance(o)>0&&o.dueDate).map(o=>new Date(o.dueDate)).filter(d=>!Number.isNaN(d.getTime())).sort((a,b)=>a-b);return ds[0]||null}
function isOverdueOrder(o){return orderBalance(o)>0&&o.dueDate&&new Date(o.dueDate)<new Date()}
function dailyClosingSummary(key=localDateKey()){
  const {s,e}=dateBounds(key);
  const orders=state.orders.filter(o=>o.status!=="Cancelled"&&new Date(o.createdAt)>=s&&new Date(o.createdAt)<e);
  const payments=state.creditPayments.filter(p=>new Date(p.date)>=s&&new Date(p.date)<e);
  const expenses=state.expenses.filter(x=>new Date(x.date)>=s&&new Date(x.date)<e);
  const receivedBy=(method)=>orders.filter(o=>o.paymentMethod===method).reduce((a,o)=>a+orderReceived(o),0)+payments.filter(p=>(p.paymentMethod||"Cash")===method).reduce((a,p)=>a+(Number(p.amount)||0),0);
  const cashSales=receivedBy("Cash"),mobile=receivedBy("MTN Mobile Money")+receivedBy("Airtel Money"),card=receivedBy("Card");
  const cashExpenses=expenses.filter(x=>(x.paymentMethod||"Cash")==="Cash").reduce((a,x)=>a+(Number(x.amount)||0),0),cashRefunds=state.refunds.filter(r=>r.status!=="Voided"&&r.paymentMethod==="Cash"&&new Date(r.createdAt)>=s&&new Date(r.createdAt)<e).reduce((a,r)=>a+(Number(r.amount)||0),0);
  const creditIssued=orders.filter(o=>o.paymentMethod==="Credit").reduce((a,o)=>a+Math.max(0,(Number(o.total)||0)-(Number(o.initialPaid)||0)),0);
  return{date:key,cashSales,mobile,card,cashExpenses,cashRefunds,creditIssued,expectedCash:cashSales-cashExpenses-cashRefunds,orders:orders.length}
}
function stockRecord(type,id){return type==="product"?product(id):material(id)}
function stockRecordName(type,id){return stockRecord(type,id)?.name||"Item"}
function wasteUnitCost(type,id){return type==="product"?recipeUnitCost(id):(material(id)?.cost||0)}

const MAIN_SECTION_MAP={
 dashboard:{title:"Dashboard",subtitle:"Business overview and today's priorities.",defaultPanel:"dashboardTab",subs:[]},
 sales:{title:"Sales / POS",subtitle:"Counter sales, cashier shifts, refunds and daily cash control.",defaultPanel:"posTab",subs:[["Point of Sale","posTab"],["Cashier Shifts","cashierShiftTab"],["Daily Closing","cashClosingTab"]]},
 expenses:{title:"Expenses",subtitle:"Record operating costs and monitor cash outflow.",defaultPanel:"expensesTab",subs:[]},
 stock:{title:"Stock",subtitle:"Finished products, materials, adjustments, waste and movement history.",defaultPanel:"inventoryTab",subs:[["Finished Products","inventoryTab"],["Raw Materials","materialsTab"],["Suppliers","suppliersTab"],["Stock Adjustments","stockAdjustmentTab"],["Waste & Damage","wasteTab"],["Movement Ledger","stockLedgerTab"]]},
 production:{title:"Production",subtitle:"Plan baking, manage orders and track deliveries.",defaultPanel:"productionTab",subs:[["Production Plan","productionTab"],["Orders","ordersTab"],["Delivery","deliveryTab"]]},
 recipes:{title:"Recipes & Costing",subtitle:"Control recipes, batch costs and product margins.",defaultPanel:"recipesTab",subs:[]},
 customers:{title:"Customers & Credit",subtitle:"Customer directory, order history and outstanding balances.",defaultPanel:"customersTab",subs:[["Customer Directory","customersTab"],["Credit & Debts","creditTab"]]},
 reports:{title:"Reports",subtitle:"Daily and monthly sales, expenses, credit and performance.",defaultPanel:"reportsTab",subs:[]},
 receipts:{title:"Receipts",subtitle:"Search, view and reprint sales receipts.",defaultPanel:"receiptsTab",subs:[]},
 staff:{title:"Staff",subtitle:"Employee accounts, permissions, audit trail, cloud sync and backups.",defaultPanel:"employeesTab",subs:[["Employees","employeesTab"],["Audit Trail","auditTab"],["Cloud & Backup","backupTab"]]}
};
let activeMainSection="dashboard";
function showPanel(panelId){document.querySelectorAll("#staffApp .tab-panel").forEach(p=>p.classList.add("hidden"));const p=$(panelId);if(p)p.classList.remove("hidden");document.querySelectorAll(".sub-nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.subpanel===panelId));if(panelId==="auditTab")renderAudit()}
function renderSubnav(sectionKey){const cfg=MAIN_SECTION_MAP[sectionKey],box=$("sectionSubnav");if(!cfg||!cfg.subs.length){box.innerHTML="";box.classList.add("hidden");return}box.innerHTML=cfg.subs.map(([label,id],i)=>`<button class="sub-nav-btn ${i===0?"active":""}" data-subpanel="${id}">${label}</button>`).join("");box.classList.remove("hidden")}
function openMainSection(key,panelId=null){const cfg=MAIN_SECTION_MAP[key];if(!cfg)return;activeMainSection=key;$("currentSectionTitle").textContent=cfg.title;$("currentSectionSubtitle").textContent=cfg.subtitle;renderSubnav(key);showPanel(panelId||cfg.defaultPanel);document.querySelectorAll("[data-main]").forEach(b=>b.classList.toggle("active",b.dataset.main===key));$("moreMenuBackdrop")?.classList.add("hidden");$("staffApp")?.scrollIntoView({behavior:"smooth",block:"start"})}
function normalizedPhone(v){return String(v||"").replace(/\s+/g,"").trim()}
function customerDirectory(){const map=new Map();const merge=(name,phone,extra={})=>{phone=normalizedPhone(phone);if(!phone)return;const cur=map.get(phone)||{id:extra.id||uid(),name:name||phone,phone,email:"",address:"",notes:"",creditLimit:0,creditDays:7,createdAt:extra.createdAt||new Date().toISOString()};Object.assign(cur,{name:name||cur.name,phone,email:extra.email??cur.email,address:extra.address??cur.address,notes:extra.notes??cur.notes,creditLimit:Number(extra.creditLimit??cur.creditLimit??0),creditDays:Number(extra.creditDays??cur.creditDays??7)});map.set(phone,cur)};state.customers.forEach(c=>merge(c.name,c.phone,c));state.users.filter(u=>u.role==="customer").forEach(u=>merge(u.name,u.username,{id:u.id}));state.orders.forEach(o=>merge(o.customer,o.phone));state.customCakes.forEach(c=>merge(c.customer,c.phone));return[...map.values()].sort((a,b)=>a.name.localeCompare(b.name))}
function upsertCustomer(name,phone,extra={}){phone=normalizedPhone(phone);if(!phone||name==="Walk-in")return;let c=state.customers.find(x=>normalizedPhone(x.phone)===phone);if(!c){c={id:uid(),name:name||phone,phone,email:"",address:"",notes:"",creditLimit:0,creditDays:7,createdAt:new Date().toISOString()};state.customers.push(c)}if(name)c.name=name;if(extra.email!==undefined)c.email=extra.email;if(extra.address!==undefined)c.address=extra.address;if(extra.notes!==undefined)c.notes=extra.notes;if(extra.creditLimit!==undefined)c.creditLimit=Math.max(0,Number(extra.creditLimit)||0);if(extra.creditDays!==undefined)c.creditDays=Math.max(1,Number(extra.creditDays)||7)}
function customerOrders(phone){phone=normalizedPhone(phone);return state.orders.filter(o=>normalizedPhone(o.phone)===phone)}
function customerCakes(phone){phone=normalizedPhone(phone);return state.customCakes.filter(o=>normalizedPhone(o.phone)===phone)}
function customerDebt(phone){return customerOrders(phone).reduce((s,o)=>s+orderBalance(o),0)}
function addCustomer(){if(!isStaff())return toast("Staff login required.");const name=$("newCustomerName").value.trim(),phone=normalizedPhone($("newCustomerPhone").value);if(!name||!phone)return toast("Enter customer name and phone.");const extra={email:$("newCustomerEmail").value.trim(),address:$("newCustomerAddress").value.trim()};if(can("admin")){extra.creditLimit=Math.max(0,Number($("newCustomerCreditLimit").value)||0);extra.creditDays=Math.max(1,Number($("newCustomerCreditDays").value)||7)}upsertCustomer(name,phone,extra);["newCustomerName","newCustomerPhone","newCustomerEmail","newCustomerAddress","newCustomerCreditLimit"].forEach(id=>{$(id).value=""});$("newCustomerCreditDays").value="7";localSave();renderCustomers();toast("Customer added.")}
function renderCustomers(){if(!$("customerList"))return;const q=$("customerSearch").value.toLowerCase().trim(),filter=$("customerFilter").value,all=customerDirectory(),list=all.filter(c=>{const orders=customerOrders(c.phone),debt=customerDebt(c.phone),match=!q||c.name.toLowerCase().includes(q)||c.phone.toLowerCase().includes(q);return match&&(filter==="all"||filter==="debt"&&debt>0||filter==="active"&&orders.length>0)});$("customerCount").textContent=all.length;$("customersWithDebt").textContent=all.filter(c=>customerDebt(c.phone)>0).length;$("customerDebtTotal").textContent=money.format(all.reduce((s,c)=>s+customerDebt(c.phone),0));$("customerList").innerHTML=list.length?list.map(c=>{const os=customerOrders(c.phone),spent=os.reduce((s,o)=>s+(Number(o.total)||0),0),debt=customerDebt(c.phone),limit=Number(c.creditLimit)||0,due=customerNextDue(c.phone),overdue=os.some(isOverdueOrder);return`<article class="customer-card ${overdue?"overdue-card":""}"><div class="customer-avatar">${esc((c.name||"C").charAt(0).toUpperCase())}</div><div class="customer-main"><strong>${esc(c.name)}</strong><span>${esc(c.phone)}</span><small>${os.length} order${os.length===1?"":"s"} · ${money.format(spent)} total · Limit ${money.format(limit)}</small>${due?`<small class="${overdue?"overdue-text":""}">${overdue?"Overdue":"Next due"}: ${due.toLocaleDateString()}</small>`:""}</div><div class="customer-debt ${debt>0?"has-debt":""}"><span>Balance</span><strong>${money.format(debt)}</strong></div><div class="inline-actions"><button class="small-btn" onclick="viewCustomer('${esc(c.phone)}')">View</button>${can("admin")?`<button class="small-btn" onclick="editCustomer(${c.id},'${esc(c.phone)}')">Edit</button><button class="small-btn danger-lite" onclick="deleteCustomer(${c.id},'${esc(c.phone)}')">Delete</button>`:""}</div></article>`}).join(""):`<div class="empty">No customers found.</div>`}
function viewCustomer(phone){const c=customerDirectory().find(x=>normalizedPhone(x.phone)===normalizedPhone(phone));if(!c)return;const os=customerOrders(c.phone),cakes=customerCakes(c.phone),spent=os.reduce((s,o)=>s+(Number(o.total)||0),0),paid=os.reduce((s,o)=>s+orderReceived(o),0),debt=customerDebt(c.phone),limit=Number(c.creditLimit)||0,due=customerNextDue(c.phone),overdue=os.filter(isOverdueOrder);$("customerDetailContent").innerHTML=`<span class="eyebrow">Customer Profile</span><h2>${esc(c.name)}</h2><div class="subtle">${esc(c.phone)}${c.email?` · ${esc(c.email)}`:""}${c.address?`<br>${esc(c.address)}`:""}</div><div class="profile-stats"><div><span>Orders</span><strong>${os.length}</strong></div><div><span>Total Sales</span><strong>${money.format(spent)}</strong></div><div><span>Credit Balance</span><strong>${money.format(debt)}</strong></div><div><span>Credit Limit</span><strong>${money.format(limit)}</strong></div><div><span>Credit Terms</span><strong>${Number(c.creditDays)||7} days</strong></div><div><span>Next Due</span><strong class="${overdue.length?"overdue-text":""}">${due?due.toLocaleDateString():"—"}</strong></div></div>${overdue.length?`<div class="credit-warning">${overdue.length} overdue credit sale${overdue.length===1?"":"s"}.</div>`:""}<h4>Order History</h4><div class="profile-history">${os.length?os.map(o=>`<button onclick="showReceipt(${o.id})"><span>#${String(o.id).slice(-6)} · ${new Date(o.createdAt).toLocaleDateString()}</span><strong>${money.format(o.total)}</strong><small>${esc(o.paymentStatus)}${o.dueDate?` · Due ${new Date(o.dueDate).toLocaleDateString()}`:""}</small></button>`).join(""):`<div class="empty">No sales yet.</div>`}</div>${cakes.length?`<h4>Custom Cakes</h4><div class="subtle">${cakes.map(x=>`${esc(x.flavor)} ${esc(x.size)} — ${esc(x.status)}`).join("<br>")}</div>`:""}`;$("customerBackdrop").classList.remove("hidden")}
function renderReceiptHistory(){if(!$("receiptHistoryList"))return;const q=$("receiptSearch").value.toLowerCase().trim(),date=$("receiptDate").value,pf=$("receiptPaymentFilter").value;const list=state.orders.filter(o=>{const hay=`${o.id} ${o.customer||""} ${o.phone||""}`.toLowerCase(),d=new Date(o.createdAt).toISOString().slice(0,10);return(!q||hay.includes(q))&&(!date||d===date)&&(pf==="all"||o.paymentStatus===pf)});$("receiptCount").textContent=list.length;$("receiptValue").textContent=money.format(list.reduce((s,o)=>s+(Number(o.total)||0),0));$("receiptHistoryList").innerHTML=list.length?list.map(o=>`<article class="receipt-history-card"><div class="receipt-number">#${String(o.id).slice(-8)}</div><div><strong>${esc(o.customer||"Walk-in")}</strong><span>${new Date(o.createdAt).toLocaleString()}</span><small>${esc(o.paymentMethod)} · ${esc(o.paymentStatus)}</small></div><div class="receipt-history-total">${money.format(o.total)}</div><div class="inline-actions"><button class="small-btn" onclick="showReceipt(${o.id})">View / Print</button>${can("admin")&&o.status!=="Cancelled"?`<button class="small-btn danger-lite" onclick="voidOrder(${o.id})">Void</button>`:""}${can("admin")?`<button class="small-btn danger-delete" onclick="deleteOrder(${o.id})">Delete</button>`:""}</div></article>`).join(""):`<div class="empty">No receipts found.</div>`}
function renderDashboard(){if(!$("dashTodaySales"))return;const now=new Date(),start=new Date(now);start.setHours(0,0,0,0);const todays=state.orders.filter(o=>new Date(o.createdAt)>=start&&o.status!=="Cancelled"),exp=state.expenses.filter(e=>new Date(e.date)>=start);$("dashDate").textContent=now.toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"short"});$("dashTodaySales").textContent=money.format(todays.reduce((s,o)=>s+orderReceived(o),0));$("dashTodayOrders").textContent=todays.length;$("dashTodayExpenses").textContent=money.format(exp.reduce((s,e)=>s+(Number(e.amount)||0),0));$("dashTodayCredit").textContent=money.format(todays.reduce((s,o)=>s+orderBalance(o),0));const lowM=state.materials.filter(m=>m.stock<=m.reorder),lowP=state.products.filter(p=>p.stock<=5),plans=state.productionPlans.filter(p=>["Planned","In Progress"].includes(p.status));const alerts=[];if(lowM.length)alerts.push(`<button data-main="stock" data-sub-open="materialsTab"><b>${lowM.length}</b><span>raw material${lowM.length===1?"":"s"} at reorder level</span></button>`);if(lowP.length)alerts.push(`<button data-main="stock"><b>${lowP.length}</b><span>finished product${lowP.length===1?"":"s"} low in stock</span></button>`);if(plans.length)alerts.push(`<button data-main="production"><b>${plans.length}</b><span>production batch${plans.length===1?"":"es"} pending</span></button>`);if(totalReceivables()>0)alerts.push(`<button data-main="customers" data-sub-open="creditTab"><b>${money.format(totalReceivables())}</b><span>customer credit outstanding</span></button>`);const overdue=state.orders.filter(isOverdueOrder);if(overdue.length)alerts.push(`<button data-main="customers" data-sub-open="creditTab"><b>${overdue.length}</b><span>overdue credit sale${overdue.length===1?"":"s"}</span></button>`);if(!state.cashClosings.some(c=>c.date===localDateKey()))alerts.push(`<button data-main="sales" data-sub-open="cashClosingTab"><b>!</b><span>today’s cash closing has not been submitted</span></button>`);$("dashAlerts").innerHTML=alerts.length?alerts.join(""):`<div class="all-clear">✓ No urgent items right now.</div>`}

function renderAuth(){const l=!!state.session;$("sessionBadge").textContent=l?`${state.session.name} · ${state.session.role}`:"Guest";$("loginBtn").classList.toggle("hidden",l);$("logoutBtn").classList.toggle("hidden",!l);const staff=l&&["admin","cashier","baker","rider"].includes(state.session.role);$("staffApp").classList.toggle("hidden",!staff);$("customerPortal").classList.toggle("hidden",!(l&&state.session.role==="customer"));document.querySelectorAll(".admin-only").forEach(e=>e.classList.toggle("hidden",!can("admin")));document.querySelectorAll(".admin-cashier").forEach(e=>e.classList.toggle("hidden",!can("admin","cashier")));document.querySelectorAll(".staff-add").forEach(e=>e.classList.toggle("hidden",!staff));document.querySelectorAll(".admin-baker").forEach(e=>e.classList.toggle("hidden",!can("admin","baker")));$("bottomNav")?.classList.toggle("hidden",!staff);if(staff)$("roleNote").innerHTML=can("admin")?`<strong>Primary Admin</strong><div class="admin-lock-note">Full control: prices, edits, deletions and business settings.</div>`:`Logged in as ${esc(state.session.role)} · you can add operational records, but only the Primary Admin can edit saved data or prices.`;renderCustomerOrders()}
function populateSelects(){const pOpts=state.products.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");["productionProduct","recipeProduct"].forEach(id=>{const prev=$(id).value;$(id).innerHTML=`<option value="">Select product</option>${pOpts}`;if([...$(id).options].some(o=>o.value===prev))$(id).value=prev});const prevM=$("recipeMaterial").value;$("recipeMaterial").innerHTML=`<option value="">Select material</option>${state.materials.map(m=>`<option value="${m.id}">${esc(m.name)} (${esc(m.unit)})</option>`).join("")}`;if([...$("recipeMaterial").options].some(o=>o.value===prevM))$("recipeMaterial").value=prevM};const ps=$("purchaseSupplier");if(ps){const prevS=ps.value;ps.innerHTML=`<option value="">Select supplier (optional)</option>${state.suppliers.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")}`;if([...ps.options].some(o=>o.value===prevS))ps.value=prevS}
function renderCategories(){const prev=$("categoryFilter").value,c=[...new Set(state.products.map(p=>p.category))].sort();$("categoryFilter").innerHTML=`<option value="all">All categories</option>${c.map(x=>`<option>${esc(x)}</option>`).join("")}`;if([...$("categoryFilter").options].some(o=>o.value===prev))$("categoryFilter").value=prev}
function renderProducts(){const q=$("searchInput").value.toLowerCase().trim(),c=$("categoryFilter").value,a=state.products.filter(p=>(p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q))&&(c==="all"||p.category===c));$("productGrid").innerHTML=a.length?a.map(p=>`<article class="product-card"><div class="product-icon">${esc(p.emoji||"🥐")}</div><h4>${esc(p.name)}</h4><div class="subtle">${esc(p.category)}</div><div class="product-row"><div><div class="price">${money.format(p.price)}</div><div class="stock ${p.stock<=5?"low":"ok"}">${p.stock>0?`${p.stock} in stock`:"Out of stock"}</div></div><button class="small-btn" ${p.stock<=0?"disabled":""} onclick="addToCart(${p.id})">Add</button></div></article>`).join(""):`<div class="empty">No matching products.</div>`}
function addToCart(id){const p=product(id);if(!p||p.stock<=0)return;let i=state.cart.find(x=>x.id===id);if((i?.qty||0)>=p.stock)return toast("No more stock available.");i?i.qty++:state.cart.push({id,qty:1});localSave();renderCart()}
function qty(id,d){const p=product(id),i=state.cart.find(x=>x.id===id);if(!p||!i)return;i.qty+=d;if(i.qty<=0)state.cart=state.cart.filter(x=>x.id!==id);else i.qty=Math.min(i.qty,p.stock);localSave();renderCart()}
const cartSubtotal=()=>state.cart.reduce((s,i)=>s+(product(i.id)?.price||0)*i.qty,0);
function renderCart(){const c=state.cart.reduce((s,i)=>s+i.qty,0);$("cartCount").textContent=`${c} item${c===1?"":"s"}`;$("cartItems").innerHTML=state.cart.length?state.cart.map(i=>{const p=product(i.id);return p?`<div class="cart-item"><div><strong>${esc(p.name)}</strong><div class="subtle">${money.format(p.price)} each</div></div><div class="qty"><button onclick="qty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="qty(${p.id},1)">+</button></div></div>`:""}).join(""):`<div class="empty">Your cart is empty.</div>`;const s=cartSubtotal(),d=$("needsDelivery").checked&&state.cart.length?5000:0;$("cartSubtotal").textContent=money.format(s);$("cartDelivery").textContent=money.format(d);$("cartTotal").textContent=money.format(s+d);$("deliveryAddress").classList.toggle("hidden",!$("needsDelivery").checked)}
function createOrder(paymentStatus){const name=$("customerName").value.trim()||state.session?.name||"",phone=$("customerPhone").value.trim()||(state.session?.role==="customer"?state.session.username:"");if(!name||!phone)return toast("Enter customer name and phone.");if(!state.cart.length)return toast("Cart is empty.");if($("needsDelivery").checked&&!$("deliveryAddress").value.trim())return toast("Enter delivery address.");for(const i of state.cart){const p=product(i.id);if(!p||p.stock<i.qty)return toast(`Not enough stock for ${p?.name||"item"}.`)}const sub=cartSubtotal(),del=$("needsDelivery").checked?5000:0,o={id:uid(),source:"online",customer:name,phone,paymentMethod:$("paymentMethod").value,paymentStatus,subtotal:sub,discount:0,deliveryFee:del,total:sub+del,delivery:$("needsDelivery").checked,address:$("deliveryAddress").value.trim(),deliveryStatus:$("needsDelivery").checked?"Awaiting Dispatch":"Pickup",status:"Confirmed",rider:"",createdAt:new Date().toISOString(),amountPaid:paymentStatus==="Paid"?sub+del:0,initialPaid:paymentStatus==="Paid"?sub+del:0,balanceDue:0,items:state.cart.map(i=>({...i}))};state.cart.forEach(i=>product(i.id).stock-=i.qty);state.orders.unshift(o);upsertCustomer(name,phone);state.cart=[];["customerName","customerPhone","deliveryAddress"].forEach(id=>$(id).value="");$("needsDelivery").checked=false;localSave();renderAll();showReceipt(o.id);toast("Order created.")}
function checkout(){if(!state.cart.length)return toast("Add products first.");const method=$("paymentMethod").value,phone=$("customerPhone").value.trim()||(state.session?.role==="customer"?state.session.username:"");if(["MTN Mobile Money","Airtel Money"].includes(method)){if(!phone)return toast("Enter phone number.");state.pendingCheckout={type:"shop",method,phone,total:cartSubtotal()+($("needsDelivery").checked?5000:0)};showPayment(method,phone,state.pendingCheckout.total)}else createOrder(method==="Cash"?"Pending":"Paid")}
function showPayment(method,phone,total){$("paymentTitle").textContent=method;$("paymentText").textContent=`Payment request for ${phone}. Live deployment will send this through the secure payment backend.`;$("paymentAmount").textContent=money.format(total);$("paymentBackdrop").classList.remove("hidden")}

async function requestBackendPayment(){if(!state.pendingCheckout)return;const p=state.pendingCheckout;if(!cloudToken()||!state.cloud?.url){if(await uiConfirm("The secure payment backend is not connected. Continue in demo mode?","Demo Payment")){if(p.type==="shop")createOrder("Paid");else if(p.type==="pos")p.finalize("Paid");$("paymentBackdrop").classList.add("hidden");state.pendingCheckout=null}return}const provider=p.method.startsWith("MTN")?"mtn":"airtel";$("confirmPaymentBtn").disabled=true;$("paymentText").textContent="Sending payment request to the secure backend...";try{const r=await fetch(state.cloud.url+"/payments/request",{method:"POST",headers:cloudHeaders(),body:JSON.stringify({provider,phone:p.phone,amount:p.total,orderId:"pending-"+Date.now()})});const d=await r.json();if(!r.ok)throw new Error(d.message||d.error||"Payment request failed");if(d.demo){$("paymentText").textContent="Backend is in DEMO payment mode. Confirm the demo transaction to continue.";const ok=await fetch(state.cloud.url+`/payments/${d.id}/demo-success`,{method:"POST",headers:cloudHeaders()});if(!ok.ok)throw new Error("Demo payment confirmation failed");if(p.type==="shop")createOrder("Paid");else if(p.type==="pos")p.finalize("Paid");$("paymentBackdrop").classList.add("hidden");state.pendingCheckout=null;toast("Demo payment recorded by backend.");return}$("paymentText").textContent="Payment request sent. Approve it on the customer's phone; checking status...";let success=false;for(let i=0;i<12;i++){await new Promise(r=>setTimeout(r,3000));const sr=await fetch(state.cloud.url+`/payments/${d.id}`,{headers:cloudHeaders()});const s=await sr.json();const status=String(s.status||"").toUpperCase();if(["SUCCESSFUL","SUCCESS"].includes(status)){success=true;break}if(["FAILED","REJECTED","CANCELLED"].includes(status))throw new Error("Payment was "+status.toLowerCase())}if(!success)throw new Error("Payment is still pending. Check again before completing the sale.");if(p.type==="shop")createOrder("Paid");else if(p.type==="pos")p.finalize("Paid");$("paymentBackdrop").classList.add("hidden");state.pendingCheckout=null;toast("Payment verified successfully.")}catch(e){$("paymentText").textContent="Payment not completed: "+e.message;toast("Payment was not marked paid.")}finally{$("confirmPaymentBtn").disabled=false}}

function customCake(){const n=$("cakeCustomer").value.trim()||state.session?.name||"",ph=$("cakePhone").value.trim()||(state.session?.role==="customer"?state.session.username:"");const size=$("cakeSize").value,fl=$("cakeFlavor").value,date=$("cakeDate").value,b=Number($("cakeBudget").value);if(!n||!ph||!size||!fl||!date||!b)return toast("Complete cake details.");upsertCustomer(n,ph);state.customCakes.unshift({id:uid(),customer:n,phone:ph,size,flavor:fl,date,budget:b,message:$("cakeMessage").value.trim(),fulfillment:$("cakeDelivery").value,status:"Pending",createdAt:new Date().toISOString()});localSave();renderOrders();["cakeCustomer","cakePhone","cakeDate","cakeBudget","cakeMessage"].forEach(id=>$(id).value="");$("cakeSize").value="";$("cakeFlavor").value="";toast("Custom cake request submitted.")}

function renderPOS(){const q=$("posSearch").value.toLowerCase().trim(),list=state.products.filter(p=>p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q));$("posProducts").innerHTML=list.map(p=>`<button class="pos-product" ${p.stock<=0?"disabled":""} onclick="posAdd(${p.id})"><div class="emoji">${esc(p.emoji||"🥐")}</div><strong>${esc(p.name)}</strong><div class="subtle">${money.format(p.price)} · Stock ${p.stock}</div></button>`).join("");$("posItems").innerHTML=state.posCart.length?state.posCart.map(i=>{const p=product(i.id);return p?`<div class="cart-item"><div><strong>${esc(p.name)}</strong><div class="subtle">${money.format(p.price)}</div></div><div class="qty"><button onclick="posQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="posQty(${p.id},1)">+</button></div></div>`:""}).join(""):`<div class="empty">Tap products to start a sale.</div>`;const sub=posSubtotal(),disc=Math.max(0,Math.min(100,Number($("posDiscount").value)||0)),discount=sub*disc/100,total=sub-discount,tender=Number($("posTender").value)||0;$("posSubtotal").textContent=money.format(sub);$("posDiscountView").textContent=money.format(discount);$("posTotal").textContent=money.format(total);$("posChange").textContent=money.format(Math.max(0,tender-total))}
const posSubtotal=()=>state.posCart.reduce((s,i)=>s+(product(i.id)?.price||0)*i.qty,0);
function posAdd(id){const p=product(id);if(!p||p.stock<=0)return;let i=state.posCart.find(x=>x.id===id);if((i?.qty||0)>=p.stock)return toast("Not enough finished stock.");i?i.qty++:state.posCart.push({id,qty:1});localSave();renderPOS()}
function posQty(id,d){const p=product(id),i=state.posCart.find(x=>x.id===id);if(!p||!i)return;i.qty+=d;if(i.qty<=0)state.posCart=state.posCart.filter(x=>x.id!==id);else i.qty=Math.min(i.qty,p.stock);localSave();renderPOS()}
function clearPOS(){state.posCart=[];localSave();renderPOS()}
function completePOS(){
  if(!isStaff())return toast("Staff login required to record a sale.");
  if(!state.posCart.length)return toast("Add products to the POS sale.");
  for(const i of state.posCart)if(product(i.id).stock<i.qty)return toast(`Not enough stock for ${product(i.id).name}.`);
  const sub=posSubtotal(),pct=Math.max(0,Math.min(100,Number($("posDiscount").value)||0)),discount=sub*pct/100,total=sub-discount,method=$("posPayment").value,tender=Number($("posTender").value)||0;
  if(!can("admin")&&pct>0){$("posDiscount").value=0;renderPOS();return toast("Only the Primary Admin can apply a discount or change selling prices.");}
  const name=$("posCustomer").value.trim()||"Walk-in",phone=$("posPhone").value.trim();
  if(method==="Cash"&&tender<total)return toast("Cash received is less than the total.");
  if(method==="Credit"&&(name==="Walk-in"||!phone))return toast("Credit sales require customer name and phone.");
  if(method==="Credit"&&!can("admin")){
    const profile=customerProfile(phone),limit=customerCreditLimit(phone),newBalance=Math.max(0,total-Math.max(0,Math.min(total,tender))),projected=customerDebt(phone)+newBalance;
    if(!profile||limit<=0)return toast("This customer has no admin-approved credit limit.");
    if(projected>limit)return toast(`Credit limit exceeded. Limit ${money.format(limit)}, projected balance ${money.format(projected)}.`);
  }
  const finalize=(paidStatus)=>{
    let amountPaid=total,balanceDue=0,initialPaid=total,status=paidStatus||"Paid";
    if(method==="Credit"){
      initialPaid=Math.max(0,Math.min(total,tender));
      amountPaid=initialPaid;
      balanceDue=Math.max(0,total-initialPaid);
      status=balanceDue>0?(initialPaid>0?"Part Paid":"Credit"):"Paid"
    }
    const createdAt=new Date().toISOString(),dueDate=method==="Credit"&&balanceDue>0?new Date(Date.now()+customerCreditDays(phone)*86400000).toISOString():null;
    const o={id:uid(),source:"pos",customer:name,phone,paymentMethod:method,paymentStatus:status,subtotal:sub,discount,deliveryFee:0,total,delivery:false,address:"",deliveryStatus:"Pickup",status:"Completed",rider:"",createdAt,dueDate,amountPaid,initialPaid,balanceDue,items:state.posCart.map(i=>({...i}))};
    state.posCart.forEach(i=>product(i.id).stock-=i.qty);state.orders.unshift(o);upsertCustomer(name,phone);state.posCart=[];
    ["posCustomer","posPhone","posTender"].forEach(id=>$(id).value="");$("posDiscount").value=0;
    localSave();renderAll();showReceipt(o.id);toast(method==="Credit"&&balanceDue>0?"Credit sale recorded.":"Sale completed.")
  };
  if(["MTN Mobile Money","Airtel Money"].includes(method)){if(!phone)return toast("Enter customer phone for Mobile Money.");state.pendingCheckout={type:"pos",method,phone,total,finalize};showPayment(method,phone,total)}
  else finalize("Paid")
}
function renderMaterials(){$("materialsBody").innerHTML=state.materials.map(m=>`<tr><td><strong>${esc(m.name)}</strong>${m.stock<=m.reorder?`<div class="stock low">Low stock</div>`:""}</td><td>${esc(m.unit)}</td><td>${num.format(m.stock)}</td><td>${money.format(m.cost)}</td><td>${money.format(m.stock*m.cost)}</td><td>${num.format(m.reorder)}</td><td>${can("admin")?`<button class="small-btn" onclick="editMaterial(${m.id})">Edit</button> <button class="small-btn" onclick="openPurchase(${m.id})">Purchase</button> <button class="small-btn" onclick="setMaterialStock(${m.id})">Set</button>${can("admin")?` <button class="small-btn danger-lite" onclick="deleteMaterial(${m.id})">Delete</button>`:""}`:"View"}</td></tr>`).join("")}
function addMaterial(){if(!can("admin"))return;const n=$("materialName").value.trim(),u=$("materialUnit").value.trim(),s=Number($("materialStock").value),c=Number($("materialCost").value),r=Number($("materialReorder").value);if(!n||!u||[s,c,r].some(Number.isNaN)||s<0||c<0||r<0)return toast("Complete material details.");state.materials.push({id:uid(),name:n,unit:u,stock:s,cost:c,reorder:r});["materialName","materialStock","materialCost","materialReorder"].forEach(id=>$(id).value="");localSave();renderAll();toast("Material added.")}
function openPurchase(id){if(!can("admin"))return toast("Primary admin access required.");state.purchaseMaterialId=id;const m=material(id);$("purchaseTitle").textContent=`Purchase ${m.name}`;$("purchaseBox").classList.remove("hidden");$("purchaseBox").scrollIntoView({behavior:"smooth",block:"center"})}
function recordPurchase(){
  if(!can("admin"))return toast("Primary admin access required.");
  const m=material(state.purchaseMaterialId);if(!m)return;
  const q=Number($("purchaseQty").value),total=Number($("purchaseTotalCost").value),supplierId=Number($("purchaseSupplier").value)||null,paid=Math.max(0,Math.min(total,Number($("purchasePaid").value)||0));
  if(!q||q<=0||!total||total<=0)return toast("Enter purchase quantity and total cost.");
  const oldValue=m.stock*m.cost,newStock=m.stock+q;m.cost=(oldValue+total)/newStock;m.stock=newStock;
  const sup=supplierId?supplierById(supplierId):null;
  const rec={id:uid(),materialId:m.id,qty:q,totalCost:total,supplierId,supplier:sup?.name||"",paidAmount:paid,balance:Math.max(0,total-paid),date:new Date().toISOString()};
  state.materialPurchases.unshift(rec);
  if(supplierId&&paid>0)state.supplierPayments.unshift({id:uid(),supplierId,amount:paid,date:rec.date,note:`Payment on purchase #${String(rec.id).slice(-6)}`});
  state.expenses.unshift({id:uid(),title:`Purchase: ${m.name}`,amount:total,category:"Ingredients",paymentMethod:"Cash",date:rec.date,linkedPurchaseId:rec.id});
  ["purchaseQty","purchaseTotalCost","purchasePaid"].forEach(id=>$(id).value="");$("purchaseSupplier").value="";
  $("purchaseBox").classList.add("hidden");state.purchaseMaterialId=null;localSave();renderAll();toast(rec.balance>0?"Purchase recorded with supplier balance.":"Purchase recorded.")
}
async function setMaterialStock(id){if(!can("admin"))return toast("Primary admin access required.");const m=material(id),v=await uiPrompt(`Set ${m.name} stock (${m.unit})`,m.stock,"number","Adjust Raw Material Stock");if(v===null)return;const n=Number(v);if(Number.isNaN(n)||n<0)return toast("Invalid stock.");m.stock=n;localSave();renderAll()}

function renderRecipes(){const cards=state.products.map(p=>{const r=recipe(p.id),batch=r?recipeBatchCost(p.id):0,unit=r?recipeUnitCost(p.id):0,margin=marginPct(p);const rows=r&&r.items.length?r.items.map(i=>{const m=material(i.materialId);return `<div class="recipe-row"><span>${esc(m?.name||"Missing material")} — ${num.format(i.qty)} ${esc(m?.unit||"")}</span><span class="row-cost">${money.format((m?.cost||0)*i.qty)}</span>${can("admin")?`<button class="small-btn" onclick="editRecipeQty(${p.id},${i.materialId})">Edit Qty</button> <button class="small-btn" onclick="removeRecipeItem(${p.id},${i.materialId})">Remove</button>`:""}</div>`}).join(""):`<div class="empty">No ingredients configured.</div>`;return `<article class="recipe-card"><div class="head"><div><strong>${esc(p.name)}</strong><div class="subtle">Batch yield: ${r?.yield||0} units</div></div>${can("admin")?`<div class="inline-actions"><button class="small-btn" onclick="setRecipeYield(${p.id})">Set Yield</button><button class="small-btn danger-lite" onclick="clearRecipe(${p.id})">Clear Recipe</button></div>`:""}</div><div class="recipe-ingredients">${rows}</div><div class="cost-grid"><div class="cost-chip"><span>Batch Cost</span><strong>${money.format(batch)}</strong></div><div class="cost-chip"><span>Cost / Unit</span><strong>${money.format(unit)}</strong></div><div class="cost-chip"><span>Selling Price</span><strong>${money.format(p.price)}</strong></div><div class="cost-chip"><span>Gross Margin</span><strong>${r?margin.toFixed(1)+"%":"—"}</strong></div></div></article>`}).join("");$("recipeCards").innerHTML=cards}
function addRecipeItem(){if(!can("admin"))return toast("Primary admin access required.");const pid=Number($("recipeProduct").value),mid=Number($("recipeMaterial").value),q=Number($("recipeMaterialQty").value),yieldN=Number($("recipeYield").value);if(!pid||!mid||!q||q<=0)return toast("Select product, material and quantity.");let r=state.recipes[String(pid)];if(!r)r=state.recipes[String(pid)]={yield:yieldN>0?yieldN:1,items:[]};if(yieldN>0)r.yield=yieldN;const existing=r.items.find(i=>i.materialId===mid);existing?existing.qty=q:r.items.push({materialId:mid,qty:q});$("recipeMaterialQty").value="";localSave();renderAll();toast("Recipe ingredient saved.")}
async function setRecipeYield(pid){if(!can("admin"))return toast("Primary admin access required.");let r=state.recipes[String(pid)];if(!r)r=state.recipes[String(pid)]={yield:1,items:[]};const v=await uiPrompt(`Batch yield for ${product(pid).name}`,r.yield,"number","Recipe Yield");if(v===null)return;const n=Number(v);if(!n||n<=0)return toast("Invalid yield.");r.yield=n;localSave();renderAll()}
function removeRecipeItem(pid,mid){if(!can("admin"))return toast("Primary admin access required.");const r=recipe(pid);if(!r)return;r.items=r.items.filter(i=>i.materialId!==mid);localSave();renderAll()}

function addProduction(){if(!can("admin","baker"))return toast("Baker or admin access required.");const pid=Number($("productionProduct").value),q=Number($("productionQty").value),due=$("productionDue").value;if(!pid||!q||q<=0||!due)return toast("Select product, quantity and due time.");const f=feasibility(pid,q);state.productionPlans.unshift({id:uid(),productId:pid,qty:q,due,note:$("productionNote").value.trim(),status:"Planned",createdAt:new Date().toISOString(),startedAt:null,completedAt:null});["productionQty","productionDue","productionNote"].forEach(id=>$(id).value="");localSave();renderAll();toast(f.ok?"Production batch planned.":"Batch planned, but materials are currently insufficient.")}
function renderProduction(){$("productionList").innerHTML=state.productionPlans.length?state.productionPlans.map(p=>{const pr=product(p.productId),f=feasibility(p.productId,p.qty),req=requirements(p.productId,p.qty),reqText=req.map(r=>`${material(r.materialId)?.name}: ${num.format(r.qty)} ${material(r.materialId)?.unit||""}`).join(" · ");const pct=p.status==="Completed"?100:p.status==="In Progress"?55:p.status==="Cancelled"?0:15;return `<article class="production-card"><div class="head"><div><strong>${esc(pr?.name||"Product")} · ${p.qty} units</strong><div class="subtle">Due ${new Date(p.due).toLocaleString()}${p.note?` · ${esc(p.note)}`:""}</div></div><span class="status">${esc(p.status)}</span></div><div class="progress-track"><span style="width:${pct}%"></span></div><div class="availability ${f.ok?"good":"bad"}">${p.status==="Completed"?"Materials consumed and finished stock added.":f.ok?"✓ Materials available":"⚠ "+f.missing.join(" | ")}</div><div class="subtle">Needs: ${esc(reqText||"Recipe not configured")}</div><div class="order-actions">${can("admin","baker")&&p.status==="Planned"?`<button class="small-btn" onclick="startProduction(${p.id})">Start</button>`:""}${can("admin","baker")&&p.status==="In Progress"?`<button class="small-btn" onclick="completeProduction(${p.id})">Complete Batch</button>`:""}${can("admin")&&p.status!=="Completed"?`<button class="small-btn" onclick="editProduction(${p.id})">Edit</button>`:""}${can("admin")&&!["Completed","Cancelled"].includes(p.status)?`<button class="small-btn" onclick="cancelProduction(${p.id})">Cancel</button>`:""}</div></article>`}).join(""):`<div class="empty">No production batches planned.</div>`}
function startProduction(id){if(!can("admin","baker"))return toast("Baker or admin access required.");const p=state.productionPlans.find(x=>x.id===id);if(!p)return;const f=feasibility(p.productId,p.qty);if(!f.ok)return toast("Cannot start: insufficient materials.");p.status="In Progress";p.startedAt=new Date().toISOString();localSave();renderAll()}
function completeProduction(id){if(!can("admin","baker"))return toast("Baker or admin access required.");const p=state.productionPlans.find(x=>x.id===id);if(!p||p.status!=="In Progress")return;const f=feasibility(p.productId,p.qty);if(!f.ok)return toast("Cannot complete: materials are insufficient.");requirements(p.productId,p.qty).forEach(r=>material(r.materialId).stock-=r.qty);product(p.productId).stock+=p.qty;p.status="Completed";p.completedAt=new Date().toISOString();localSave();renderAll();toast("Batch completed: ingredients deducted and finished stock added.")}
function cancelProduction(id){if(!can("admin"))return toast("Primary admin access required.");const p=state.productionPlans.find(x=>x.id===id);if(!p)return;p.status="Cancelled";localSave();renderAll()}

function renderOrders(){const f=$("orderStatusFilter")?.value||"all",po=state.orders.filter(o=>f==="all"||o.status===f),cakes=state.customCakes.filter(o=>f==="all"||o.status===f);$("staffOrderList").innerHTML=[...po.map(orderCard),...cakes.map(cakeCard)].join("")||`<div class="empty">No orders found.</div>`}
function orderCard(o){const items=o.items.map(i=>`${i.qty}× ${product(i.id)?.name||"Product"}`).join(", ");let a="";if(can("admin","cashier","baker"))a+=`<select onchange="setOrderStatus(${o.id},this.value)">${["Pending","Confirmed","Baking","Ready","Out for Delivery","Completed","Cancelled"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select>`;if(can("admin","cashier")&&o.paymentStatus!=="Paid")a+=`<button class="small-btn" onclick="markPaid(${o.id})">Mark Paid</button>`;if(can("admin"))a+=`<button class="small-btn" onclick="editOrderContact(${o.id})">Correct Details</button>`;if(can("admin")&&o.status!=="Cancelled")a+=`<button class="small-btn danger-lite" onclick="voidOrder(${o.id})">Void</button>`;if(can("admin"))a+=`<button class="small-btn danger-delete" onclick="deleteOrder(${o.id})">Delete</button>`;a+=`<button class="small-btn" onclick="showReceipt(${o.id})">Receipt</button>`;return `<article class="order-card"><div class="order-card-grid"><div><strong>#${String(o.id).slice(-6)} · ${esc(o.customer)}</strong><div class="subtle">${esc(items)}</div><div class="subtle">${new Date(o.createdAt).toLocaleString()} · ${esc(o.source||"order")}</div>${o.delivery?`<div class="subtle">Delivery: ${esc(o.address)}</div>`:""}</div><div><span class="status">${esc(o.status)}</span> <span class="status">${esc(o.paymentStatus)}</span><div class="price">${money.format(o.total)}</div></div></div><div class="order-actions">${a}</div></article>`}
function cakeCard(c){return `<article class="order-card"><div class="order-card-grid"><div><strong>Cake #${String(c.id).slice(-6)} · ${esc(c.customer)}</strong><div class="subtle">${esc(c.size)} ${esc(c.flavor)} · Due ${esc(c.date)}</div><div class="subtle">${esc(c.message||"No special message")}</div></div><div><span class="status">${esc(c.status)}</span><div class="price">Budget ${money.format(c.budget)}</div></div></div>${can("admin","cashier","baker")?`<div class="order-actions"><button class="small-btn" onclick="editCake(${c.id})">Edit</button><select onchange="setCakeStatus(${c.id},this.value)">${["Pending","Confirmed","Baking","Ready","Completed","Cancelled"].map(s=>`<option ${c.status===s?"selected":""}>${s}</option>`).join("")}</select></div>`:""}</article>`}
function setOrderStatus(id,s){if(!can("admin","cashier","baker"))return toast("You do not have permission to change order status.");const o=state.orders.find(x=>x.id===id);if(!o)return;o.status=s;if(s==="Out for Delivery")o.deliveryStatus="In Transit";if(s==="Completed")o.deliveryStatus=o.delivery?"Delivered":"Pickup Completed";localSave();renderAll()}function setCakeStatus(id,s){if(!can("admin","cashier","baker"))return toast("You do not have permission to change cake status.");const c=state.customCakes.find(x=>x.id===id);if(!c)return;c.status=s;localSave();renderOrders()}function markPaid(id){if(!isStaff())return toast("Staff login required.");const o=state.orders.find(x=>x.id===id);if(!o)return;o.paymentStatus="Paid";o.amountPaid=o.total;o.balanceDue=0;localSave();renderAll()}

function populateStockControlSelects(){
  const fill=(typeEl,itemEl)=>{if(!typeEl||!itemEl)return;const type=typeEl.value,items=type==="product"?state.products:state.materials,prev=itemEl.value;itemEl.innerHTML=items.map(x=>`<option value="${x.id}">${esc(x.name)} · Stock ${num.format(x.stock)}</option>`).join("");if([...itemEl.options].some(o=>o.value===prev))itemEl.value=prev};
  fill($("adjustmentType"),$("adjustmentItem"));fill($("wasteType"),$("wasteItem"));
}
function recordStockAdjustment(){
  if(!can("admin"))return toast("Primary Admin access required.");
  const type=$("adjustmentType").value,id=Number($("adjustmentItem").value),q=Number($("adjustmentQty").value),item=stockRecord(type,id);
  if(!item||!Number.isFinite(q)||q===0)return toast("Choose an item and enter a non-zero stock change.");
  if(item.stock+q<0)return toast("Adjustment would make stock negative.");
  const rec={id:uid(),itemType:type,itemId:id,itemName:item.name,quantity:q,reason:$("adjustmentReason").value,note:$("adjustmentNote").value.trim(),before:item.stock,after:item.stock+q,recordedBy:state.session.username,recordedByName:state.session.name,createdAt:new Date().toISOString(),status:"Applied"};
  item.stock+=q;state.stockAdjustments.unshift(rec);$("adjustmentQty").value="";$("adjustmentNote").value="";localSave();renderAll();toast("Stock adjustment applied and recorded.")
}
async function reverseStockAdjustment(id){
  if(!can("admin"))return;const a=state.stockAdjustments.find(x=>x.id===id);if(!a||a.status==="Reversed")return;
  const item=stockRecord(a.itemType,a.itemId);if(!item)return toast("The linked stock item no longer exists.");if(item.stock-a.quantity<0)return toast("Cannot reverse because current stock is too low.");
  if(!await uiConfirm(`Reverse the ${a.quantity>0?"+":""}${a.quantity} adjustment for ${a.itemName}?`,"Reverse Adjustment"))return;
  item.stock-=a.quantity;a.status="Reversed";a.reversedAt=new Date().toISOString();a.reversedBy=state.session.username;localSave();renderAll();toast("Stock adjustment reversed.")
}
function renderStockAdjustments(){
  if(!$("adjustmentList"))return;populateStockControlSelects();
  $("adjustmentList").innerHTML=state.stockAdjustments.length?state.stockAdjustments.slice(0,100).map(a=>`<article class="control-record ${a.status==="Reversed"?"muted-record":""}"><div><strong>${esc(a.itemName)} · ${a.quantity>0?"+":""}${num.format(a.quantity)}</strong><div class="subtle">${esc(a.itemType==="product"?"Finished Product":"Raw Material")} · ${esc(a.reason)} · ${new Date(a.createdAt).toLocaleString()}</div><small>${esc(a.note||"")}</small></div><div><span>${num.format(a.before)} → ${num.format(a.after)}</span><strong>${esc(a.status)}</strong>${can("admin")&&a.status!=="Reversed"?`<button class="small-btn danger-lite" onclick="reverseStockAdjustment(${a.id})">Reverse</button>`:""}</div></article>`).join(""):`<div class="empty">No stock adjustments recorded.</div>`;
}
function recordWaste(){
  if(!isStaff())return toast("Staff login required.");
  const type=$("wasteType").value,id=Number($("wasteItem").value),q=Number($("wasteQty").value),item=stockRecord(type,id);
  if(!item||!Number.isFinite(q)||q<=0)return toast("Choose an item and enter the wasted quantity.");if(item.stock<q)return toast("Waste quantity is greater than available stock.");
  const cost=wasteUnitCost(type,id),rec={id:uid(),itemType:type,itemId:id,itemName:item.name,quantity:q,reason:$("wasteReason").value,note:$("wasteNote").value.trim(),unitCost:cost,value:cost*q,before:item.stock,after:item.stock-q,recordedBy:state.session.username,recordedByName:state.session.name,createdAt:new Date().toISOString(),status:"Recorded"};
  item.stock-=q;state.wasteRecords.unshift(rec);$("wasteQty").value="";$("wasteNote").value="";localSave();renderAll();toast("Waste recorded and stock reduced.")
}
async function voidWaste(id){
  if(!can("admin"))return;const w=state.wasteRecords.find(x=>x.id===id);if(!w||w.status==="Voided")return;const item=stockRecord(w.itemType,w.itemId);if(!item)return toast("Linked stock item no longer exists.");
  if(!await uiConfirm(`Void this waste record and restore ${num.format(w.quantity)} to ${w.itemName}?`,"Void Waste Record"))return;
  item.stock+=w.quantity;w.status="Voided";w.voidedAt=new Date().toISOString();w.voidedBy=state.session.username;localSave();renderAll();toast("Waste record voided and stock restored.")
}
function renderWaste(){
  if(!$("wasteList"))return;populateStockControlSelects();const active=state.wasteRecords.filter(w=>w.status!=="Voided");$("wasteCount").textContent=active.length;$("wasteValue").textContent=money.format(active.reduce((s,w)=>s+(Number(w.value)||0),0));
  $("wasteList").innerHTML=state.wasteRecords.length?state.wasteRecords.slice(0,100).map(w=>`<article class="control-record ${w.status==="Voided"?"muted-record":""}"><div><strong>${esc(w.itemName)} · ${num.format(w.quantity)}</strong><div class="subtle">${esc(w.reason)} · ${esc(w.recordedByName||w.recordedBy||"Staff")} · ${new Date(w.createdAt).toLocaleString()}</div><small>${esc(w.note||"")}</small></div><div><span>${money.format(w.value||0)}</span><strong>${esc(w.status)}</strong>${can("admin")&&w.status!=="Voided"?`<button class="small-btn danger-lite" onclick="voidWaste(${w.id})">Void</button>`:""}</div></article>`).join(""):`<div class="empty">No waste or damaged stock recorded.</div>`;
}

function renderInventory(){$("inventoryBody").innerHTML=state.products.map(p=>{const c=recipeUnitCost(p.id),m=recipe(p.id)?marginPct(p):null;return `<tr><td>${esc(p.emoji||"🥐")} ${esc(p.name)}</td><td>${esc(p.category)}</td><td>${money.format(p.price)}</td><td>${recipe(p.id)?money.format(c):"—"}</td><td>${m===null?"—":m.toFixed(1)+"%"}</td><td class="${p.stock<=5?"stock low":""}">${p.stock}</td><td>${can("admin")?`<button class="small-btn" onclick="editProduct(${p.id})">Edit</button> <button class="small-btn" onclick="restock(${p.id})">+5</button> <button class="small-btn" onclick="adjustStock(${p.id})">Set</button>${can("admin")?` <button class="small-btn danger-lite" onclick="deleteProduct(${p.id})">Delete</button>`:""}`:"View"}</td></tr>`}).join("")}
function addProduct(){if(!can("admin"))return;const n=$("newName").value.trim(),c=$("newCategory").value.trim(),p=Number($("newPrice").value),s=Number($("newStock").value);if(!n||!c||!p||s<0)return toast("Complete product fields.");state.products.push({id:uid(),name:n,category:c,price:p,stock:s,emoji:$("newEmoji").value.trim()||"🥐"});["newName","newCategory","newPrice","newStock","newEmoji"].forEach(id=>$(id).value="");localSave();renderAll()}function restock(id){if(!can("admin"))return toast("Primary admin access required.");product(id).stock+=5;localSave();renderAll()}async function adjustStock(id){if(!can("admin"))return toast("Primary admin access required.");const p=product(id),v=await uiPrompt(`Set stock for ${p.name}`,p.stock,"number","Adjust Finished Stock");if(v===null)return;const n=Number(v);if(Number.isNaN(n)||n<0)return;p.stock=n;localSave();renderAll()}
function addExpense(){if(!isStaff())return toast("Staff login required.");const t=$("expenseTitle").value.trim(),a=Number($("expenseAmount").value);if(!t||!a)return toast("Enter expense title and amount.");state.expenses.unshift({id:uid(),title:t,amount:a,category:$("expenseCategory").value,paymentMethod:$("expensePaymentMethod").value,date:new Date().toISOString(),recordedBy:state.session?.username||""});$("expenseTitle").value="";$("expenseAmount").value="";localSave();renderAll()}function renderExpenses(){$("expenseList").innerHTML=state.expenses.length?state.expenses.map(e=>`<div class="expense-card editable-row"><div><strong>${esc(e.title)}</strong><div class="subtle">${esc(e.category)} · ${esc(e.paymentMethod||"Cash")} · ${new Date(e.date).toLocaleDateString()}</div><div class="price">${money.format(e.amount)}</div></div>${can("admin")?`<div class="inline-actions"><button class="small-btn" onclick="editExpense(${e.id})">Edit</button>${can("admin")?`<button class="small-btn danger-lite" onclick="deleteExpense(${e.id})">Delete</button>`:""}</div>`:""}</div>`).join(""):`<div class="empty">No expenses recorded.</div>`}
function addEmployee(){if(!can("admin"))return;const n=$("employeeName").value.trim(),u=$("employeeUsername").value.trim(),p=$("employeePassword").value,role=$("employeeRole").value;if(!n||!u||!p)return toast("Complete employee details.");if(!["cashier","baker","rider"].includes(role))return toast("Only one admin is allowed. Choose cashier, baker or rider.");if(state.users.some(x=>x.username===u))return toast("Username exists.");state.users.push({id:uid(),name:n,username:u,password:p,role});["employeeName","employeeUsername","employeePassword"].forEach(id=>$(id).value="");localSave();renderEmployees()}function renderEmployees(){$("employeeList").innerHTML=state.users.filter(u=>u.role!=="customer").map(u=>`<div class="employee-card editable-row"><div><strong>${esc(u.name)}</strong><div class="subtle">@${esc(u.username)} · ${esc(u.role)}</div></div>${can("admin")?`<div class="inline-actions"><button class="small-btn" onclick="editEmployee(${u.id})">Edit</button>${u.id===PRIMARY_ADMIN_ID?`<span class="status">Primary Admin</span>`:`<button class="small-btn danger-lite" onclick="deleteEmployee(${u.id})">Delete</button>`}</div>`:""}</div>`).join("")}
function renderDelivery(){const os=state.orders.filter(o=>o.delivery),rs=state.users.filter(u=>u.role==="rider");$("deliveryList").innerHTML=os.length?os.map(o=>`<article class="order-card"><strong>#${String(o.id).slice(-6)} · ${esc(o.customer)}</strong><div class="subtle">${esc(o.address)} · ${esc(o.deliveryStatus)}</div><div class="order-actions">${can("admin","cashier")?`<select onchange="assignRider(${o.id},this.value)"><option value="">Assign rider</option>${rs.map(r=>`<option value="${esc(r.username)}" ${o.rider===r.username?"selected":""}>${esc(r.name)}</option>`).join("")}</select>`:""}${can("admin","cashier","rider")?`<select onchange="setDeliveryStatus(${o.id},this.value)">${["Awaiting Dispatch","In Transit","Delivered","Failed"].map(s=>`<option ${o.deliveryStatus===s?"selected":""}>${s}</option>`).join("")}</select>`:""}</div></article>`).join(""):`<div class="empty">No delivery orders.</div>`}function assignRider(id,u){if(!can("admin","cashier"))return toast("Cashier or admin access required.");const o=state.orders.find(x=>x.id===id);if(o){o.rider=u;localSave();renderDelivery()}}function setDeliveryStatus(id,s){if(!can("admin","cashier","rider"))return toast("Delivery access required.");const o=state.orders.find(x=>x.id===id);if(!o)return;if(can("rider")&&o.rider&&o.rider!==state.session.username)return toast("Assigned to another rider.");o.deliveryStatus=s;if(s==="Delivered")o.status="Completed";localSave();renderAll()}
function renderCustomerOrdersLegacyV12(){if(state.session?.role!=="customer")return;const os=state.orders.filter(o=>o.phone===state.session.username),cs=state.customCakes.filter(c=>c.phone===state.session.username);$("customerOrders").innerHTML=[...os.map(orderCard),...cs.map(cakeCard)].join("")||`<div class="empty">You have no orders yet.</div>`}
function renderStats(){
  const rev=state.orders.reduce((s,o)=>s+orderReceived(o),0),exp=state.expenses.reduce((s,e)=>s+(Number(e.amount)||0),0);
  $("salesRevenue").textContent=money.format(rev);$("expenseTotal").textContent=money.format(exp);$("profitTotal").textContent=money.format(rev-exp);
  $("lowMaterialTotal").textContent=state.materials.filter(m=>m.stock<=m.reorder).length;
  $("plannedBatchTotal").textContent=state.productionPlans.filter(p=>["Planned","In Progress"].includes(p.status)).length;
  $("lowStockTotal").textContent=state.products.filter(p=>p.stock<=5).length;
  $("receivableTotal").textContent=money.format(totalReceivables());$("payableTotal").textContent=money.format(totalPayables());
  $("heroProducts").textContent=state.products.length;$("heroOrders").textContent=state.orders.length+state.customCakes.length;$("heroRevenue").textContent=money.format(rev)
}
function showReceipt(id){const o=state.orders.find(x=>x.id===id);if(!o)return;const lines=o.items.map(i=>{const p=product(i.id);return `<div class="receipt-line"><span>${i.qty} × ${esc(p?.name||"Product")}</span><span>${money.format((p?.price||0)*i.qty)}</span></div>`}).join("");$("receiptContent").innerHTML=`<div class="receipt"><img src="logo.png" class="receipt-logo" alt="D&#39;s Bakery logo"><h2>D's Bakery</h2><div style="text-align:center">Fresh Every Day · Sales Receipt</div><hr><div>Receipt: #${String(o.id).slice(-8)}</div><div>Date: ${new Date(o.createdAt).toLocaleString()}</div><div>Customer: ${esc(o.customer)}</div><hr>${lines}<hr><div class="receipt-line"><span>Subtotal</span><strong>${money.format(o.subtotal)}</strong></div>${o.discount?`<div class="receipt-line"><span>Discount</span><strong>-${money.format(o.discount)}</strong></div>`:""}<div class="receipt-line"><span>Delivery</span><strong>${money.format(o.deliveryFee)}</strong></div><div class="receipt-line"><span>TOTAL</span><strong>${money.format(o.total)}</strong></div><hr><div>Payment: ${esc(o.paymentMethod)} (${esc(o.paymentStatus)})</div>${orderBalance(o)>0?`<div class="receipt-line"><span>Amount Paid</span><strong>${money.format(orderReceived(o))}</strong></div><div class="receipt-line"><span>Balance Due</span><strong>${money.format(orderBalance(o))}</strong></div>`:""}<div class="receipt-contact"><div>Tel: <strong>${BAKERY_CONTACT.phone1} / ${BAKERY_CONTACT.phone2}</strong></div><div>Email: <strong>${esc(BAKERY_CONTACT.email)}</strong></div><div>TikTok: <strong>${esc(BAKERY_CONTACT.tiktok)}</strong></div></div><div style="text-align:center;margin-top:14px">Thank you!</div></div>`;$("receiptBackdrop").classList.remove("hidden")}
async function login(){const u=$("loginUsername").value.trim(),p=$("loginPassword").value;if(!u||!p)return toast("Enter username and password.");enforceSingleAdmin();if(state.cloud?.url){try{const r=await fetch(state.cloud.url.replace(/\/$/,"")+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json","X-Device-Id":deviceId()},body:JSON.stringify({username:u,password:p})});if(r.ok){const d=await r.json();setCloudToken(d.token);state.session={id:Number(d.user.id),name:d.user.name,username:d.user.username,role:d.user.role};let local=state.users.find(x=>x.id===state.session.id||x.username===state.session.username);if(local){local.name=state.session.name;local.role=state.session.role;if(p)local.password=p}else state.users.push({id:state.session.id,name:state.session.name,username:state.session.username,password:p,role:state.session.role});localSave();$("modalBackdrop").classList.add("hidden");await cloudPull(true);renderAll();startCloudPolling();toast(`Welcome ${state.session.name}. Online sync connected.`);return}else if(r.status===401){toast("Incorrect server login details.");return}}catch(e){toast("Server unavailable — using offline login if available.")}}const x=state.users.find(a=>a.username===u&&a.password===p);if(!x)return toast("Incorrect login details.");state.session={id:x.id,name:x.name,username:x.username,role:x.role};localSave();$("modalBackdrop").classList.add("hidden");renderAll();toast(`Welcome ${x.name}. Offline mode.`)}function registerCustomer(){const n=$("regName").value.trim(),ph=$("regPhone").value.trim(),p=$("regPassword").value;if(!n||!ph||!p)return toast("Complete registration.");if(state.users.some(u=>u.username===ph))return toast("Account exists.");const u={id:uid(),name:n,username:ph,password:p,role:"customer"};state.users.push(u);upsertCustomer(n,ph);state.session={id:u.id,name:u.name,username:u.username,role:u.role};localSave();$("modalBackdrop").classList.add("hidden");renderAll()}function logout(){state.session=null;setCloudToken("");if(cloudPollTimer){clearInterval(cloudPollTimer);cloudPollTimer=null}localSave();renderAll()}


function addSupplier(){
  if(!can("admin"))return;
  const name=$("supplierName").value.trim(),phone=$("supplierPhone").value.trim();
  if(!name)return toast("Enter supplier name.");
  state.suppliers.push({id:uid(),name,phone,email:$("supplierEmail").value.trim(),address:$("supplierAddress").value.trim()});
  ["supplierName","supplierPhone","supplierEmail","supplierAddress"].forEach(id=>$(id).value="");
  localSave();renderAll();toast("Supplier added.")
}
async function paySupplier(id){
  if(!can("admin"))return;
  const sup=supplierById(id),bal=supplierBalance(id);if(!sup||bal<=0)return toast("No supplier balance.");
  const raw=await uiPrompt(`Outstanding for ${sup.name}: ${money.format(bal)}. Enter payment amount:`,bal,"number","Supplier Payment");if(raw===null)return;
  const amount=Number(raw);if(!amount||amount<=0||amount>bal)return toast("Enter a valid amount not above the balance.");
  state.supplierPayments.unshift({id:uid(),supplierId:id,amount,date:new Date().toISOString(),note:"Supplier balance payment"});
  localSave();renderAll();toast("Supplier payment recorded.")
}
function renderSuppliers(){
  $("supplierList").innerHTML=state.suppliers.length?state.suppliers.map(s=>{
    const purchases=state.materialPurchases.filter(p=>Number(p.supplierId)===s.id).reduce((a,p)=>a+(Number(p.totalCost)||0),0),bal=supplierBalance(s.id);
    return `<article class="supplier-card"><div class="head"><div><strong>${esc(s.name)}</strong><div class="subtle">${esc(s.phone||"No phone")}${s.address?` · ${esc(s.address)}`:""}</div></div><span class="status ${bal>0?"Pending":"Paid"}">${bal>0?"Owes supplier":"Clear"}</span></div><div class="supplier-money"><div><span>Total Purchases</span><strong>${money.format(purchases)}</strong></div><div><span>Outstanding</span><strong>${money.format(bal)}</strong></div></div><div class="inline-actions">${can("admin")?`<button class="small-btn" onclick="editSupplier(${s.id})">Edit</button>${bal>0?`<button class="small-btn" onclick="paySupplier(${s.id})">Record Payment</button>`:""}<button class="small-btn danger-lite" onclick="deleteSupplier(${s.id})">Delete</button>`:""}</div></article>`
  }).join(""):`<div class="empty">No suppliers added.</div>`
}
async function recordCreditPayment(id){
  if(!isStaff())return toast("Staff login required.");
  const o=state.orders.find(x=>x.id===id),bal=o?orderBalance(o):0;if(!o||bal<=0)return toast("No outstanding balance.");
  const raw=await uiPrompt(`Balance for ${o.customer}: ${money.format(bal)}. Enter payment received:`,bal,"number","Receive Credit Payment");if(raw===null)return;
  const amount=Number(raw);if(!amount||amount<=0||amount>bal)return toast("Enter a valid amount not above the balance.");
  const pm=await uiPrompt("Payment method: Cash, MTN Mobile Money, Airtel Money or Card","Cash","text","Payment Method");if(pm===null)return;
  const allowed=["Cash","MTN Mobile Money","Airtel Money","Card"];if(!allowed.includes(pm))return toast("Use Cash, MTN Mobile Money, Airtel Money or Card.");
  o.amountPaid=orderReceived(o)+amount;o.balanceDue=Math.max(0,bal-amount);o.paymentStatus=o.balanceDue<=0?"Paid":"Part Paid";
  state.creditPayments.unshift({id:uid(),orderId:o.id,customer:o.customer,phone:o.phone,amount,paymentMethod:pm,date:new Date().toISOString(),recordedBy:state.session?.username||""});
  localSave();renderAll();toast(o.balanceDue<=0?"Debt fully paid.":"Customer payment recorded.")
}
function renderCredit(){
  const debts=state.orders.filter(o=>orderBalance(o)>0).sort((a,b)=>new Date(a.dueDate||a.createdAt)-new Date(b.dueDate||b.createdAt)),grouped={};
  debts.forEach(o=>{const k=o.phone||o.customer;if(!grouped[k])grouped[k]={name:o.customer,phone:o.phone,total:0,orders:[]};grouped[k].total+=orderBalance(o);grouped[k].orders.push(o)});
  $("creditOutstanding").textContent=money.format(totalReceivables());$("creditCustomerCount").textContent=Object.keys(grouped).length;$("creditPaymentsTotal").textContent=money.format(state.creditPayments.reduce((s,p)=>s+(Number(p.amount)||0),0));
  $("creditList").innerHTML=Object.keys(grouped).length?Object.values(grouped).map(g=>`<article class="credit-card ${g.orders.some(isOverdueOrder)?"overdue-card":""}"><div class="head"><div><strong>${esc(g.name)}</strong><div class="subtle">${esc(g.phone||"No phone")} · Limit ${money.format(customerCreditLimit(g.phone))}</div></div><div class="price">${money.format(g.total)}</div></div>${g.orders.map(o=>`<div class="credit-order ${isOverdueOrder(o)?"overdue-row":""}"><span>#${String(o.id).slice(-6)} · ${new Date(o.createdAt).toLocaleDateString()}${o.dueDate?` · <b>${isOverdueOrder(o)?"OVERDUE":"Due"} ${new Date(o.dueDate).toLocaleDateString()}</b>`:""}</span><strong>${money.format(orderBalance(o))}</strong><button class="small-btn" onclick="recordCreditPayment(${o.id})">Receive Payment</button></div>`).join("")}</article>`).join(""):`<div class="empty">No customer debts.</div>`
}

function renderCashClosing(){
  if(!$("closingDate"))return;
  if(!$("closingDate").value)$("closingDate").value=localDateKey();
  const key=$("closingDate").value||localDateKey(),s=dailyClosingSummary(key);
  $("closingCashSales").textContent=money.format(s.cashSales);$("closingMobile").textContent=money.format(s.mobile);$("closingCard").textContent=money.format(s.card);$("closingCredit").textContent=money.format(s.creditIssued);$("closingExpenses").textContent=money.format(s.cashExpenses);$("closingExpected").textContent=money.format(s.expectedCash);
  const actual=Number($("closingActualCash").value);$("closingDifferencePreview").innerHTML=Number.isFinite(actual)&&$("closingActualCash").value!==""?`Difference: <strong class="${actual-s.expectedCash<0?"negative":"positive"}">${money.format(actual-s.expectedCash)}</strong>`:"";
  const rows=state.cashClosings.filter(x=>x.date===key).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  $("closingList").innerHTML=rows.length?rows.map(c=>`<article class="closing-card"><div><strong>${esc(c.date)} · ${esc(c.status)}</strong><div class="subtle">Recorded by ${esc(c.recordedByName||c.recordedBy||"Staff")} · ${new Date(c.createdAt).toLocaleString()}</div>${c.note?`<div class="subtle">${esc(c.note)}</div>`:""}</div><div class="closing-values"><span>Expected ${money.format(c.expectedCash)}</span><span>Actual ${money.format(c.actualCash)}</span><strong class="${c.difference<0?"negative":"positive"}">${c.difference<0?"Short":"Over"} ${money.format(Math.abs(c.difference))}</strong></div><div class="inline-actions">${can("admin")&&c.status!=="Confirmed"?`<button class="small-btn" onclick="confirmCashClosing(${c.id})">Confirm</button>`:""}${can("admin")?`<button class="small-btn" onclick="editCashClosing(${c.id})">Edit Actual</button>`:""}</div></article>`).join(""):`<div class="empty">No closing submitted for this date.</div>`;
}
function submitCashClosing(){
  if(!isStaff())return toast("Staff login required.");
  const key=$("closingDate").value||localDateKey();if(state.cashClosings.some(x=>x.date===key&&x.status!=="Reopened"))return toast("A closing already exists for this date. Ask the Primary Admin to correct it.");
  const s=dailyClosingSummary(key),actual=Number($("closingActualCash").value);if(!Number.isFinite(actual)||actual<0)return toast("Enter the actual cash counted.");
  const rec={id:uid(),date:key,...s,actualCash:actual,difference:actual-s.expectedCash,note:$("closingNote").value.trim(),recordedBy:state.session?.username||"",recordedByName:state.session?.name||"",createdAt:new Date().toISOString(),status:can("admin")?"Confirmed":"Submitted",confirmedAt:can("admin")?new Date().toISOString():null,confirmedBy:can("admin")?state.session.username:null};
  state.cashClosings.unshift(rec);$("closingActualCash").value="";$("closingNote").value="";localSave();renderAll();toast(rec.status==="Confirmed"?"Daily closing recorded and confirmed.":"Daily closing submitted for admin confirmation.")
}
function confirmCashClosing(id){if(!can("admin"))return;const c=state.cashClosings.find(x=>x.id===id);if(!c)return;c.status="Confirmed";c.confirmedAt=new Date().toISOString();c.confirmedBy=state.session.username;localSave();renderCashClosing();toast("Daily closing confirmed.")}
async function editCashClosing(id){if(!can("admin"))return;const c=state.cashClosings.find(x=>x.id===id);if(!c)return;const v=await askNumber("Correct actual cash counted (UGX)",c.actualCash);if(v===null||v===undefined)return;c.actualCash=v;c.difference=v-c.expectedCash;c.status="Confirmed";c.confirmedAt=new Date().toISOString();c.confirmedBy=state.session.username;localSave();renderCashClosing();toast("Closing corrected and confirmed.")}

function renderReports(){
  const {start,end}=reportRange(),orders=state.orders.filter(o=>o.status!=="Cancelled"&&dateInRange(o.createdAt,start,end)),expenses=state.expenses.filter(e=>dateInRange(e.date,start,end)),creditPays=state.creditPayments.filter(p=>dateInRange(p.date,start,end));
  const invoiced=orders.reduce((s,o)=>s+(Number(o.total)||0),0);
  const orderCash=orders.reduce((s,o)=>{if(o.paymentMethod==="Credit")return s+(Number(o.initialPaid)||0);return s+(o.paymentStatus==="Paid"?(Number(o.total)||0):0)},0);
  const collected=orderCash+creditPays.reduce((s,p)=>s+(Number(p.amount)||0),0),exp=expenses.reduce((s,e)=>s+(Number(e.amount)||0),0),credit=orders.filter(o=>o.paymentMethod==="Credit").reduce((s,o)=>s+Math.max(0,(Number(o.total)||0)-(Number(o.initialPaid)||0)),0);
  $("reportSales").textContent=money.format(invoiced);$("reportCollected").textContent=money.format(collected);$("reportExpenses").textContent=money.format(exp);$("reportNet").textContent=money.format(collected-exp);$("reportOrders").textContent=orders.length;$("reportCredit").textContent=money.format(credit);
  const prod={};orders.forEach(o=>o.items.forEach(i=>{const p=product(i.id),k=p?.name||"Product";if(!prod[k])prod[k]={qty:0,revenue:0};prod[k].qty+=i.qty;prod[k].revenue+=(p?.price||0)*i.qty}));
  const rows=Object.entries(prod).sort((a,b)=>b[1].revenue-a[1].revenue),maxP=Math.max(1,...rows.map(x=>x[1].revenue));
  $("reportProducts").innerHTML=rows.length?rows.map(([n,v])=>`<div class="report-row"><div><strong>${esc(n)}</strong><span>${v.qty} units · ${money.format(v.revenue)}</span></div><div class="bar"><i style="width:${Math.round(v.revenue/maxP*100)}%"></i></div></div>`).join(""):`<div class="empty">No sales in this period.</div>`;
  const pays={};orders.forEach(o=>pays[o.paymentMethod]=(pays[o.paymentMethod]||0)+(Number(o.total)||0));
  $("reportPayments").innerHTML=Object.entries(pays).map(([k,v])=>`<div class="mini-row"><span>${esc(k)}</span><strong>${money.format(v)}</strong></div>`).join("")||`<div class="empty">No payments.</div>`;
  const cats={};expenses.forEach(e=>cats[e.category]=(cats[e.category]||0)+(Number(e.amount)||0));
  $("reportExpenseCats").innerHTML=Object.entries(cats).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="mini-row"><span>${esc(k)}</span><strong>${money.format(v)}</strong></div>`).join("")||`<div class="empty">No expenses.</div>`
}
function exportReportCSV(){
  const {start,end,label}=reportRange(),orders=state.orders.filter(o=>o.status!=="Cancelled"&&dateInRange(o.createdAt,start,end));
  const rows=[["D's Bakery Report",label],[],["Order ID","Date","Customer","Phone","Payment","Status","Total","Paid","Balance"]];
  orders.forEach(o=>rows.push([o.id,new Date(o.createdAt).toLocaleString(),o.customer,o.phone||"",o.paymentMethod,o.paymentStatus,o.total,orderReceived(o),orderBalance(o)]));
  rows.push([],["Current Customer Receivables",totalReceivables()],["Current Supplier Payables",totalPayables()]);
  const csv=rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(",")).join("\n"),blob=new Blob([csv],{type:"text/csv"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`bakerypro-report-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(a.href)
}

function cloudConfigFromUI(){state.cloud={url:$("cloudUrl").value.trim().replace(/\/$/,""),mode:$("cloudMode").value,revision:Number(state.cloud?.revision||0)};DataService.set("cloud",state.cloud)}
function cloudHeaders(){return {"Content-Type":"application/json","X-Device-Id":deviceId(),...(cloudToken()?{"Authorization":"Bearer "+cloudToken()}:{})}}
function setCloud(txt,cls){
  $("cloudStatus").textContent=txt;
  $("syncDot").className="sync-dot "+cls;
  updateSyncMini(cls==="online"?"Synced":cls==="syncing"?"Syncing":cls==="conflict"?"Conflict":null)
}
async function connectCloud(){
  if(!state.session)return toast("Login first.");
  cloudConfigFromUI();if(!state.cloud.url)return toast("Enter the backend URL.");
  const password=$("cloudPassword").value;if(!password)return toast("Enter the server password for the current login.");
  setCloud("Connecting...","syncing");
  try{
    const r=await fetch(state.cloud.url+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json","X-Device-Id":deviceId()},body:JSON.stringify({username:state.session.username,password})});
    const d=await r.json();if(!r.ok)throw new Error(d.error||"Login failed");
    setCloudToken(d.token);$("cloudPassword").value="";
    setCloud("Connected as "+d.user.username,"online");
    if(outboxCount())await flushSyncOutbox(true);else await cloudPull(true,true);
    startRealtimeSync();startCloudPolling();
    toast("Live multi-device connection established.")
  }catch(e){setCloud("Connection failed: "+e.message,"error");toast("Cloud login failed.")}
}
async function cloudTest(){
  cloudConfigFromUI();if(!state.cloud.url)return toast("Enter the backend URL.");
  setCloud("Checking...","syncing");
  try{const r=await fetch(state.cloud.url+"/health",{headers:{"X-Device-Id":deviceId()}});if(!r.ok)throw new Error("HTTP "+r.status);const d=await r.json();setCloud(`Backend online · revision ${d.revision??0} · ${d.liveClients??0} live device${Number(d.liveClients)===1?"":"s"}`,"online");toast("Backend connection successful.")}
  catch(e){setCloud("Connection failed: "+e.message,"error")}
}
async function flushSyncOutbox(silent=false){
  if(syncBusy||!cloudToken()||!state.cloud?.url||!navigator.onLine)return null;
  const box=getOutbox();if(!box.length){updateSyncMini();return null}
  syncBusy=true;setCloud(`Syncing ${box.length} pending change${box.length===1?"":"s"}...`,"syncing");
  try{
    const item=box[0];
    const r=await fetch(state.cloud.url+"/state",{method:"PUT",headers:cloudHeaders(),body:JSON.stringify({state:item.state,deviceId:deviceId(),baseRevision:Number(item.baseRevision||0)})});
    const d=await r.json().catch(()=>({}));
    if(r.status===409){
      if(d.error==="revision_conflict"){
        setCloud(`Admin sync conflict · server revision ${d.currentRevision}`,"conflict");
        if(!silent)toast("Another device changed the bakery data. Your admin changes are still saved locally; download the latest data before retrying.");
        return {conflict:true,...d}
      }
      if(d.error==="insufficient_stock"){
        setCloud("Sync stopped · stock conflict","conflict");
        if(!silent)toast("Some offline sales exceed the stock now available. The pending changes were kept for admin review.");
        return {conflict:true,...d}
      }
    }
    if(!r.ok)throw new Error(d.error||("HTTP "+r.status));
    state.cloud.revision=Number(d.revision||state.cloud.revision||0);DataService.set("cloud",state.cloud);
    saveOutbox([]);
    setCloud("Synced · revision "+state.cloud.revision,"online");
    await cloudPull(true,true);
    if(!silent)toast("Changes synchronized.");
    return d
  }catch(e){
    setCloud(navigator.onLine?"Sync retry pending: "+e.message:`Offline · ${outboxCount()} pending`,"offline");
    if(!silent)toast("Changes are saved on this device and will retry automatically.");
    return null
  }finally{syncBusy=false;updateSyncMini()}
}
async function cloudPush(silent=false){if(!cloudToken())return silent?null:toast("Connect this device to the backend first.");cloudConfigFromUI();if(!state.cloud.url)return;queueSyncSnapshot();return flushSyncOutbox(silent)}
async function cloudPull(silent=false,force=false){
  if(!cloudToken())return silent?null:toast("Connect this device to the backend first.");
  cloudConfigFromUI();if(!state.cloud.url)return silent?null:toast("Enter backend URL.");
  if(outboxCount()&&!force){if(!silent)toast("Local changes are waiting to sync first.");return null}
  if(!silent)setCloud("Downloading latest data...","syncing");
  try{
    const r=await fetch(state.cloud.url+"/state",{headers:cloudHeaders()});const payload=await r.json();if(!r.ok)throw new Error(payload.error||("HTTP "+r.status));
    const d=payload.state||payload,passwordMap=Object.fromEntries((state.users||[]).map(u=>[u.username,u.password||""]));
    syncApplying=true;
    for(const k of ["products","orders","expenses","customCakes","productionPlans","materialPurchases","materials","suppliers","creditPayments","supplierPayments","customers","cashClosings","stockAdjustments","wasteRecords","cashierShifts","refunds","stockMovements"])if(Array.isArray(d[k]))state[k]=d[k];
    if(Array.isArray(d.users))state.users=d.users.map(u=>({...u,password:passwordMap[u.username]||""}));
    if(d.recipes&&typeof d.recipes==="object")state.recipes=d.recipes;
    state.cloud.revision=Number(payload.revision||state.cloud.revision||0);enforceSingleAdmin();localSave();syncApplying=false;renderAll();
    setCloud("Live · revision "+state.cloud.revision,"online");if(!silent)toast("Latest shared bakery data downloaded.");return payload
  }catch(e){syncApplying=false;setCloud("Download failed: "+e.message,"error");if(!silent)toast("Cloud download failed.");return null}
}
async function cloudPoll(){
  if(!cloudToken()||!state.cloud?.url||!navigator.onLine)return;
  try{
    const r=await fetch(state.cloud.url+"/state/meta",{headers:cloudHeaders()});if(!r.ok)return;const d=await r.json();
    if(Number(d.revision||0)>Number(state.cloud.revision||0)){
      if(outboxCount())await flushSyncOutbox(true);
      if(!outboxCount())await cloudPull(true,true)
    }
  }catch{}
}
function startCloudPolling(){if(cloudPollTimer)clearInterval(cloudPollTimer);if(cloudToken()&&state.cloud?.url)cloudPollTimer=setInterval(cloudPoll,30000)}
async function startRealtimeSync(){
  if(syncStreamAbort){syncStreamAbort.abort();syncStreamAbort=null}
  if(syncStreamRetryTimer){clearTimeout(syncStreamRetryTimer);syncStreamRetryTimer=null}
  if(!cloudToken()||!state.cloud?.url||!navigator.onLine)return;
  const controller=new AbortController();syncStreamAbort=controller;
  try{
    const r=await fetch(state.cloud.url+"/events",{headers:cloudHeaders(),signal:controller.signal,cache:"no-store"});
    if(!r.ok||!r.body)throw new Error("Live stream unavailable");
    setCloud("Live multi-device sync active","online");
    const reader=r.body.getReader(),decoder=new TextDecoder();let buffer="";
    while(true){
      const {value,done}=await reader.read();if(done)break;
      buffer+=decoder.decode(value,{stream:true});
      const blocks=buffer.split("\n\n");buffer=blocks.pop()||"";
      for(const block of blocks){
        const dataLine=block.split("\n").find(line=>line.startsWith("data:"));
        if(!dataLine)continue;
        let ev;try{ev=JSON.parse(dataLine.slice(5).trim())}catch{continue}
        const rev=Number(ev.revision||0);
        if(rev>Number(state.cloud.revision||0)){
          if(outboxCount())await flushSyncOutbox(true);
          if(!outboxCount())await cloudPull(true,true)
        }
      }
    }
    throw new Error("Live stream closed")
  }catch(e){
    if(controller.signal.aborted)return;
    setCloud(navigator.onLine?"Live sync reconnecting...":"Offline","offline");
    syncStreamRetryTimer=setTimeout(()=>startRealtimeSync(),3000)
  }
}
function renderCloud(){
  $("cloudUrl").value=state.cloud?.url||"";$("cloudMode").value=state.cloud?.mode||"auto";
  const pending=outboxCount();
  setCloud(cloudToken()?`Connected · revision ${state.cloud?.revision||0}${pending?` · ${pending} pending`:""}`:(state.cloud?.url?"Backend configured · login required":"Not connected"),cloudToken()?(pending?"pending":"online"):"offline")
}
window.addEventListener("online",()=>{setCloud(outboxCount()?`Back online · ${outboxCount()} pending`:"Back online","syncing");flushSyncOutbox(true).finally(()=>{startRealtimeSync();cloudPoll()})});
window.addEventListener("offline",()=>{setCloud(`Offline${outboxCount()?` · ${outboxCount()} pending`:""}`,"offline");if(syncStreamAbort)syncStreamAbort.abort()});

async function renderAudit(){if(!$("auditList")||!can("admin"))return;if(!cloudToken()||!state.cloud?.url){$("auditList").innerHTML='<div class="empty">Connect this device to the backend to view the audit trail.</div>';return}$("auditList").innerHTML='<div class="empty">Loading audit trail...</div>';try{const r=await fetch(state.cloud.url+"/audit?limit=150",{headers:cloudHeaders()});const d=await r.json();if(!r.ok)throw new Error(d.error||"Audit load failed");$("auditList").innerHTML=(d.items||[]).length?(d.items||[]).map(a=>`<article class="audit-card"><div><strong>${esc(a.action)}</strong><span>${new Date(a.created_at).toLocaleString()}</span></div><div class="subtle">${esc(a.actor_username||"system")} · ${esc(a.actor_role||"system")}${a.device_id?` · device ${esc(String(a.device_id).slice(0,8))}`:""}</div><pre>${esc(JSON.stringify(a.details||{},null,2))}</pre></article>`).join(""):'<div class="empty">No audit activity yet.</div>'}catch(e){$("auditList").innerHTML=`<div class="empty">Could not load audit trail: ${esc(e.message)}</div>`}}
function exportBackup(){if(!can("admin"))return toast("Primary admin access required.");const b=new Blob([JSON.stringify(snapshot(),null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=`ds-bakery-v13-1-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href)}function importBackup(file){if(!can("admin"))return toast("Primary admin access required.");const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);for(const k of ["products","users","orders","expenses","customCakes","productionPlans","materialPurchases","materials","suppliers","creditPayments","supplierPayments","customers","cashClosings","stockAdjustments","wasteRecords","cashierShifts","refunds","stockMovements"])if(Array.isArray(d[k]))state[k]=d[k];if(d.recipes)state.recipes=d.recipes;enforceSingleAdmin();localSave();renderAll();toast("Backup imported.")}catch{toast("Invalid backup.")}};r.readAsText(file)}async function resetDemo(){if(!can("admin"))return;if(await uiConfirm("Reset all D's Bakery demo data? This cannot be undone.","Reset Data")){DataService.reset();location.reload()}}


async function askValue(label,current){const v=await uiPrompt(label,current??"","text","Edit Data");return v===null?null:v.trim()}
async function askNumber(label,current){const v=await uiPrompt(label,current??0,"number","Edit Data");if(v===null)return null;const n=Number(v);if(Number.isNaN(n)||n<0){toast("Enter a valid number.");return undefined}return n}
async function editProduct(id){
  const p=product(id);if(!p||!can("admin"))return;
  const n=await askValue("Product name",p.name);if(n===null)return;
  const c=await askValue("Category",p.category);if(c===null)return;
  const pr=await askNumber("Selling price (UGX)",p.price);if(pr===null||pr===undefined)return;
  const s=await askNumber("Finished stock",p.stock);if(s===null||s===undefined)return;
  const e=await askValue("Emoji / symbol",p.emoji||"🥐");if(e===null)return;
  if(!n||!c)return toast("Name and category are required.");
  Object.assign(p,{name:n,category:c,price:pr,stock:s,emoji:e||"🥐"});localSave();renderAll();toast("Product updated.")
}
async function deleteProduct(id){
  if(!can("admin"))return;const p=product(id);if(!p)return;
  const used=state.orders.some(o=>o.items.some(i=>i.id===id))||state.productionPlans.some(x=>x.productId===id)||!!state.recipes[String(id)];
  if(used)return toast("This product has recipe/production/sales history. Set its stock to 0 instead of deleting it.");
  if(!await uiConfirm(`Delete ${p.name}?`))return;state.products=state.products.filter(x=>x.id!==id);localSave();renderAll();toast("Product deleted.")
}
async function editMaterial(id){
  const m=material(id);if(!m||!can("admin"))return;
  const n=await askValue("Material name",m.name);if(n===null)return;
  const u=await askValue("Unit e.g. kg, tray, bag",m.unit);if(u===null)return;
  const s=await askNumber("Current stock",m.stock);if(s===null||s===undefined)return;
  const c=await askNumber("Average cost per unit (UGX)",m.cost);if(c===null||c===undefined)return;
  const r=await askNumber("Reorder level",m.reorder);if(r===null||r===undefined)return;
  if(!n||!u)return toast("Name and unit are required.");
  Object.assign(m,{name:n,unit:u,stock:s,cost:c,reorder:r});localSave();renderAll();toast("Raw material updated.")
}
async function deleteMaterial(id){
  if(!can("admin"))return;const m=material(id);if(!m)return;
  const used=Object.values(state.recipes).some(r=>r.items.some(i=>i.materialId===id))||state.materialPurchases.some(p=>p.materialId===id);
  if(used)return toast("This material is used in recipe/purchase history. Remove it from recipes first and keep the history.");
  if(!await uiConfirm(`Delete ${m.name}?`))return;state.materials=state.materials.filter(x=>x.id!==id);localSave();renderAll();toast("Material deleted.")
}
async function editRecipeQty(pid,mid){
  if(!can("admin"))return;const r=recipe(pid),i=r?.items.find(x=>x.materialId===mid);if(!i)return;
  const q=await askNumber(`Quantity of ${material(mid)?.name||"material"} per batch`,i.qty);if(q===null||q===undefined||q<=0)return;
  i.qty=q;localSave();renderAll();toast("Recipe quantity updated.")
}
async function clearRecipe(pid){
  if(!can("admin"))return;if(!await uiConfirm(`Clear recipe for ${product(pid)?.name||"product"}?`))return;
  delete state.recipes[String(pid)];localSave();renderAll();toast("Recipe cleared.")
}
async function editProduction(id){
  if(!can("admin"))return;const p=state.productionPlans.find(x=>x.id===id);if(!p)return;
  if(p.status==="Completed")return toast("Completed batches are locked because stock has already changed.");
  const q=await askNumber("Quantity to produce",p.qty);if(q===null||q===undefined||q<=0)return;
  const due=await askValue("Due date/time (YYYY-MM-DDTHH:MM)",String(p.due).slice(0,16));if(due===null)return;
  const note=await askValue("Notes / shift",p.note||"");if(note===null)return;
  p.qty=q;p.due=due;p.note=note;localSave();renderAll();toast("Production plan updated.")
}
async function editExpense(id){
  if(!can("admin"))return;const e=state.expenses.find(x=>x.id===id);if(!e)return;
  if(e.linkedPurchaseId)return toast("Ingredient purchase expenses are linked to purchase history and should not be edited here.");
  const t=await askValue("Expense title",e.title);if(t===null)return;
  const a=await askNumber("Amount (UGX)",e.amount);if(a===null||a===undefined)return;
  const c=await askValue("Category",e.category);if(c===null)return;
  const d=await askValue("Date (YYYY-MM-DD)",String(e.date).slice(0,10));if(d===null)return;
  if(!t)return toast("Expense title is required.");
  e.title=t;e.amount=a;e.category=c||"Other";e.date=new Date(d+"T12:00:00").toISOString();localSave();renderAll();toast("Expense updated.")
}
async function deleteExpense(id){
  if(!can("admin"))return;const e=state.expenses.find(x=>x.id===id);if(!e)return;
  if(e.linkedPurchaseId)return toast("This expense is linked to a material purchase and cannot be deleted separately.");
  if(!await uiConfirm(`Delete expense: ${e.title}?`))return;state.expenses=state.expenses.filter(x=>x.id!==id);localSave();renderAll();toast("Expense deleted.")
}
async function editSupplier(id){
  if(!can("admin"))return;const s=supplierById(id);if(!s)return;
  const n=await askValue("Supplier name",s.name);if(n===null)return;
  const p=await askValue("Phone",s.phone||"");if(p===null)return;
  const e=await askValue("Email",s.email||"");if(e===null)return;
  const a=await askValue("Address / location",s.address||"");if(a===null)return;
  if(!n)return toast("Supplier name is required.");
  Object.assign(s,{name:n,phone:p,email:e,address:a});localSave();renderAll();toast("Supplier updated.")
}
async function deleteSupplier(id){
  if(!can("admin"))return;const s=supplierById(id);if(!s)return;
  if(state.materialPurchases.some(p=>Number(p.supplierId)===id)||state.supplierPayments.some(p=>Number(p.supplierId)===id))return toast("This supplier has purchase/payment history and cannot be deleted.");
  if(!await uiConfirm(`Delete ${s.name}?`))return;state.suppliers=state.suppliers.filter(x=>x.id!==id);localSave();renderAll();toast("Supplier deleted.")
}
async function editCustomer(id,phone){
  if(!can("admin"))return;
  let c=state.customers.find(x=>x.id===id)||state.customers.find(x=>normalizedPhone(x.phone)===normalizedPhone(phone));
  if(!c){const d=customerDirectory().find(x=>normalizedPhone(x.phone)===normalizedPhone(phone));if(!d)return;upsertCustomer(d.name,d.phone,{email:d.email,address:d.address,notes:d.notes});c=state.customers.find(x=>normalizedPhone(x.phone)===normalizedPhone(phone))}
  const old=normalizedPhone(c.phone),n=await askValue("Customer name",c.name);if(n===null)return;
  const p=await askValue("Phone number",c.phone);if(p===null)return;const np=normalizedPhone(p);
  const e=await askValue("Email",c.email||"");if(e===null)return;
  const a=await askValue("Address",c.address||"");if(a===null)return;
  const notes=await askValue("Notes",c.notes||"");if(notes===null)return;
  const creditLimit=await askNumber("Credit limit (UGX)",Number(c.creditLimit)||0);if(creditLimit===null||creditLimit===undefined)return;
  const creditDays=await askNumber("Credit due period (days)",Number(c.creditDays)||7);if(creditDays===null||creditDays===undefined||creditDays<1)return toast("Credit days must be at least 1.");
  if(!n||!np)return toast("Customer name and phone are required.");
  c.name=n;c.phone=np;c.email=e;c.address=a;c.notes=notes;c.creditLimit=creditLimit;c.creditDays=creditDays;
  if(old!==np){state.orders.forEach(o=>{if(normalizedPhone(o.phone)===old)o.phone=np});state.customCakes.forEach(x=>{if(normalizedPhone(x.phone)===old)x.phone=np});state.users.filter(u=>u.role==="customer"&&normalizedPhone(u.username)===old).forEach(u=>u.username=np)}
  localSave();renderAll();toast("Customer updated.")
}
async function deleteCustomer(id,phone){
  if(!can("admin"))return;const np=normalizedPhone(phone);
  if(customerOrders(np).length||customerCakes(np).length)return toast("This customer has order/cake history and cannot be deleted. Edit the profile instead.");
  const c=state.customers.find(x=>x.id===id)||state.customers.find(x=>normalizedPhone(x.phone)===np);if(!c)return;
  if(!await uiConfirm(`Delete ${c.name}?`))return;state.customers=state.customers.filter(x=>x.id!==c.id);localSave();renderAll();toast("Customer deleted.")
}
async function editEmployee(id){
  if(!can("admin"))return;const u=state.users.find(x=>x.id===id&&x.role!=="customer");if(!u)return;
  const n=await askValue("Full name",u.name);if(n===null)return;const un=await askValue("Username",u.username);if(un===null)return;
  const pw=await askValue("Password",u.password);if(pw===null)return;
  let role="admin";
  if(id!==PRIMARY_ADMIN_ID){role=await askValue("Role: cashier, baker or rider",u.role);if(role===null)return;if(!["cashier","baker","rider"].includes(role))return toast("Only the primary administrator can have the admin role.")}
  if(!n||!un||!pw)return toast("Enter valid staff details.");
  if(state.users.some(x=>x.id!==id&&x.username===un))return toast("Username already exists.");
  Object.assign(u,{name:n,username:un,password:pw,role});if(state.session?.id===id)state.session={id:u.id,name:u.name,username:u.username,role:u.role};
  localSave();renderAll();toast("Staff account updated.")
}
async function deleteEmployee(id){
  if(!can("admin"))return;const u=state.users.find(x=>x.id===id);if(!u)return;
  if(id===PRIMARY_ADMIN_ID)return toast("The primary administrator cannot be deleted.");
  if(state.session?.id===id)return toast("You cannot delete the account currently logged in.");
  if(!await uiConfirm(`Delete staff account for ${u.name}?`))return;state.users=state.users.filter(x=>x.id!==id);localSave();renderAll();toast("Staff account deleted.")
}
async function editCake(id){
  if(!can("admin"))return;const c=state.customCakes.find(x=>x.id===id);if(!c)return;
  const n=await askValue("Customer name",c.customer);if(n===null)return;const p=await askValue("Phone",c.phone);if(p===null)return;
  const s=await askValue("Cake size",c.size);if(s===null)return;const f=await askValue("Flavor",c.flavor);if(f===null)return;
  const d=await askValue("Due date (YYYY-MM-DD)",c.date);if(d===null)return;const b=await askNumber("Budget (UGX)",c.budget);if(b===null||b===undefined)return;
  const m=await askValue("Message / design notes",c.message||"");if(m===null)return;
  Object.assign(c,{customer:n,phone:p,size:s,flavor:f,date:d,budget:b,message:m});upsertCustomer(n,p);localSave();renderAll();toast("Cake order updated.")
}
async function editOrderContact(id){
  if(!can("admin"))return;const o=state.orders.find(x=>x.id===id);if(!o)return;
  const n=await askValue("Customer name",o.customer);if(n===null)return;const p=await askValue("Phone",o.phone||"");if(p===null)return;
  let a=o.address||"";if(o.delivery){a=await askValue("Delivery address",o.address||"");if(a===null)return}
  o.customer=n||o.customer;o.phone=p;if(o.delivery)o.address=a;upsertCustomer(o.customer,o.phone);localSave();renderAll();toast("Order details corrected.")
}
async function voidOrder(id){
  if(!can("admin"))return;const o=state.orders.find(x=>x.id===id);if(!o||o.status==="Cancelled")return;
  if(!await uiConfirm("Void this sale? It remains in receipt history and finished product stock will be restored."))return;
  o.items.forEach(i=>{const p=product(i.id);if(p)p.stock+=i.qty});o.status="Cancelled";o.paymentStatus="Voided";o.amountPaid=0;o.balanceDue=0;o.voidedAt=new Date().toISOString();localSave();renderAll();toast("Sale voided and stock restored.")
}
async function deleteOrder(id){
  if(!can("admin"))return toast("Primary Admin access required.");
  const o=state.orders.find(x=>x.id===Number(id));if(!o)return toast("Order not found.");
  const receiptNo=String(o.id).slice(-8);
  const linkedPayments=state.creditPayments.filter(p=>Number(p.orderId)===Number(o.id));
  const warning=`Permanently delete order #${receiptNo} for ${o.customer||"Walk-in"}?\n\nThis removes it from receipts, reports, customer history and credit records. ${o.status==="Cancelled"?"Stock was already restored when this order was voided.":"Sold finished-product stock will be restored."}${linkedPayments.length?` ${linkedPayments.length} linked credit payment record${linkedPayments.length===1?"":"s"} will also be deleted.`:""}`;
  if(!await uiConfirm(warning,"Delete Order Permanently"))return;

  // Restore sold stock only if it has not already been restored by a prior void.
  if(o.status!=="Cancelled"&&o.paymentStatus!=="Voided"){
    (o.items||[]).forEach(i=>{const p=product(i.id);if(p)p.stock+=(Number(i.qty)||0)});
  }

  // Remove linked credit-payment history to avoid orphan balances/payments.
  state.creditPayments=state.creditPayments.filter(p=>Number(p.orderId)!==Number(o.id));
  state.orders=state.orders.filter(x=>Number(x.id)!==Number(o.id));

  // Close an open receipt modal if this was the receipt being viewed.
  $("receiptBackdrop")?.classList.add("hidden");

  localSave();renderAll();toast(`Order #${receiptNo} deleted permanently.`);
}
function parseCsv(text){
  const rows=[];let row=[],field="",quoted=false;
  for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'){if(quoted&&n==='"'){field+='"';i++}else quoted=!quoted}else if(c===","&&!quoted){row.push(field);field=""}else if((c==="\n"||c==="\r")&&!quoted){if(c==="\r"&&n==="\n")i++;row.push(field);if(row.some(x=>x.trim()!==""))rows.push(row);row=[];field=""}else field+=c}
  row.push(field);if(row.some(x=>x.trim()!==""))rows.push(row);if(rows.length<2)return[];
  const headers=rows[0].map(h=>h.trim().toLowerCase());return rows.slice(1).map(r=>Object.fromEntries(headers.map((h,i)=>[h,(r[i]??"").trim()])))
}
function downloadCsvTemplate(){
  const t=$("bulkDataset").value,data={
   products:["name,category,price,stock,emoji","White Bread,Bread,5000,20,🍞"],
   materials:["name,unit,stock,cost,reorder","Wheat Flour,kg,50,4500,10"],
   customers:["name,phone,email,address,notes","Example Customer,0700000000,,Kampala,"],
   suppliers:["name,phone,email,address","Example Supplier,0700000001,,Kampala"],
   expenses:["title,amount,category,date","Electricity,100000,Utilities,2026-10-01"],
   staff:["name,username,password,role","Cashier One,cashier1,change-me,cashier"]
  };
  const blob=new Blob([data[t].join("\n")],{type:"text/csv"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`bakerypro-${t}-template.csv`;a.click();URL.revokeObjectURL(a.href)
}
function importCsv(){
  if(!can("admin"))return toast("Admin login required.");const file=$("bulkCsvFile").files[0];if(!file)return toast("Choose a CSV file.");
  const type=$("bulkDataset").value,r=new FileReader();r.onload=()=>{try{const rows=parseCsv(r.result);if(!rows.length)return toast("No data rows found.");let count=0;
   if(type==="products")rows.forEach(x=>{if(!x.name||!x.category)return;let p=state.products.find(p=>p.name.toLowerCase()===x.name.toLowerCase());if(!p){p={id:uid()};state.products.push(p)}Object.assign(p,{name:x.name,category:x.category,price:Number(x.price)||0,stock:Number(x.stock)||0,emoji:x.emoji||p.emoji||"🥐"});count++});
   if(type==="materials")rows.forEach(x=>{if(!x.name||!x.unit)return;let m=state.materials.find(m=>m.name.toLowerCase()===x.name.toLowerCase());if(!m){m={id:uid()};state.materials.push(m)}Object.assign(m,{name:x.name,unit:x.unit,stock:Number(x.stock)||0,cost:Number(x.cost)||0,reorder:Number(x.reorder)||0});count++});
   if(type==="customers")rows.forEach(x=>{if(!x.name||!x.phone)return;upsertCustomer(x.name,x.phone,{email:x.email||"",address:x.address||"",notes:x.notes||""});count++});
   if(type==="suppliers")rows.forEach(x=>{if(!x.name)return;let s=state.suppliers.find(s=>s.name.toLowerCase()===x.name.toLowerCase());if(!s){s={id:uid()};state.suppliers.push(s)}Object.assign(s,{name:x.name,phone:x.phone||"",email:x.email||"",address:x.address||""});count++});
   if(type==="expenses")rows.forEach(x=>{if(!x.title)return;state.expenses.unshift({id:uid(),title:x.title,amount:Number(x.amount)||0,category:x.category||"Other",date:x.date?new Date(x.date+"T12:00:00").toISOString():new Date().toISOString()});count++});
   if(type==="staff")rows.forEach(x=>{if(!x.name||!x.username||!x.password||!["cashier","baker","rider"].includes(x.role))return;let u=state.users.find(u=>u.username===x.username);if(!u){u={id:uid()};state.users.push(u)}Object.assign(u,{name:x.name,username:x.username,password:x.password,role:x.role});count++});
   localSave();renderAll();$("bulkCsvFile").value="";toast(`${count} ${type} record${count===1?"":"s"} imported.`)
  }catch(e){toast("CSV import failed.")}};r.readAsText(file)
}


let dialogResolver=null;
function openUIDialog({title="D's Bakery",message="",value=null,type="text",confirmOnly=false,okText="Continue"}={}){
 return new Promise(resolve=>{
  dialogResolver=resolve;$("uiDialogTitle").textContent=title;$("uiDialogMessage").textContent=message;$("uiDialogOk").textContent=okText;
  const input=$("uiDialogInput");input.classList.toggle("hidden",confirmOnly);input.type=type;input.value=value??"";
  $("uiDialogBackdrop").classList.remove("hidden");setTimeout(()=>{if(!confirmOnly){input.focus();input.select()}},30)
 })
}
function closeUIDialog(value){$("uiDialogBackdrop").classList.add("hidden");const r=dialogResolver;dialogResolver=null;if(r)r(value)}
function uiConfirm(message,title="Please Confirm"){return openUIDialog({title,message,confirmOnly:true,okText:"Confirm"})}
function uiPrompt(message,value="",type="text",title="Edit"){return openUIDialog({title,message,value,type,confirmOnly:false,okText:"Save"})}

/* ==================== D'S BAKERY V11 CONTROLS ==================== */
function bakeryLogoURL(){const img=document.querySelector(".brand-logo");return img?.currentSrc||img?.src||"logo.png"}
function actorName(){return state.session?.name||state.session?.username||"System"}
function orderItemUnitPrice(i){return Number(i.price??product(i.id)?.price??0)}
function orderRefunds(orderId){return state.refunds.filter(r=>Number(r.orderId)===Number(orderId)&&r.status!=="Voided")}
function orderRefundedAmount(o){return orderRefunds(o.id).reduce((s,r)=>s+(Number(r.amount)||0),0)}
function orderNetTotal(o){return Math.max(0,(Number(o.total)||0)-orderRefundedAmount(o))}
function refundedQty(orderId,productId){return orderRefunds(orderId).filter(r=>Number(r.productId)===Number(productId)).reduce((s,r)=>s+(Number(r.qty)||0),0)}
function addOrderEvent(o,type,detail=""){
  if(!o)return;o.timeline=Array.isArray(o.timeline)?o.timeline:[];
  o.timeline.push({id:uid(),type,detail:String(detail||""),at:new Date().toISOString(),by:state.session?.username||"system",byName:actorName()})
}
function addStockMovement(itemType,itemId,qty,before,after,reason,refType="",refId=null,note=""){
  const item=stockRecord(itemType,itemId);
  state.stockMovements.unshift({id:uid(),itemType,itemId:Number(itemId),itemName:item?.name||"Item",qty:Number(qty)||0,before:Number(before)||0,after:Number(after)||0,reason,refType,refId,notes:note||"",recordedBy:state.session?.username||"system",recordedByName:actorName(),createdAt:new Date().toISOString()})
}
function refundCashOutflow(r){return r.paymentMethod==="Credit Balance Reduction"?0:Number(r.amount)||0}
function shiftByUser(username=state.session?.username){return state.cashierShifts.find(s=>s.username===username&&s.status==="Open")||null}
function shiftMetrics(shift){
  const start=new Date(shift.openedAt),end=shift.closedAt?new Date(shift.closedAt):new Date(),user=shift.username;
  const orders=state.orders.filter(o=>o.status!=="Cancelled"&&o.recordedBy===user&&new Date(o.createdAt)>=start&&new Date(o.createdAt)<=end);
  const creditPays=state.creditPayments.filter(p=>p.recordedBy===user&&new Date(p.date)>=start&&new Date(p.date)<=end);
  const expenses=state.expenses.filter(e=>e.recordedBy===user&&new Date(e.date)>=start&&new Date(e.date)<=end);
  const refunds=state.refunds.filter(r=>r.status!=="Voided"&&r.recordedBy===user&&new Date(r.createdAt)>=start&&new Date(r.createdAt)<=end);
  const cashSales=orders.filter(o=>o.paymentMethod==="Cash").reduce((s,o)=>s+orderReceived(o),0);
  const cashCredit=creditPays.filter(p=>(p.paymentMethod||"Cash")==="Cash").reduce((s,p)=>s+(Number(p.amount)||0),0);
  const cashExpenses=expenses.filter(e=>(e.paymentMethod||"Cash")==="Cash").reduce((s,e)=>s+(Number(e.amount)||0),0);
  const cashRefunds=refunds.filter(r=>r.paymentMethod==="Cash").reduce((s,r)=>s+(Number(r.amount)||0),0);
  return{cashSales,cashCredit,cashExpenses,cashRefunds,expectedCash:(Number(shift.openingCash)||0)+cashSales+cashCredit-cashExpenses-cashRefunds,orders:orders.length}
}
function normalizeOrderHistory(){
  state.orders.forEach(o=>{if(!Array.isArray(o.timeline))o.timeline=[];(o.items||[]).forEach(i=>{if(i.price===undefined)i.price=product(i.id)?.price||0})});
}
normalizeOrderHistory();

function createOrder(paymentStatus){
  const name=$("customerName").value.trim()||state.session?.name||"",phone=$("customerPhone").value.trim()||(state.session?.role==="customer"?state.session.username:"");
  if(!name||!phone)return toast("Enter customer name and phone.");if(!state.cart.length)return toast("Cart is empty.");if($("needsDelivery").checked&&!$("deliveryAddress").value.trim())return toast("Enter delivery address.");
  for(const i of state.cart){const p=product(i.id);if(!p||p.stock<i.qty)return toast(`Not enough stock for ${p?.name||"item"}.`)}
  const sub=cartSubtotal(),del=$("needsDelivery").checked?5000:0,createdAt=new Date().toISOString();
  const o={id:uid(),source:"online",customer:name,phone,paymentMethod:$("paymentMethod").value,paymentStatus,subtotal:sub,discount:0,deliveryFee:del,total:sub+del,delivery:$("needsDelivery").checked,address:$("deliveryAddress").value.trim(),deliveryStatus:$("needsDelivery").checked?"Awaiting Dispatch":"Pickup",status:"Confirmed",rider:"",createdAt,amountPaid:paymentStatus==="Paid"?sub+del:0,initialPaid:paymentStatus==="Paid"?sub+del:0,balanceDue:0,recordedBy:state.session?.username||"customer",recordedByName:actorName(),items:state.cart.map(i=>({...i,price:product(i.id)?.price||0})),timeline:[]};
  addOrderEvent(o,"Created",`Online/customer order created · ${o.paymentMethod}`);
  state.cart.forEach(i=>{const p=product(i.id),before=p.stock;p.stock-=i.qty;addStockMovement("product",p.id,-i.qty,before,p.stock,"Sale","order",o.id,`Order #${String(o.id).slice(-6)}`)});
  state.orders.unshift(o);upsertCustomer(name,phone);state.cart=[];["customerName","customerPhone","deliveryAddress"].forEach(id=>$(id).value="");$("needsDelivery").checked=false;localSave();renderAll();showReceipt(o.id);toast("Order created.")
}
function completePOS(){
  if(!hasPerm("sales"))return toast("You do not have permission to record sales.");
  if(!state.posCart.length)return toast("Add products to the POS sale.");for(const i of state.posCart)if(product(i.id).stock<i.qty)return toast(`Not enough stock for ${product(i.id).name}.`);
  const sub=posSubtotal(),pct=Math.max(0,Math.min(100,Number($("posDiscount").value)||0)),discount=sub*pct/100,total=sub-discount,method=$("posPayment").value,tender=Number($("posTender").value)||0;
  if(!can("admin")&&pct>0){$("posDiscount").value=0;renderPOS();return toast("Only the Primary Admin can apply a discount.");}
  const name=$("posCustomer").value.trim()||"Walk-in",phone=$("posPhone").value.trim();
  if(method==="Cash"&&tender<total)return toast("Cash received is less than the total.");if(method==="Credit"&&(name==="Walk-in"||!phone))return toast("Credit sales require customer name and phone.");
  if(method==="Credit"&&!can("admin")){const profile=customerProfile(phone),limit=customerCreditLimit(phone),newBalance=Math.max(0,total-Math.max(0,Math.min(total,tender))),projected=customerDebt(phone)+newBalance;if(!profile||limit<=0)return toast("This customer has no admin-approved credit limit.");if(projected>limit)return toast(`Credit limit exceeded. Limit ${money.format(limit)}, projected balance ${money.format(projected)}.`)}
  const finalize=(paidStatus)=>{
    let amountPaid=total,balanceDue=0,initialPaid=total,status=paidStatus||"Paid";if(method==="Credit"){initialPaid=Math.max(0,Math.min(total,tender));amountPaid=initialPaid;balanceDue=Math.max(0,total-initialPaid);status=balanceDue>0?(initialPaid>0?"Part Paid":"Credit"):"Paid"}
    const createdAt=new Date().toISOString(),dueDate=method==="Credit"&&balanceDue>0?new Date(Date.now()+customerCreditDays(phone)*86400000).toISOString():null;
    const o={id:uid(),source:"pos",customer:name,phone,paymentMethod:method,paymentStatus:status,subtotal:sub,discount,deliveryFee:0,total,delivery:false,address:"",deliveryStatus:"Pickup",status:"Completed",rider:"",createdAt,dueDate,amountPaid,initialPaid,balanceDue,recordedBy:state.session.username,recordedByName:actorName(),items:state.posCart.map(i=>({...i,price:product(i.id)?.price||0})),timeline:[]};
    addOrderEvent(o,"Created",`POS sale · ${method} · ${money.format(total)}`);
    state.posCart.forEach(i=>{const p=product(i.id),before=p.stock;p.stock-=i.qty;addStockMovement("product",p.id,-i.qty,before,p.stock,"Sale","order",o.id,`POS order #${String(o.id).slice(-6)}`)});
    state.orders.unshift(o);upsertCustomer(name,phone);state.posCart=[];["posCustomer","posPhone","posTender"].forEach(id=>$(id).value="");$("posDiscount").value=0;localSave();renderAll();showReceipt(o.id);toast(method==="Credit"&&balanceDue>0?"Credit sale recorded.":"Sale completed.")
  };
  if(["MTN Mobile Money","Airtel Money"].includes(method)){if(!phone)return toast("Enter customer phone for Mobile Money.");state.pendingCheckout={type:"pos",method,phone,total,finalize};showPayment(method,phone,total)}else finalize("Paid")
}
function recordPurchase(){
  if(!can("admin"))return toast("Primary admin access required.");const m=material(state.purchaseMaterialId);if(!m)return;
  const q=Number($("purchaseQty").value),total=Number($("purchaseTotalCost").value),supplierId=Number($("purchaseSupplier").value)||null,paid=Math.max(0,Math.min(total,Number($("purchasePaid").value)||0));if(!q||q<=0||!total||total<=0)return toast("Enter purchase quantity and total cost.");
  const before=m.stock,oldValue=m.stock*m.cost,newStock=m.stock+q;m.cost=(oldValue+total)/newStock;m.stock=newStock;const sup=supplierId?supplierById(supplierId):null;
  const rec={id:uid(),materialId:m.id,qty:q,totalCost:total,supplierId,supplier:sup?.name||"",paidAmount:paid,balance:Math.max(0,total-paid),date:new Date().toISOString()};
  state.materialPurchases.unshift(rec);addStockMovement("material",m.id,q,before,m.stock,"Purchase","purchase",rec.id,sup?.name||"Material purchase");
  if(supplierId&&paid>0)state.supplierPayments.unshift({id:uid(),supplierId,amount:paid,date:rec.date,note:`Payment on purchase #${String(rec.id).slice(-6)}`});
  state.expenses.unshift({id:uid(),title:`Purchase: ${m.name}`,amount:total,category:"Ingredients",paymentMethod:"Cash",date:rec.date,linkedPurchaseId:rec.id,recordedBy:state.session.username});
  ["purchaseQty","purchaseTotalCost","purchasePaid"].forEach(id=>$(id).value="");$("purchaseSupplier").value="";$("purchaseBox").classList.add("hidden");state.purchaseMaterialId=null;localSave();renderAll();toast(rec.balance>0?"Purchase recorded with supplier balance.":"Purchase recorded.")
}
function addProduction(){if(!hasPerm("production"))return toast("You do not have production permission.");const pid=Number($("productionProduct").value),q=Number($("productionQty").value),due=$("productionDue").value;if(!pid||!q||q<=0||!due)return toast("Select product, quantity and due time.");const f=feasibility(pid,q);state.productionPlans.unshift({id:uid(),productId:pid,qty:q,due,note:$("productionNote").value.trim(),status:"Planned",createdAt:new Date().toISOString(),recordedBy:state.session.username,startedAt:null,completedAt:null});["productionQty","productionDue","productionNote"].forEach(id=>$(id).value="");localSave();renderAll();toast(f.ok?"Production batch planned.":"Batch planned, but materials are currently insufficient.")}
function startProduction(id){if(!hasPerm("production"))return toast("You do not have production permission.");const p=state.productionPlans.find(x=>x.id===id);if(!p)return;const f=feasibility(p.productId,p.qty);if(!f.ok)return toast("Cannot start: insufficient materials.");p.status="In Progress";p.startedAt=new Date().toISOString();localSave();renderAll()}
function completeProduction(id){
  if(!hasPerm("production"))return toast("You do not have production permission.");const p=state.productionPlans.find(x=>x.id===id);if(!p||p.status!=="In Progress")return;const f=feasibility(p.productId,p.qty);if(!f.ok)return toast("Cannot complete: materials are insufficient.");
  requirements(p.productId,p.qty).forEach(r=>{const m=material(r.materialId),before=m.stock;m.stock-=r.qty;addStockMovement("material",m.id,-r.qty,before,m.stock,"Production Consumption","production",p.id,product(p.productId)?.name||"Batch")});
  const pr=product(p.productId),before=pr.stock;pr.stock+=p.qty;addStockMovement("product",pr.id,p.qty,before,pr.stock,"Production Output","production",p.id,`Batch ${p.qty} units`);
  p.status="Completed";p.completedAt=new Date().toISOString();localSave();renderAll();toast("Batch completed: ingredients deducted and finished stock added.")
}
function cancelProduction(id){if(!hasPerm("production")&&!can("admin"))return toast("You do not have production permission.");const p=state.productionPlans.find(x=>x.id===id);if(!p)return;p.status="Cancelled";localSave();renderAll()}
function addExpense(){if(!hasPerm("expenses"))return toast("You do not have permission to record expenses.");const t=$("expenseTitle").value.trim(),a=Number($("expenseAmount").value);if(!t||!a)return toast("Enter expense title and amount.");state.expenses.unshift({id:uid(),title:t,amount:a,category:$("expenseCategory").value,paymentMethod:$("expensePaymentMethod").value,date:new Date().toISOString(),recordedBy:state.session.username,recordedByName:actorName()});$("expenseTitle").value="";$("expenseAmount").value="";localSave();renderAll()}
function addCustomer(){if(!hasPerm("customers"))return toast("You do not have permission to add customers.");const name=$("newCustomerName").value.trim(),phone=normalizedPhone($("newCustomerPhone").value);if(!name||!phone)return toast("Enter customer name and phone.");const extra={email:$("newCustomerEmail").value.trim(),address:$("newCustomerAddress").value.trim()};if(can("admin")){extra.creditLimit=Math.max(0,Number($("newCustomerCreditLimit").value)||0);extra.creditDays=Math.max(1,Number($("newCustomerCreditDays").value)||7)}upsertCustomer(name,phone,extra);["newCustomerName","newCustomerPhone","newCustomerEmail","newCustomerAddress","newCustomerCreditLimit"].forEach(id=>{$(id).value=""});$("newCustomerCreditDays").value="7";localSave();renderCustomers();toast("Customer added.")}
async function recordCreditPayment(id){
  if(!hasPerm("payments"))return toast("You do not have permission to receive payments.");const o=state.orders.find(x=>x.id===id);if(!o)return;const bal=orderBalance(o);if(bal<=0)return toast("This order has no outstanding balance.");
  const raw=await uiPrompt(`Balance for ${o.customer}: ${money.format(bal)}. Enter payment received:`,bal,"number","Receive Credit Payment");if(raw===null)return;const amount=Number(raw);if(!amount||amount<=0||amount>bal)return toast("Enter a valid amount not above the balance.");
  const pm=await uiPrompt("Payment method: Cash, MTN Mobile Money, Airtel Money or Card","Cash","text","Payment Method");if(pm===null)return;const allowed=["Cash","MTN Mobile Money","Airtel Money","Card"];if(!allowed.includes(pm))return toast("Use Cash, MTN Mobile Money, Airtel Money or Card.");
  o.amountPaid=orderReceived(o)+amount;o.balanceDue=Math.max(0,bal-amount);o.paymentStatus=o.balanceDue<=0?"Paid":"Part Paid";state.creditPayments.unshift({id:uid(),orderId:o.id,customer:o.customer,phone:o.phone,amount,paymentMethod:pm,date:new Date().toISOString(),recordedBy:state.session.username,recordedByName:actorName()});addOrderEvent(o,"Payment",`${money.format(amount)} received via ${pm}`);localSave();renderAll();toast("Customer payment recorded.")
}
function setOrderStatus(id,s){if(!(hasPerm("sales")||hasPerm("production")))return toast("You do not have permission to change order status.");const o=state.orders.find(x=>x.id===id);if(!o)return;const old=o.status;o.status=s;if(s==="Out for Delivery")o.deliveryStatus="In Transit";if(s==="Completed")o.deliveryStatus=o.delivery?"Delivered":"Pickup Completed";addOrderEvent(o,"Status",`${old} → ${s}`);localSave();renderAll()}
function setCakeStatus(id,s){if(!(hasPerm("sales")||hasPerm("production")))return toast("You do not have permission to change cake status.");const c=state.customCakes.find(x=>x.id===id);if(!c)return;c.status=s;localSave();renderOrders()}
function markPaid(id){if(!hasPerm("payments"))return toast("You do not have payment permission.");const o=state.orders.find(x=>x.id===id);if(!o)return;o.paymentStatus="Paid";o.amountPaid=o.total;o.balanceDue=0;addOrderEvent(o,"Payment","Marked fully paid");localSave();renderAll()}
function assignRider(id,u){if(!(hasPerm("delivery")||hasPerm("sales")))return toast("You do not have delivery assignment permission.");const o=state.orders.find(x=>x.id===id);if(o){o.rider=u;addOrderEvent(o,"Delivery",u?`Assigned rider ${u}`:"Rider unassigned");localSave();renderDelivery()}}
function setDeliveryStatus(id,s){if(!hasPerm("delivery"))return toast("You do not have delivery permission.");const o=state.orders.find(x=>x.id===id);if(!o)return;if(state.session?.role==="rider"&&o.rider&&o.rider!==state.session.username)return toast("Assigned to another rider.");const old=o.deliveryStatus;o.deliveryStatus=s;if(s==="Delivered")o.status="Completed";addOrderEvent(o,"Delivery",`${old} → ${s}`);localSave();renderAll()}
function recordWaste(){
  if(!hasPerm("waste"))return toast("You do not have permission to record waste.");const type=$("wasteType").value,id=Number($("wasteItem").value),q=Number($("wasteQty").value),item=stockRecord(type,id);
  if(!item||!Number.isFinite(q)||q<=0)return toast("Choose an item and enter the wasted quantity.");if(item.stock<q)return toast("Waste quantity is greater than available stock.");
  const before=item.stock,cost=wasteUnitCost(type,id),rec={id:uid(),itemType:type,itemId:id,itemName:item.name,quantity:q,reason:$("wasteReason").value,note:$("wasteNote").value.trim(),unitCost:cost,value:cost*q,before,after:item.stock-q,recordedBy:state.session.username,recordedByName:actorName(),createdAt:new Date().toISOString(),status:"Recorded"};
  item.stock-=q;state.wasteRecords.unshift(rec);addStockMovement(type,id,-q,before,item.stock,"Waste / Damage","waste",rec.id,rec.reason);$("wasteQty").value="";$("wasteNote").value="";localSave();renderAll();toast("Waste recorded and stock reduced.")
}
async function voidWaste(id){if(!can("admin"))return;const w=state.wasteRecords.find(x=>x.id===id);if(!w||w.status==="Voided")return;const item=stockRecord(w.itemType,w.itemId);if(!item)return toast("Linked stock item no longer exists.");if(!await uiConfirm(`Void this waste record and restore ${num.format(w.quantity)} to ${w.itemName}?`,"Void Waste Record"))return;const before=item.stock;item.stock+=w.quantity;w.status="Voided";w.voidedAt=new Date().toISOString();w.voidedBy=state.session.username;addStockMovement(w.itemType,w.itemId,w.quantity,before,item.stock,"Waste Reversal","waste",w.id,"Admin void");localSave();renderAll();toast("Waste record voided and stock restored.")}
function recordStockAdjustment(){
  if(!can("admin"))return toast("Primary Admin access required.");const type=$("adjustmentType").value,id=Number($("adjustmentItem").value),q=Number($("adjustmentQty").value),item=stockRecord(type,id);if(!item||!Number.isFinite(q)||q===0)return toast("Choose an item and enter a non-zero stock change.");if(item.stock+q<0)return toast("Adjustment would make stock negative.");
  const before=item.stock,rec={id:uid(),itemType:type,itemId:id,itemName:item.name,quantity:q,reason:$("adjustmentReason").value,note:$("adjustmentNote").value.trim(),before,after:item.stock+q,recordedBy:state.session.username,recordedByName:actorName(),createdAt:new Date().toISOString(),status:"Applied"};
  item.stock+=q;state.stockAdjustments.unshift(rec);addStockMovement(type,id,q,before,item.stock,"Manual Adjustment","adjustment",rec.id,rec.reason);$("adjustmentQty").value="";$("adjustmentNote").value="";localSave();renderAll();toast("Stock adjustment applied and recorded.")
}
async function reverseStockAdjustment(id){if(!can("admin"))return;const a=state.stockAdjustments.find(x=>x.id===id);if(!a||a.status==="Reversed")return;const item=stockRecord(a.itemType,a.itemId);if(!item)return toast("The linked stock item no longer exists.");if(item.stock-a.quantity<0)return toast("Cannot reverse because current stock is too low.");if(!await uiConfirm(`Reverse the ${a.quantity>0?"+":""}${a.quantity} adjustment for ${a.itemName}?`,"Reverse Adjustment"))return;const before=item.stock;item.stock-=a.quantity;a.status="Reversed";a.reversedAt=new Date().toISOString();a.reversedBy=state.session.username;addStockMovement(a.itemType,a.itemId,-a.quantity,before,item.stock,"Adjustment Reversal","adjustment",a.id,"Admin reversal");localSave();renderAll();toast("Stock adjustment reversed.")}
async function setMaterialStock(id){if(!can("admin"))return toast("Primary admin access required.");const m=material(id),v=await uiPrompt(`Set ${m.name} stock (${m.unit})`,m.stock,"number","Adjust Raw Material Stock");if(v===null)return;const n=Number(v);if(Number.isNaN(n)||n<0)return toast("Invalid stock.");const before=m.stock;m.stock=n;addStockMovement("material",m.id,n-before,before,n,"Admin Stock Set","manual",null,"Set stock");localSave();renderAll()}
function restock(id){if(!can("admin"))return toast("Primary admin access required.");const p=product(id),before=p.stock;p.stock+=5;addStockMovement("product",p.id,5,before,p.stock,"Admin Restock","manual",null,"+5 quick restock");localSave();renderAll()}
async function adjustStock(id){if(!can("admin"))return toast("Primary admin access required.");const p=product(id),v=await uiPrompt(`Set stock for ${p.name}`,p.stock,"number","Adjust Finished Stock");if(v===null)return;const n=Number(v);if(Number.isNaN(n)||n<0)return;const before=p.stock;p.stock=n;addStockMovement("product",p.id,n-before,before,n,"Admin Stock Set","manual",null,"Set stock");localSave();renderAll()}


/* Customer self-cancellation */
let customerCancelOrderId=null;
function customerOwnsOrder(o){
  return state.session?.role==="customer" && normalizedPhone(o?.phone)===normalizedPhone(state.session.username)
}
function customerCanCancel(o){
  return customerOwnsOrder(o) && ["Pending","Confirmed"].includes(o.status)
}
function openCustomerCancel(id){
  const o=state.orders.find(x=>Number(x.id)===Number(id));
  if(!o||!customerOwnsOrder(o))return toast("This order is not available in your account.");
  if(!customerCanCancel(o))return toast("This order can no longer be cancelled automatically. Please contact D's Bakery.");
  customerCancelOrderId=o.id;
  $("customerCancelTitle").textContent=`Cancel Order #${String(o.id).slice(-6)}`;
  $("customerCancelReason").value="";
  $("customerCancelDetails").value="";
  $("customerCancelBackdrop").classList.remove("hidden");
}
function submitCustomerCancellation(){
  const o=state.orders.find(x=>Number(x.id)===Number(customerCancelOrderId));
  if(!o||!customerCanCancel(o)){$("customerCancelBackdrop").classList.add("hidden");customerCancelOrderId=null;return toast("This order can no longer be cancelled automatically.");}
  const reason=$("customerCancelReason").value.trim(),details=$("customerCancelDetails").value.trim();
  if(!reason)return toast("Please select why you are cancelling the order.");
  if(reason==="Other"&&!details)return toast("Please briefly explain the cancellation reason.");
  const fullReason=details?`${reason}: ${details}`:reason;

  // Restore any sold stock that has not already been returned/refunded.
  (o.items||[]).forEach(i=>{
    const p=product(i.id),qty=Math.max(0,(Number(i.qty)||0)-refundedQty(o.id,i.id));
    if(p&&qty>0){
      const before=p.stock;
      p.stock+=qty;
      addStockMovement("product",p.id,qty,before,p.stock,"Customer Cancellation","order",o.id,fullReason)
    }
  });

  const paid=orderReceived(o);
  o.status="Cancelled";
  o.cancellationReason=fullReason;
  o.cancelledAt=new Date().toISOString();
  o.cancelledBy="Customer";
  o.cancelledByName=state.session?.name||o.customer||"Customer";
  o.balanceDue=0;
  o.paymentStatus=paid>0?"Refund Pending":"Cancelled";
  addOrderEvent(o,"Customer Cancelled",fullReason);

  $("customerCancelBackdrop").classList.add("hidden");
  customerCancelOrderId=null;
  localSave();renderAll();
  toast(paid>0?"Order cancelled. Your payment is marked Refund Pending.":"Order cancelled successfully.")
}
function customerOrderCard(o){
  const items=(o.items||[]).map(i=>`${i.qty}× ${product(i.id)?.name||"Product"}`).join(", ");
  const canCancel=customerCanCancel(o);
  return `<article class="order-card customer-order-card">
    <div class="order-card-grid">
      <div>
        <strong>#${String(o.id).slice(-6)} · ${esc(o.customer)}</strong>
        <div class="subtle">${esc(items)}</div>
        <div class="subtle">${new Date(o.createdAt).toLocaleString()}</div>
        ${o.delivery?`<div class="subtle">Delivery: ${esc(o.address)}</div>`:""}
        ${o.cancellationReason?`<div class="cancellation-note"><strong>Cancellation reason:</strong> ${esc(o.cancellationReason)}</div>`:""}
      </div>
      <div>
        <span class="status ${esc(o.status)}">${esc(o.status)}</span>
        <span class="status">${esc(o.paymentStatus)}</span>
        <div class="price">${money.format(orderNetTotal(o))}</div>
      </div>
    </div>
    <div class="order-actions">
      <button class="small-btn" onclick="showOrderDetails(${o.id})">Details</button>
      <button class="small-btn" onclick="showReceipt(${o.id})">Receipt</button>
      ${canCancel?`<button class="small-btn customer-cancel-btn" onclick="openCustomerCancel(${o.id})">Cancel Order</button>`:""}
      ${!canCancel&&o.status!=="Cancelled"&&!["Completed"].includes(o.status)?`<span class="subtle">Contact the bakery to cancel after production starts.</span>`:""}
    </div>
  </article>`
}
function renderCustomerOrders(){
  if(state.session?.role!=="customer")return;
  const phone=normalizedPhone(state.session.username);
  const os=state.orders.filter(o=>normalizedPhone(o.phone)===phone);
  const cs=state.customCakes.filter(c=>normalizedPhone(c.phone)===phone);
  $("customerOrders").innerHTML=[...os.map(customerOrderCard),...cs.map(cakeCard)].join("")||`<div class="empty">You have no orders yet.</div>`
}

/* Staff-specific permissions */
let editingPermissionsUserId=null;
function addEmployee(){
  if(!can("admin"))return;const n=$("employeeName").value.trim(),u=$("employeeUsername").value.trim(),p=$("employeePassword").value,role=$("employeeRole").value;if(!n||!u||!p)return toast("Complete employee details.");if(!["cashier","baker","rider"].includes(role))return toast("Choose cashier, baker or rider.");if(state.users.some(x=>x.username===u))return toast("Username exists.");
  state.users.push({id:uid(),name:n,username:u,password:p,role,permissions:roleDefaultPermissions(role)});["employeeName","employeeUsername","employeePassword"].forEach(id=>$(id).value="");localSave();renderEmployees();toast("Staff account created. Review its permissions if needed.")
}
function permissionSummary(u){normalizeUserPermissions(u);return PERMISSION_KEYS.filter(k=>u.permissions?.[k]).map(k=>PERMISSION_LABELS[k].replace("Record ","").replace("Open & close ","")).join(" · ")}
function renderEmployees(){
  $("employeeList").innerHTML=state.users.filter(u=>u.role!=="customer").map(u=>{normalizeUserPermissions(u);return`<div class="employee-card editable-row"><div><strong>${esc(u.name)}</strong><div class="subtle">@${esc(u.username)} · ${esc(u.role)}</div><small class="permission-summary">${u.id===PRIMARY_ADMIN_ID?"All permissions":esc(permissionSummary(u)||"No operational permissions")}</small></div>${can("admin")?`<div class="inline-actions"><button class="small-btn" onclick="editEmployee(${u.id})">Edit</button>${u.id===PRIMARY_ADMIN_ID?`<span class="status">Primary Admin</span>`:`<button class="small-btn" onclick="editStaffPermissions(${u.id})">Permissions</button><button class="small-btn danger-lite" onclick="deleteEmployee(${u.id})">Delete</button>`}</div>`:""}</div>`}).join("")
}
function editStaffPermissions(id){
  if(!can("admin"))return;const u=state.users.find(x=>x.id===Number(id)&&x.role!=="customer");if(!u||u.id===PRIMARY_ADMIN_ID)return;normalizeUserPermissions(u);editingPermissionsUserId=u.id;$("permissionsTitle").textContent=`Permissions · ${u.name}`;$("permissionsGrid").innerHTML=PERMISSION_KEYS.map(k=>`<label class="permission-option"><input type="checkbox" data-perm-key="${k}" ${u.permissions[k]?"checked":""}/><span><strong>${esc(PERMISSION_LABELS[k])}</strong><small>${k==="refunds"?"Can return items and issue refunds.":k==="shifts"?"Can open/close their own cash shift.":"Operational permission; saved-data editing remains admin-only."}</small></span></label>`).join("");$("permissionsBackdrop").classList.remove("hidden")
}
function saveStaffPermissions(){
  if(!can("admin")||!editingPermissionsUserId)return;const u=state.users.find(x=>x.id===editingPermissionsUserId);if(!u)return;$("permissionsGrid").querySelectorAll("[data-perm-key]").forEach(el=>u.permissions[el.dataset.permKey]=el.checked);localSave();$("permissionsBackdrop").classList.add("hidden");editingPermissionsUserId=null;renderAll();toast("Staff permissions updated.")
}
async function editEmployee(id){
  if(!can("admin"))return;const u=state.users.find(x=>x.id===id&&x.role!=="customer");if(!u)return;const oldRole=u.role;
  const n=await askValue("Full name",u.name);if(n===null)return;const un=await askValue("Username",u.username);if(un===null)return;const pw=await askValue("Password",u.password);if(pw===null)return;let role="admin";
  if(id!==PRIMARY_ADMIN_ID){role=await askValue("Role: cashier, baker or rider",u.role);if(role===null)return;if(!["cashier","baker","rider"].includes(role))return toast("Only the primary administrator can have the admin role.")}
  if(!n||!un||!pw)return toast("Enter valid staff details.");if(state.users.some(x=>x.id!==id&&x.username===un))return toast("Username already exists.");Object.assign(u,{name:n,username:un,password:pw,role});if(role!==oldRole&&id!==PRIMARY_ADMIN_ID)u.permissions=roleDefaultPermissions(role);normalizeUserPermissions(u);if(state.session?.id===id)state.session={id:u.id,name:u.name,username:u.username,role:u.role};localSave();renderAll();toast("Staff account updated.")
}

/* Cashier shifts */
function renderCashierShifts(){
  if(!$("shiftCurrent"))return;const mine=shiftByUser();const allowed=hasPerm("shifts");
  $("openShiftForm").classList.toggle("hidden",!!mine||!allowed);$("closeShiftForm").classList.toggle("hidden",!mine||!allowed);
  if(mine){const m=shiftMetrics(mine);$("shiftCurrent").innerHTML=`<div class="shift-live"><div><span class="eyebrow">Open Shift</span><h3>${esc(mine.recordedByName||mine.username)}</h3><div class="subtle">Opened ${new Date(mine.openedAt).toLocaleString()} · Opening cash ${money.format(mine.openingCash)}</div></div><div class="shift-metrics"><span>Cash sales <b>${money.format(m.cashSales)}</b></span><span>Cash payments <b>${money.format(m.cashCredit)}</b></span><span>Cash expenses <b>${money.format(m.cashExpenses)}</b></span><span>Cash refunds <b>${money.format(m.cashRefunds)}</b></span><span>Expected cash <b>${money.format(m.expectedCash)}</b></span></div></div>`}else $("shiftCurrent").innerHTML=allowed?`<div class="empty">You do not have an open shift.</div>`:`<div class="empty">You do not have cashier-shift permission.</div>`;
  const list=(can("admin")?state.cashierShifts:state.cashierShifts.filter(s=>s.username===state.session?.username)).slice().sort((a,b)=>new Date(b.openedAt)-new Date(a.openedAt));
  $("shiftList").innerHTML=list.length?list.map(s=>`<article class="shift-card"><div><strong>${esc(s.recordedByName||s.username)} · ${esc(s.status)}</strong><div class="subtle">${new Date(s.openedAt).toLocaleString()}${s.closedAt?` → ${new Date(s.closedAt).toLocaleString()}`:""}</div></div><div><span>Opening ${money.format(s.openingCash)}</span>${s.status==="Closed"?`<br><span>Expected ${money.format(s.expectedCash)}</span><br><span>Actual ${money.format(s.actualCash)}</span><br><strong class="${s.difference<0?"negative":"positive"}">${s.difference<0?"Short":"Over"} ${money.format(Math.abs(s.difference))}</strong>`:""}</div></article>`).join(""):`<div class="empty">No cashier shifts yet.</div>`
}
function openCashierShift(){if(!hasPerm("shifts"))return toast("You do not have shift permission.");if(shiftByUser())return toast("You already have an open shift.");const opening=Math.max(0,Number($("shiftOpeningCash").value)||0),rec={id:uid(),username:state.session.username,recordedByName:actorName(),openingCash:opening,openNote:$("shiftOpenNote").value.trim(),openedAt:new Date().toISOString(),status:"Open"};state.cashierShifts.unshift(rec);$("shiftOpeningCash").value="";$("shiftOpenNote").value="";localSave();renderAll();toast("Cashier shift opened.")}
function closeCashierShift(){if(!hasPerm("shifts"))return toast("You do not have shift permission.");const shift=shiftByUser();if(!shift)return toast("No open shift.");const actual=Number($("shiftActualCash").value);if(!Number.isFinite(actual)||actual<0)return toast("Enter actual cash counted.");const m=shiftMetrics(shift);Object.assign(shift,m,{actualCash:actual,difference:actual-m.expectedCash,closeNote:$("shiftCloseNote").value.trim(),closedAt:new Date().toISOString(),status:"Closed"});$("shiftActualCash").value="";$("shiftCloseNote").value="";localSave();renderAll();toast("Cashier shift closed.")}

/* Stock movement ledger */
function renderStockMovementLedger(){
  if(!$("movementList"))return;const q=$("movementSearch").value.toLowerCase().trim(),type=$("movementTypeFilter").value;
  const rows=state.stockMovements.filter(m=>(type==="all"||m.itemType===type)&&(!q||`${m.itemName} ${m.reason} ${m.refType} ${m.refId||""} ${m.recordedByName||m.recordedBy||""} ${m.notes||""}`.toLowerCase().includes(q))).slice(0,300);
  $("movementList").innerHTML=rows.length?rows.map(m=>`<article class="movement-card"><div><strong>${esc(m.itemName)} <span class="${m.qty<0?"negative":"positive"}">${m.qty>0?"+":""}${num.format(m.qty)}</span></strong><div class="subtle">${esc(m.reason)} · ${new Date(m.createdAt).toLocaleString()} · ${esc(m.recordedByName||m.recordedBy||"System")}</div><small>${esc(m.refType||"")}${m.refId?` #${esc(String(m.refId).slice(-8))}`:""}${m.notes?` · ${esc(m.notes)}`:""}</small></div><div class="movement-balance"><span>${num.format(m.before)}</span><b>→</b><strong>${num.format(m.after)}</strong></div></article>`).join(""):`<div class="empty">No stock movements found.</div>`
}

/* Returns / refunds */
let refundOrderId=null;
function openRefund(id){
  if(!hasPerm("refunds"))return toast("You do not have refund permission.");const o=state.orders.find(x=>x.id===Number(id));if(!o)return;if(o.status==="Cancelled")return toast("Cancelled orders cannot be refunded.");refundOrderId=o.id;
  const opts=(o.items||[]).map(i=>{const max=Math.max(0,(Number(i.qty)||0)-refundedQty(o.id,i.id));return max>0?`<option value="${i.id}">${esc(product(i.id)?.name||"Product")} · max ${num.format(max)}</option>`:""}).join("");if(!opts)return toast("All items on this order have already been returned/refunded.");
  $("refundTitle").textContent=`Return / Refund · #${String(o.id).slice(-6)}`;$("refundItem").innerHTML=opts;$("refundQty").value="1";$("refundReason").value="Customer Return";$("refundNote").value="";$("refundRestock").checked=true;
  $("refundMethod").value=orderBalance(o)>0?"Credit Balance Reduction":(o.paymentMethod==="Credit"?"Cash":o.paymentMethod);renderRefundPreview();$("refundBackdrop").classList.remove("hidden")
}
function renderRefundPreview(){
  if(!refundOrderId)return;const o=state.orders.find(x=>x.id===refundOrderId),pid=Number($("refundItem").value),item=o?.items.find(i=>Number(i.id)===pid),qty=Number($("refundQty").value)||0;if(!o||!item)return;
  const max=Math.max(0,(Number(item.qty)||0)-refundedQty(o.id,pid)),unit=orderItemUnitPrice(item)*(o.subtotal?1-(Number(o.discount)||0)/Number(o.subtotal):1),amount=Math.max(0,Math.min(qty,max))*unit;$("refundPreview").innerHTML=`Available to return: <strong>${num.format(max)}</strong> · Estimated refund: <strong>${money.format(amount)}</strong>`
}
function processRefund(){
  if(!hasPerm("refunds"))return toast("You do not have refund permission.");const o=state.orders.find(x=>x.id===refundOrderId);if(!o)return;
  const pid=Number($("refundItem").value),item=o.items.find(i=>Number(i.id)===pid),qty=Number($("refundQty").value),max=item?Math.max(0,(Number(item.qty)||0)-refundedQty(o.id,pid)):0;if(!item||!Number.isFinite(qty)||qty<=0||qty>max)return toast("Enter a valid return quantity.");
  const factor=o.subtotal?1-(Number(o.discount)||0)/Number(o.subtotal):1,amount=Math.round(orderItemUnitPrice(item)*qty*factor),method=$("refundMethod").value,restock=$("refundRestock").checked;
  if(method==="Credit Balance Reduction"&&orderBalance(o)<=0)return toast("There is no outstanding credit balance to reduce.");
  const rec={id:uid(),orderId:o.id,productId:pid,productName:product(pid)?.name||"Product",qty,amount,paymentMethod:method,reason:$("refundReason").value,note:$("refundNote").value.trim(),restock,recordedBy:state.session.username,recordedByName:actorName(),createdAt:new Date().toISOString(),status:"Completed"};
  if(method==="Credit Balance Reduction"){const reduction=Math.min(amount,orderBalance(o));rec.amount=reduction;o.balanceDue=Math.max(0,orderBalance(o)-reduction);o.paymentStatus=o.balanceDue<=0?(orderReceived(o)>0?"Paid":"Refunded"):"Part Paid"}
  if(restock){const p=product(pid),before=p.stock;p.stock+=qty;addStockMovement("product",pid,qty,before,p.stock,"Customer Return","refund",rec.id,`Order #${String(o.id).slice(-6)}`)}
  state.refunds.unshift(rec);o.refundedAmount=orderRefundedAmount(o);o.refundStatus=o.refundedAmount>=o.total?"Refunded":"Part Refunded";addOrderEvent(o,"Refund",`${qty} × ${rec.productName} · ${money.format(rec.amount)} via ${method}${restock?" · restocked":""}`);$("refundBackdrop").classList.add("hidden");refundOrderId=null;localSave();renderAll();toast("Return / refund recorded.")
}
function showOrderDetails(id){
  const o=state.orders.find(x=>x.id===Number(id));if(!o)return;
  const events=[{type:"Created",detail:`${o.source||"order"} · ${o.paymentMethod}`,at:o.createdAt,byName:o.recordedByName||o.recordedBy||"System"},...(Array.isArray(o.timeline)?o.timeline:[])].filter((e,i)=>!(i>0&&e.type==="Created"&&e.at===o.createdAt));
  const refunds=orderRefunds(o.id);
  $("orderDetailContent").innerHTML=`<span class="eyebrow">Order Details</span><h2>#${String(o.id).slice(-8)} · ${esc(o.customer||"Walk-in")}</h2>
  <div class="order-detail-grid">
    <div><span>Gross total</span><strong>${money.format(o.total)}</strong></div>
    <div><span>Refunded</span><strong>${money.format(orderRefundedAmount(o))}</strong></div>
    <div><span>Net order value</span><strong>${money.format(orderNetTotal(o))}</strong></div>
    <div><span>Payment</span><strong>${esc(o.paymentStatus)}</strong></div>
  </div>
  ${o.cancellationReason?`<div class="cancellation-detail"><strong>Cancellation reason</strong><p>${esc(o.cancellationReason)}</p><small>${o.cancelledAt?new Date(o.cancelledAt).toLocaleString():""} · ${esc(o.cancelledByName||o.cancelledBy||"Customer")}</small></div>`:""}
  <h4>Items</h4><div class="detail-items">${(o.items||[]).map(i=>`<div><span>${num.format(i.qty)} × ${esc(product(i.id)?.name||"Product")}</span><strong>${money.format(orderItemUnitPrice(i)*i.qty)}</strong></div>`).join("")}</div>
  ${refunds.length?`<h4>Returns / Refunds</h4><div class="detail-items">${refunds.map(r=>`<div><span>${num.format(r.qty)} × ${esc(r.productName)} · ${esc(r.paymentMethod)}</span><strong>-${money.format(r.amount)}</strong></div>`).join("")}</div>`:""}
  <h4>Timeline</h4><div class="order-timeline">${events.sort((a,b)=>new Date(a.at)-new Date(b.at)).map(e=>`<div class="timeline-event"><i></i><div><strong>${esc(e.type)}</strong><span>${new Date(e.at).toLocaleString()} · ${esc(e.byName||e.by||"System")}</span><p>${esc(e.detail||"")}</p></div></div>`).join("")}</div>
  <div class="order-detail-actions">
    ${hasPerm("refunds")&&o.status!=="Cancelled"?`<button class="btn danger" onclick="openRefund(${o.id})">Return / Refund Item</button>`:""}
    ${customerCanCancel(o)?`<button class="btn danger" onclick="openCustomerCancel(${o.id})">Cancel My Order</button>`:""}
    ${can("admin")?`<button class="btn danger admin-delete-order" onclick="deleteOrder(${o.id})">Delete Order Permanently</button>`:""}
  </div>`;
  $("orderDetailBackdrop").classList.remove("hidden")
}
function orderCard(o){
  const items=o.items.map(i=>`${i.qty}× ${product(i.id)?.name||"Product"}`).join(", ");let a="";
  if(hasPerm("sales")||hasPerm("production"))a+=`<select onchange="setOrderStatus(${o.id},this.value)">${["Pending","Confirmed","Baking","Ready","Out for Delivery","Completed","Cancelled"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select>`;
  if(hasPerm("payments")&&o.paymentStatus!=="Paid"&&o.paymentStatus!=="Refunded")a+=`<button class="small-btn" onclick="markPaid(${o.id})">Mark Paid</button>`;
  a+=`<button class="small-btn" onclick="showOrderDetails(${o.id})">Details</button>`;
  if(hasPerm("refunds")&&o.status!=="Cancelled")a+=`<button class="small-btn" onclick="openRefund(${o.id})">Return / Refund</button>`;
  if(can("admin"))a+=`<button class="small-btn" onclick="editOrderContact(${o.id})">Correct Details</button>`;
  if(can("admin")&&o.status!=="Cancelled")a+=`<button class="small-btn danger-lite" onclick="voidOrder(${o.id})">Void</button>`;
  if(can("admin"))a+=`<button class="small-btn danger-delete" onclick="deleteOrder(${o.id})">Delete</button>`;
  a+=`<button class="small-btn" onclick="showReceipt(${o.id})">Receipt</button>`;
  return `<article class="order-card"><div class="order-card-grid"><div><strong>#${String(o.id).slice(-6)} · ${esc(o.customer)}</strong><div class="subtle">${esc(items)}</div><div class="subtle">${new Date(o.createdAt).toLocaleString()} · ${esc(o.recordedByName||o.recordedBy||o.source||"order")}</div>${o.delivery?`<div class="subtle">Delivery: ${esc(o.address)}</div>`:""}${orderRefundedAmount(o)>0?`<div class="refund-badge">${esc(o.refundStatus||"Refund")} · ${money.format(orderRefundedAmount(o))}</div>`:""}</div><div><span class="status">${esc(o.status)}</span> <span class="status">${esc(o.paymentStatus)}</span><div class="price">${money.format(orderNetTotal(o))}</div></div></div><div class="order-actions">${a}</div></article>`
}
function renderReceiptHistory(){
  if(!$("receiptHistoryList"))return;const q=$("receiptSearch").value.toLowerCase().trim(),date=$("receiptDate").value,pf=$("receiptPaymentFilter").value;const list=state.orders.filter(o=>{const hay=`${o.id} ${o.customer||""} ${o.phone||""}`.toLowerCase(),d=new Date(o.createdAt).toISOString().slice(0,10);return(!q||hay.includes(q))&&(!date||d===date)&&(pf==="all"||o.paymentStatus===pf)});$("receiptCount").textContent=list.length;$("receiptValue").textContent=money.format(list.reduce((s,o)=>s+orderNetTotal(o),0));
  $("receiptHistoryList").innerHTML=list.length?list.map(o=>`<article class="receipt-history-card"><div class="receipt-number">#${String(o.id).slice(-8)}</div><div><strong>${esc(o.customer||"Walk-in")}</strong><span>${new Date(o.createdAt).toLocaleString()}</span><small>${esc(o.paymentMethod)} · ${esc(o.paymentStatus)}${orderRefundedAmount(o)>0?` · Refunded ${money.format(orderRefundedAmount(o))}`:""}</small></div><div class="receipt-history-total">${money.format(orderNetTotal(o))}</div><div class="inline-actions"><button class="small-btn" onclick="showOrderDetails(${o.id})">Details</button><button class="small-btn" onclick="showReceipt(${o.id})">View / Print</button>${hasPerm("refunds")&&o.status!=="Cancelled"?`<button class="small-btn" onclick="openRefund(${o.id})">Refund</button>`:""}${can("admin")&&o.status!=="Cancelled"?`<button class="small-btn danger-lite" onclick="voidOrder(${o.id})">Void</button>`:""}${can("admin")?`<button class="small-btn danger-delete" onclick="deleteOrder(${o.id})">Delete</button>`:""}</div></article>`).join(""):`<div class="empty">No receipts found.</div>`
}
function showReceipt(id){
  const o=state.orders.find(x=>x.id===id);if(!o)return;
  const lines=o.items.map(i=>`<div class="receipt-line"><span>${i.qty} × ${esc(product(i.id)?.name||"Product")}</span><span>${money.format(orderItemUnitPrice(i)*i.qty)}</span></div>`).join(""),refs=orderRefunds(o.id),logo=esc(bakeryLogoURL());
  $("receiptContent").innerHTML=`<div class="receipt"><img src="${logo}" class="receipt-logo" alt="D's Bakery logo"><h2>D's Bakery</h2><div style="text-align:center">Fresh Every Day · Sales Receipt</div><hr><div>Receipt: #${String(o.id).slice(-8)}</div><div>Date: ${new Date(o.createdAt).toLocaleString()}</div><div>Customer: ${esc(o.customer)}</div><div>Staff: ${esc(o.recordedByName||o.recordedBy||"")}</div><div>Order status: ${esc(o.status)}</div>${o.cancellationReason?`<div>Cancellation: ${esc(o.cancellationReason)}</div>`:""}<hr>${lines}<hr><div class="receipt-line"><span>Subtotal</span><strong>${money.format(o.subtotal)}</strong></div>${o.discount?`<div class="receipt-line"><span>Discount</span><strong>-${money.format(o.discount)}</strong></div>`:""}<div class="receipt-line"><span>Delivery</span><strong>${money.format(o.deliveryFee)}</strong></div><div class="receipt-line"><span>ORIGINAL TOTAL</span><strong>${money.format(o.total)}</strong></div>${refs.length?`<hr>${refs.map(r=>`<div class="receipt-line"><span>Refund: ${esc(r.productName)} × ${num.format(r.qty)}</span><strong>-${money.format(r.amount)}</strong></div>`).join("")}<div class="receipt-line"><span>NET ORDER VALUE</span><strong>${money.format(orderNetTotal(o))}</strong></div>`:""}<hr><div>Payment: ${esc(o.paymentMethod)} (${esc(o.paymentStatus)})</div>${orderBalance(o)>0?`<div class="receipt-line"><span>Amount Paid</span><strong>${money.format(orderReceived(o))}</strong></div><div class="receipt-line"><span>Balance Due</span><strong>${money.format(orderBalance(o))}</strong></div>`:""}${o.paymentStatus==="Refund Pending"?`<div class="refund-pending-note">Refund is pending bakery processing.</div>`:""}<div style="text-align:center;margin-top:18px">Thank you!</div></div>`;$("receiptBackdrop").classList.remove("hidden")
}
async function editOrderContact(id){if(!can("admin"))return;const o=state.orders.find(x=>x.id===id);if(!o)return;const n=await askValue("Customer name",o.customer);if(n===null)return;const p=await askValue("Phone",o.phone||"");if(p===null)return;let a=o.address||"";if(o.delivery){a=await askValue("Delivery address",o.address||"");if(a===null)return}const old=`${o.customer} / ${o.phone||""}`;o.customer=n||o.customer;o.phone=p;if(o.delivery)o.address=a;upsertCustomer(o.customer,o.phone);addOrderEvent(o,"Admin Correction",`${old} → ${o.customer} / ${o.phone||""}`);localSave();renderAll();toast("Order details corrected.")}
async function voidOrder(id){
  if(!can("admin"))return;const o=state.orders.find(x=>x.id===id);if(!o||o.status==="Cancelled")return;if(!await uiConfirm("Void this sale? It remains in receipt history and finished product stock will be restored."))return;
  o.items.forEach(i=>{const p=product(i.id),qty=Math.max(0,(Number(i.qty)||0)-refundedQty(o.id,i.id));if(qty>0){const before=p.stock;p.stock+=qty;addStockMovement("product",p.id,qty,before,p.stock,"Order Void","order",o.id,"Restore unreturned sold stock")}});
  o.status="Cancelled";o.paymentStatus="Voided";o.amountPaid=0;o.balanceDue=0;o.voidedAt=new Date().toISOString();addOrderEvent(o,"Voided","Order voided by Primary Admin");localSave();renderAll();toast("Sale voided and remaining sold stock restored.")
}
async function deleteOrder(id){
  if(!can("admin"))return toast("Primary Admin access required.");const o=state.orders.find(x=>x.id===Number(id));if(!o)return toast("Order not found.");const receiptNo=String(o.id).slice(-8),linkedPayments=state.creditPayments.filter(p=>Number(p.orderId)===Number(o.id));
  if(!await uiConfirm(`Permanently delete order #${receiptNo}? This removes its receipt, reports, timeline and linked payments. Stock not already restored will be returned.`,"Delete Order Permanently"))return;
  if(o.status!=="Cancelled"&&o.paymentStatus!=="Voided"){(o.items||[]).forEach(i=>{const p=product(i.id),qty=Math.max(0,(Number(i.qty)||0)-refundedQty(o.id,i.id));if(p&&qty>0){const before=p.stock;p.stock+=qty;addStockMovement("product",p.id,qty,before,p.stock,"Deleted Order Restore","order",o.id,"Permanent delete")}})}
  state.creditPayments=state.creditPayments.filter(p=>Number(p.orderId)!==Number(o.id));state.refunds=state.refunds.filter(r=>Number(r.orderId)!==Number(o.id));state.orders=state.orders.filter(x=>Number(x.id)!==Number(o.id));$("receiptBackdrop")?.classList.add("hidden");$("orderDetailBackdrop")?.classList.add("hidden");localSave();renderAll();toast(`Order #${receiptNo} deleted permanently.`)
}

/* Reports net of refunds */
function renderReports(){
  const {start,end}=reportRange(),orders=state.orders.filter(o=>o.status!=="Cancelled"&&dateInRange(o.createdAt,start,end)),expenses=state.expenses.filter(e=>dateInRange(e.date,start,end)),creditPays=state.creditPayments.filter(p=>dateInRange(p.date,start,end)),refunds=state.refunds.filter(r=>r.status!=="Voided"&&dateInRange(r.createdAt,start,end));
  const gross=orders.reduce((s,o)=>s+(Number(o.total)||0),0),refundTotal=refunds.reduce((s,r)=>s+(Number(r.amount)||0),0),invoiced=gross-refundTotal;
  const orderCash=orders.reduce((s,o)=>{if(o.paymentMethod==="Credit")return s+(Number(o.initialPaid)||0);return s+(o.paymentStatus==="Paid"||o.paymentStatus==="Part Refunded"||o.paymentStatus==="Refunded"?(Number(o.total)||0):0)},0);
  const refundCash=refunds.reduce((s,r)=>s+refundCashOutflow(r),0),collected=orderCash+creditPays.reduce((s,p)=>s+(Number(p.amount)||0),0)-refundCash,exp=expenses.reduce((s,e)=>s+(Number(e.amount)||0),0),credit=orders.filter(o=>o.paymentMethod==="Credit").reduce((s,o)=>s+orderBalance(o),0);
  $("reportSales").textContent=money.format(invoiced);$("reportCollected").textContent=money.format(collected);$("reportExpenses").textContent=money.format(exp);$("reportNet").textContent=money.format(collected-exp);$("reportOrders").textContent=orders.length;$("reportCredit").textContent=money.format(credit);
  const prod={};orders.forEach(o=>o.items.forEach(i=>{const p=product(i.id),k=p?.name||"Product",returned=refundedQty(o.id,i.id),netQty=Math.max(0,i.qty-returned);if(!prod[k])prod[k]={qty:0,revenue:0};prod[k].qty+=netQty;prod[k].revenue+=orderItemUnitPrice(i)*netQty}));
  const rows=Object.entries(prod).sort((a,b)=>b[1].revenue-a[1].revenue),maxP=Math.max(1,...rows.map(x=>x[1].revenue));$("reportProducts").innerHTML=rows.length?rows.map(([n,v])=>`<div class="report-row"><div><strong>${esc(n)}</strong><span>${v.qty} net units · ${money.format(v.revenue)}</span></div><div class="bar"><i style="width:${Math.round(v.revenue/maxP*100)}%"></i></div></div>`).join(""):`<div class="empty">No sales in this period.</div>`;
  const pays={};orders.forEach(o=>pays[o.paymentMethod]=(pays[o.paymentMethod]||0)+(Number(o.total)||0));refunds.forEach(r=>{if(r.paymentMethod!=="Credit Balance Reduction")pays[r.paymentMethod]=(pays[r.paymentMethod]||0)-(Number(r.amount)||0)});$("reportPayments").innerHTML=Object.entries(pays).map(([k,v])=>`<div class="mini-row"><span>${esc(k)}</span><strong>${money.format(v)}</strong></div>`).join("")||`<div class="empty">No payments.</div>`;
  const cats={};expenses.forEach(e=>cats[e.category]=(cats[e.category]||0)+(Number(e.amount)||0));$("reportExpenseCats").innerHTML=Object.entries(cats).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="mini-row"><span>${esc(k)}</span><strong>${money.format(v)}</strong></div>`).join("")||`<div class="empty">No expenses.</div>`
}
function renderAuth(){
  const l=!!state.session;$("sessionBadge").textContent=l?`${state.session.name} · ${state.session.role}`:"Guest";$("loginBtn").classList.toggle("hidden",l);$("logoutBtn").classList.toggle("hidden",!l);const staff=l&&["admin","cashier","baker","rider"].includes(state.session.role);$("staffApp").classList.toggle("hidden",!staff);$("customerPortal").classList.toggle("hidden",!(l&&state.session.role==="customer"));
  document.querySelectorAll(".admin-only").forEach(e=>e.classList.toggle("hidden",!can("admin")));document.querySelectorAll(".admin-cashier").forEach(e=>e.classList.toggle("hidden",!can("admin","cashier")));document.querySelectorAll(".staff-add").forEach(e=>e.classList.toggle("hidden",!staff));document.querySelectorAll(".admin-baker").forEach(e=>e.classList.toggle("hidden",!can("admin","baker")));document.querySelectorAll("[data-permission]").forEach(e=>e.classList.toggle("hidden",!hasPerm(e.dataset.permission)));
  $("bottomNav")?.classList.toggle("hidden",!staff);if(staff)$("roleNote").innerHTML=can("admin")?`<strong>Primary Admin</strong><div class="admin-lock-note">Full control over prices, records and staff permissions.</div>`:`Logged in as ${esc(state.session.role)} · enabled: ${esc(PERMISSION_KEYS.filter(hasPerm).map(k=>PERMISSION_LABELS[k]).join(", ")||"view only")}`;renderCustomerOrders()
}
function renderAll(){renderCategories();populateSelects();renderProducts();renderCart();renderAuth();renderPOS();renderMaterials();renderRecipes();renderProduction();renderOrders();renderInventory();renderExpenses();renderEmployees();renderDelivery();renderSuppliers();renderCredit();renderReports();renderCustomers();renderReceiptHistory();renderCashierShifts();renderCashClosing();renderStockAdjustments();renderStockMovementLedger();renderWaste();renderStats();renderDashboard();renderCloud()}

function renderAllV10Legacy(){renderCategories();populateSelects();renderProducts();renderCart();renderAuth();renderPOS();renderMaterials();renderRecipes();renderProduction();renderOrders();renderInventory();renderExpenses();renderEmployees();renderDelivery();renderSuppliers();renderCredit();renderReports();renderCustomers();renderReceiptHistory();renderCashClosing();renderStockAdjustments();renderWaste();renderStats();renderDashboard();renderCloud()}
document.addEventListener("click",e=>{
 const s=e.target.closest("[data-scroll]");if(s)$(s.dataset.scroll)?.scrollIntoView({behavior:"smooth"});
 if(e.target.matches("[data-close]"))$("modalBackdrop").classList.add("hidden");
 if(e.target.matches("[data-payment-close]"))$("paymentBackdrop").classList.add("hidden");
 if(e.target.matches("[data-receipt-close]"))$("receiptBackdrop").classList.add("hidden");
 if(e.target.matches("[data-customer-close]"))$("customerBackdrop").classList.add("hidden");if(e.target.matches("[data-permissions-close]")){$("permissionsBackdrop").classList.add("hidden");editingPermissionsUserId=null}if(e.target.matches("[data-order-detail-close]"))$("orderDetailBackdrop").classList.add("hidden");if(e.target.matches("[data-refund-close]")){$("refundBackdrop").classList.add("hidden");refundOrderId=null}if(e.target.matches("[data-customer-cancel-close]")){$("customerCancelBackdrop").classList.add("hidden");customerCancelOrderId=null}
 if(e.target.matches("[data-close-more]")||e.target.id==="moreMenuBackdrop")$("moreMenuBackdrop").classList.add("hidden");
 const main=e.target.closest("[data-main]");if(main){const requested=main.dataset.subOpen||null;openMainSection(main.dataset.main,requested);return}
 const sub=e.target.closest("[data-subpanel]");if(sub){showPanel(sub.dataset.subpanel);return}
 if(e.target.closest("[data-more-menu]")){$("moreMenuBackdrop").classList.remove("hidden");return}
 const a=e.target.closest(".auth-tab");if(a){document.querySelectorAll(".auth-tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".auth-pane").forEach(x=>x.classList.add("hidden"));a.classList.add("active");$(a.dataset.auth).classList.remove("hidden")}
});
$("loginBtn").onclick=()=>$("modalBackdrop").classList.remove("hidden");$("logoutBtn").onclick=logout;$("doLoginBtn").onclick=login;$("registerBtn").onclick=registerCustomer;$("searchInput").oninput=renderProducts;$("categoryFilter").onchange=renderProducts;$("needsDelivery").onchange=renderCart;$("checkoutBtn").onclick=checkout;$("cakeOrderBtn").onclick=customCake;$("orderStatusFilter").onchange=renderOrders;$("showAddProduct").onclick=()=>$("addProductBox").classList.toggle("hidden");$("addProductBtn").onclick=addProduct;$("addExpenseBtn").onclick=addExpense;$("addCustomerBtn").onclick=addCustomer;$("customerSearch").oninput=renderCustomers;$("customerFilter").onchange=renderCustomers;$("receiptSearch").oninput=renderReceiptHistory;$("receiptDate").onchange=renderReceiptHistory;$("receiptPaymentFilter").onchange=renderReceiptHistory;$("addSupplierBtn").onclick=addSupplier;$("reportPeriod").onchange=renderReports;$("exportReportBtn").onclick=exportReportCSV;$("addEmployeeBtn").onclick=addEmployee;$("posSearch").oninput=renderPOS;$("posDiscount").oninput=renderPOS;$("posTender").oninput=renderPOS;$("clearPOSBtn").onclick=clearPOS;$("completePOSBtn").onclick=completePOS;$("showMaterialForm").onclick=()=>$("materialForm").classList.toggle("hidden");$("addMaterialBtn").onclick=addMaterial;$("recordPurchaseBtn").onclick=recordPurchase;$("addRecipeItemBtn").onclick=addRecipeItem;$("addProductionBtn").onclick=addProduction;$("connectCloudBtn").onclick=connectCloud;$("testCloudBtn").onclick=cloudTest;$("pushCloudBtn").onclick=()=>cloudPush(false);$("pullCloudBtn").onclick=cloudPull;$("exportBtn").onclick=exportBackup;$("importFile").onchange=e=>e.target.files[0]&&importBackup(e.target.files[0]);$("resetBtn").onclick=resetDemo;$("cloudMode").onchange=cloudConfigFromUI;$("cloudUrl").onchange=cloudConfigFromUI;$("confirmPaymentBtn").onclick=requestBackendPayment;$("closingDate").onchange=renderCashClosing;$("closingActualCash").oninput=renderCashClosing;$("submitClosingBtn").onclick=submitCashClosing;$("adjustmentType").onchange=populateStockControlSelects;$("wasteType").onchange=populateStockControlSelects;$("recordAdjustmentBtn").onclick=recordStockAdjustment;$("recordWasteBtn").onclick=recordWaste;$("openShiftBtn").onclick=openCashierShift;$("closeShiftBtn").onclick=closeCashierShift;$("movementSearch").oninput=renderStockMovementLedger;$("movementTypeFilter").onchange=renderStockMovementLedger;$("savePermissionsBtn").onclick=saveStaffPermissions;$("refundItem").onchange=renderRefundPreview;$("refundQty").oninput=renderRefundPreview;$("submitRefundBtn").onclick=processRefund;$("submitCustomerCancelBtn").onclick=submitCustomerCancellation;
$("uiDialogCancel").onclick=()=>closeUIDialog(null);$("uiDialogOk").onclick=()=>closeUIDialog($("uiDialogInput").classList.contains("hidden")?true:$("uiDialogInput").value);$("uiDialogInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("uiDialogOk").click();if(e.key==="Escape")$("uiDialogCancel").click()});
$("refreshAuditBtn").onclick=renderAudit;$("downloadTemplateBtn").onclick=downloadCsvTemplate;$("importCsvBtn").onclick=importCsv;$("printReceiptBtn").onclick=()=>window.print();$("openPOSHero").onclick=()=>{if(!hasPerm("sales")){$("modalBackdrop").classList.remove("hidden");toast("Login with sales permission to use POS.");return;}openMainSection("sales")};
Object.assign(window,{addToCart,qty,posAdd,posQty,openPurchase,recordPurchase,setMaterialStock,setRecipeYield,removeRecipeItem,startProduction,completeProduction,cancelProduction,setOrderStatus,setCakeStatus,markPaid,restock,adjustStock,assignRider,setDeliveryStatus,showReceipt,paySupplier,recordCreditPayment,openMainSection,viewCustomer,editProduct,deleteProduct,editMaterial,deleteMaterial,editRecipeQty,clearRecipe,editProduction,editExpense,deleteExpense,editSupplier,deleteSupplier,editCustomer,deleteCustomer,editEmployee,deleteEmployee,editCake,editOrderContact,voidOrder,deleteOrder,confirmCashClosing,editCashClosing,reverseStockAdjustment,voidWaste,editStaffPermissions,saveStaffPermissions,openCashierShift,closeCashierShift,showOrderDetails,openRefund,processRefund,openCustomerCancel,submitCustomerCancellation});
renderAll();updateSyncMini();if(state.session&&["admin","cashier","baker","rider"].includes(state.session.role))openMainSection("dashboard");if(cloudToken()&&state.cloud?.url){startRealtimeSync();startCloudPolling();if(outboxCount())flushSyncOutbox(true)}

if("serviceWorker" in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("service-worker.js").catch(()=>{});
